// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "Version",
    targets: [
        .target(name: "Version"),
        .testTarget(name: "VersionTests", dependencies: ["Version"]),
    ]
)
