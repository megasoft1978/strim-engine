import XCTest
@testable import Version

final class VersionTests: XCTestCase {
    func v(_ s: String) -> Version { Version(s)! }

    func testNumericNotLexicographic() {
        XCTAssertTrue(v("1.9") < v("1.10"))
        XCTAssertTrue(v("2.0.0") > v("1.99.99"))
        XCTAssertFalse(v("1.10") < v("1.9"))
    }

    func testTrailingZerosEqual() {
        XCTAssertEqual(v("1.0"), v("1.0.0"))
        XCTAssertTrue(v("1.0.1") > v("1.0"))
    }

    func testSorting() {
        let sorted = ["1.2", "1.10", "1.9.1", "1.9"].map(v).sorted().map(\.description)
        XCTAssertEqual(sorted, ["1.2", "1.9", "1.9.1", "1.10"])
    }

    func testInvalid() {
        XCTAssertNil(Version("1..2"))
        XCTAssertNil(Version("a.b"))
        XCTAssertNil(Version(""))
        XCTAssertNil(Version("1.-2"))
    }
}
