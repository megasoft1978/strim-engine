/// Dotted numeric version such as "1.10.2". Missing trailing components count as 0.
public struct Version: Comparable, CustomStringConvertible {
    public let parts: [Int]

    public init?(_ text: String) {
        let pieces = text.split(separator: ".", omittingEmptySubsequences: false).map { Int($0) }
        guard !pieces.isEmpty, !pieces.contains(where: { $0 == nil || $0! < 0 }) else { return nil }
        parts = pieces.map { $0! }
    }

    public var description: String { parts.map(String.init).joined(separator: ".") }

    public static func < (a: Version, b: Version) -> Bool {
        return a.description < b.description
    }

    public static func == (a: Version, b: Version) -> Bool {
        !(a < b) && !(b < a)
    }
}
