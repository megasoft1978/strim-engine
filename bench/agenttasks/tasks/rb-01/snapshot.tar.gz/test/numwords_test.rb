require 'minitest/autorun'
require 'numwords'

class NumWordsTest < Minitest::Test
  def test_small_numbers
    assert_equal 'zero', NumWords.to_words(0)
    assert_equal 'nineteen', NumWords.to_words(19)
  end

  def test_tens_are_hyphenated
    assert_equal 'twenty', NumWords.to_words(20)
    assert_equal 'forty-two', NumWords.to_words(42)
    assert_equal 'ninety-nine', NumWords.to_words(99)
  end

  def test_hundreds_use_and_only_in_the_last_group
    assert_equal 'one hundred', NumWords.to_words(100)
    assert_equal 'one hundred and five', NumWords.to_words(105)
    assert_equal 'three hundred and twenty-one', NumWords.to_words(321)
  end

  def test_thousands
    assert_equal 'one thousand', NumWords.to_words(1000)
    assert_equal 'twelve thousand three hundred and forty-five', NumWords.to_words(12_345)
    assert_equal 'two thousand and one', NumWords.to_words(2001)
    assert_equal 'nine hundred and ninety-nine thousand nine hundred and ninety-nine', NumWords.to_words(999_999)
  end

  def test_negative_and_errors
    assert_equal 'minus seven', NumWords.to_words(-7)
    assert_raises(ArgumentError) { NumWords.to_words(1.5) }
    assert_raises(RangeError) { NumWords.to_words(1_000_000) }
  end

  def test_ordinals
    assert_equal '1st', NumWords.ordinal(1)
    assert_equal '22nd', NumWords.ordinal(22)
    assert_equal '103rd', NumWords.ordinal(103)
    assert_equal '11th', NumWords.ordinal(11)
    assert_equal '12th', NumWords.ordinal(12)
    assert_equal '213th', NumWords.ordinal(213)
    assert_equal '4th', NumWords.ordinal(4)
  end
end
