# English words for whole numbers.
module NumWords
  ONES = %w[zero one two three four five six seven eight nine ten eleven twelve thirteen
            fourteen fifteen sixteen seventeen eighteen nineteen].freeze
  TENS = %w[_ _ twenty thirty forty fifty sixty seventy eighty ninety].freeze

  module_function

  # to_words(0) => "zero", to_words(42) => "forty-two", to_words(1_205) => "one thousand two hundred five"
  # Numbers up to 999_999; negatives get a "minus " prefix.
  def to_words(n)
    raise ArgumentError, 'integer expected' unless n.is_a?(Integer)
    raise RangeError, 'too large' if n.abs > 999_999
    return "minus #{to_words(-n)}" if n.negative?
    return ONES[n] if n < 20

    parts = []
    thousands, rest = n.divmod(1000)
    parts << "#{below_thousand(thousands)} thousand" if thousands.positive?
    parts << below_thousand(rest) if rest.positive?
    parts.join(' ')
  end

  def below_thousand(n)
    words = []
    hundreds, rest = n.divmod(100)
    words << "#{ONES[hundreds]} hundred" if hundreds.positive?
    if rest >= 20
      tens, ones = rest.divmod(10)
      words << (ones.zero? ? TENS[tens] : "#{TENS[tens]} #{ONES[ones]}")
    elsif rest.positive?
      words << ONES[rest]
    end
    words.join(' ')
  end

  # Ordinal suffix: 1 => "1st", 12 => "12th", 23 => "23rd".
  def ordinal(n)
    suffix = case n % 10
             when 1 then 'st'
             when 2 then 'nd'
             when 3 then 'rd'
             else 'th'
             end
    "#{n}#{suffix}"
  end
end
