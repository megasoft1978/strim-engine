'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parse, compare, max } = require('../lib/semver.js');

test('parse reads all parts', () => {
  assert.deepEqual(parse('v1.20.3-beta.1+b5'), { major: 1, minor: 20, patch: 3, pre: ['beta', '1'] });
  assert.equal(parse('1.2'), null);
  assert.equal(parse('x.y.z'), null);
});

test('compare orders numerically, not as strings', () => {
  assert.equal(compare('1.2.0', '1.10.0'), -1);
  assert.equal(compare('2.0.0', '10.0.0'), -1);
  assert.equal(compare('1.0.9', '1.0.10'), -1);
  assert.equal(compare('1.0.0', '1.0.0'), 0);
  assert.equal(compare('3.0.0', '2.9.9'), 1);
});

test('prerelease sorts below the release', () => {
  assert.equal(compare('1.0.0-rc.1', '1.0.0'), -1);
  assert.equal(compare('1.0.0-alpha.2', '1.0.0-alpha.10'), -1);
  assert.equal(compare('1.0.0-1', '1.0.0-alpha'), -1);
});

test('compare rejects invalid input', () => {
  assert.throws(() => compare('1.0', '1.0.0'), TypeError);
});

test('max skips invalid entries', () => {
  assert.equal(max(['1.9.0', 'nope', '1.10.0', '1.2.0']), '1.10.0');
  assert.equal(max([]), null);
});
