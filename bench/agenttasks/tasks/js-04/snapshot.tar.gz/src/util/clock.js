'use strict';

/** Wall clock and sleep; tests replace both. */
const clock = {
  now: () => Date.now(),
  sleep: (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
};

module.exports = { clock };
