'use strict';

let counter = 0;

/** Monotonic job ids such as "job-000042". */
function nextId(prefix = 'job') {
  counter += 1;
  return `${prefix}-${String(counter).padStart(6, '0')}`;
}

function resetIds() { counter = 0; }

module.exports = { nextId, resetIds };
