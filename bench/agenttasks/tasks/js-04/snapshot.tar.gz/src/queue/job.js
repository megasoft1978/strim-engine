'use strict';
const { nextId } = require('../util/ids.js');

const STATES = ['queued', 'running', 'done', 'failed', 'dead'];

class Job {
  constructor(name, payload, opts = {}) {
    this.id = nextId();
    this.name = name;
    this.payload = payload;
    this.maxAttempts = opts.maxAttempts === undefined ? 3 : opts.maxAttempts;
    this.attempts = 0;
    this.state = 'queued';
    this.runAt = 0;
    this.lastError = null;
  }

  transition(to) {
    if (!STATES.includes(to)) throw new Error(`unknown state ${to}`);
    this.state = to;
  }

  get exhausted() { return this.attempts >= this.maxAttempts; }
}

module.exports = { Job, STATES };
