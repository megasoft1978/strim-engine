'use strict';
const { retryDelay } = require('./backoff.js');
const { clock } = require('../util/clock.js');

/** Runs due jobs with a handler map { name: async (payload) => any }. */
class Worker {
  constructor(store, handlers, opts = {}) {
    this.store = store;
    this.handlers = handlers;
    this.random = opts.random || Math.random;
    this.log = opts.log || (() => {});
  }

  async runOne() {
    const job = this.store.takeDue(clock.now());
    if (!job) return false;
    const handler = this.handlers[job.name];
    job.transition('running');
    job.attempts += 1;
    try {
      if (!handler) throw new Error(`no handler for ${job.name}`);
      await handler(job.payload);
      job.transition('done');
    } catch (err) {
      job.lastError = String(err && err.message || err);
      if (job.exhausted) {
        job.transition('dead');
        this.log(`dead ${job.id}`);
      } else {
        job.transition('queued');
        job.runAt = clock.now() + retryDelay(job.attempts, this.random);
        this.log(`retry ${job.id} at ${job.runAt}`);
      }
    }
    return true;
  }

  async drain() {
    let n = 0;
    while (await this.runOne()) n += 1;
    return n;
  }
}

module.exports = { Worker };
