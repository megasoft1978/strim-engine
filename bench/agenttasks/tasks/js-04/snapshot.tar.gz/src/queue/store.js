'use strict';

/** In-memory job store ordered by runAt, then insertion order. */
class Store {
  constructor() { this.jobs = []; }

  add(job) {
    this.jobs.push(job);
    this.jobs.sort((a, b) => a.runAt - b.runAt);
  }

  /** The next queued job whose runAt is <= now, or undefined. */
  takeDue(now) {
    const i = this.jobs.findIndex((j) => j.state === 'queued' && j.runAt <= now);
    return i < 0 ? undefined : this.jobs[i];
  }

  countBy(state) { return this.jobs.filter((j) => j.state === state).length; }
}

module.exports = { Store };
