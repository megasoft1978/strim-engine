'use strict';

const BASE_MS = 200;
const FACTOR = 2;
const CAP_MS = 30000;

/**
 * Delay before retry number `attempt` (1-based): exponential growth from BASE_MS, capped at CAP_MS,
 * with up to 20 percent random jitter subtracted so that retries of many jobs do not align.
 */
function retryDelay(attempt, random = Math.random) {
  const raw = Math.min(CAP_MS, BASE_MS * Math.pow(FACTOR, attempt - 1));
  return Math.round(raw * (1 - 0.2 * random()));
}

module.exports = { retryDelay, BASE_MS, CAP_MS };
