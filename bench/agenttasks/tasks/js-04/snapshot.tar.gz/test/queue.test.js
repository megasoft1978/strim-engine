'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { Job, Store, Worker } = require('../src/index.js');
const { clock } = require('../src/util/clock.js');
const { retryDelay } = require('../src/queue/backoff.js');

test('a job that succeeds is done', async () => {
  const store = new Store();
  store.add(new Job('echo', { x: 1 }));
  const w = new Worker(store, { echo: async () => 'ok' });
  assert.equal(await w.drain(), 1);
  assert.equal(store.countBy('done'), 1);
});

test('retry delay grows and is capped', () => {
  assert.equal(retryDelay(1, () => 0), 200);
  assert.equal(retryDelay(3, () => 0), 800);
  assert.equal(retryDelay(20, () => 0), 30000);
});

test('failing jobs die after maxAttempts', async () => {
  let t = 0;
  clock.now = () => t;
  const store = new Store();
  store.add(new Job('boom', {}, { maxAttempts: 2 }));
  const w = new Worker(store, { boom: async () => { throw new Error('nope'); } }, { random: () => 0 });
  await w.drain();
  t += 1000;
  await w.drain();
  assert.equal(store.countBy('dead'), 1);
  clock.now = () => Date.now();
});
