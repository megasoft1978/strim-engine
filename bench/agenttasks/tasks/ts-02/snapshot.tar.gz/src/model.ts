export type Cents = number;

export interface Line {
  sku: string;
  unitPrice: Cents;
  qty: number;
  /** Percent off this line (0-100). */
  discountPct?: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: Line[];
  /** Sales tax in basis points (825 = 8.25 percent). */
  taxBp: number;
}

export function line(sku: string, unitPrice: Cents, qty: number, discountPct?: number): Line {
  return discountPct === undefined ? { sku, unitPrice, qty } : { sku, unitPrice, qty, discountPct };
}
