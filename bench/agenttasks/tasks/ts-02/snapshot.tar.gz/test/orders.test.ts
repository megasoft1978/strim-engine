import test from 'node:test';
import assert from 'node:assert/strict';
import { line } from '../src/model.ts';
import type { Order } from '../src/model.ts';
import { lineTotal, subtotal, tax, total, roundCents } from '../src/pricing.ts';
import { formatCents, summarize, receipt } from '../src/report.ts';

const order = (id: string, customer: string, lines: ReturnType<typeof line>[], taxBp = 1000): Order => ({ id, customer, lines, taxBp });

test('roundCents is half away from zero', () => {
  assert.equal(roundCents(2.5), 3);
  assert.equal(roundCents(-2.5), -3);
  assert.equal(roundCents(2.4), 2);
});

test('line totals apply the discount', () => {
  assert.equal(lineTotal(line('a', 1000, 3)), 3000);
  assert.equal(lineTotal(line('a', 1000, 3, 10)), 2700);
  assert.equal(lineTotal(line('b', 333, 1, 50)), 167);
});

test('tax applies to the discounted subtotal', () => {
  const o = order('1', 'ann', [line('a', 1000, 2, 50), line('b', 500, 1)]);
  assert.equal(subtotal(o), 1500);
  assert.equal(tax(o), 150);
  assert.equal(total(o), 1650);
});

test('money formatting', () => {
  assert.equal(formatCents(5), '$0.05');
  assert.equal(formatCents(123456), '$1234.56');
  assert.equal(formatCents(-250), '-$2.50');
});

test('summaries: tax-inclusive spend, biggest spender first', () => {
  const orders = [
    order('1', 'ann', [line('a', 1000, 1)]),
    order('2', 'bob', [line('a', 3000, 1)]),
    order('3', 'ann', [line('a', 1000, 1)]),
    order('4', 'cy', [line('a', 2000, 1, 0)], 0),
  ];
  assert.deepEqual(summarize(orders), [
    { customer: 'bob', orders: 1, spent: 3300 },
    { customer: 'ann', orders: 2, spent: 2200 },
    { customer: 'cy', orders: 1, spent: 2000 },
  ]);
});

test('receipt', () => {
  const o = order('9', 'dee', [line('pen', 250, 4, 20)], 825);
  assert.equal(receipt(o), 'pen x4\nsubtotal $8.00\ntax $0.66\ntotal $8.66');
});
