package shop

import (
	"errors"
	"reflect"
	"testing"
)

func TestRemoveExactDropsSKU(t *testing.T) {
	s := NewStock()
	s.Add("a", 3)
	if err := s.Remove("a", 3); err != nil {
		t.Fatalf("Remove all: %v", err)
	}
	if got := s.SKUs(); len(got) != 0 {
		t.Fatalf("SKUs = %v, want none", got)
	}
}

func TestRemoveTooMany(t *testing.T) {
	s := NewStock()
	s.Add("a", 2)
	if err := s.Remove("a", 3); !errors.Is(err, ErrInsufficient) {
		t.Fatalf("err = %v, want ErrInsufficient", err)
	}
	if s.Count("a") != 2 {
		t.Fatalf("Count = %d, want 2", s.Count("a"))
	}
}

func TestSKUsSorted(t *testing.T) {
	s := NewStock()
	for _, k := range []string{"h", "c", "f", "a", "g", "b", "e", "d"} {
		s.Add(k, 1)
	}
	want := []string{"a", "b", "c", "d", "e", "f", "g", "h"}
	if got := s.SKUs(); !reflect.DeepEqual(got, want) {
		t.Fatalf("SKUs = %v, want %v", got, want)
	}
}
