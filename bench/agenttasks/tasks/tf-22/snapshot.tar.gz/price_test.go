package shop

import "testing"

func TestDiscountRoundsHalfUp(t *testing.T) {
	cases := []struct{ cents, pct, want int }{
		{1000, 10, 900}, {999, 10, 899}, {995, 10, 896}, {5, 50, 3}, {100, 0, 100}, {100, 100, 0},
	}
	for _, c := range cases {
		if got := Discount(c.cents, c.pct); got != c.want {
			t.Errorf("Discount(%d,%d) = %d, want %d", c.cents, c.pct, got, c.want)
		}
	}
}

func TestWithTaxRoundsHalfUp(t *testing.T) {
	cases := []struct{ cents, bps, want int }{
		{1000, 825, 1083}, {1999, 825, 2164}, {10, 500, 11}, {100, 0, 100},
	}
	for _, c := range cases {
		if got := WithTax(c.cents, c.bps); got != c.want {
			t.Errorf("WithTax(%d,%d) = %d, want %d", c.cents, c.bps, got, c.want)
		}
	}
}
