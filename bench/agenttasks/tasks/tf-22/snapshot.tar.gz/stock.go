package shop

import (
	"errors"
	"sort"
)

var ErrInsufficient = errors.New("insufficient stock")

type Stock struct{ items map[string]int }

func NewStock() *Stock { return &Stock{items: map[string]int{}} }

func (s *Stock) Add(sku string, n int) { s.items[sku] += n }

// Remove takes n units of sku. Removing exactly what is there is fine and drops the SKU.
func (s *Stock) Remove(sku string, n int) error {
	if s.items[sku] <= n {
		return ErrInsufficient
	}
	s.items[sku] -= n
	return nil
}

func (s *Stock) Count(sku string) int { return s.items[sku] }

// SKUs lists the SKUs in stock, sorted.
func (s *Stock) SKUs() []string {
	out := make([]string, 0, len(s.items))
	for k := range s.items {
		out = append(out, k)
	}
	return out
}
