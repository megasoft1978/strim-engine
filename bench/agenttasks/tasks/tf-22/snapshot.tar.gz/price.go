package shop

// Discount returns cents after a percent discount, rounded half up.
func Discount(cents, pct int) int { return cents * (100 - pct) / 100 }

// WithTax adds tax given in basis points (1 bp = 0.01%), rounded half up.
func WithTax(cents, bps int) int { return cents + cents*bps/10000 }
