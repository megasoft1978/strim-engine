package shop

import (
	"errors"
	"strings"
	"testing"
)

func TestTotalUsesQuantity(t *testing.T) {
	lines := []Line{{"a", 3, 250}, {"b", 1, 1000}}
	if got, want := Total(lines, 10, 825), 1705; got != want {
		t.Fatalf("Total = %d, want %d", got, want)
	}
	if got := Total(nil, 10, 825); got != 0 {
		t.Fatalf("Total(nil) = %d", got)
	}
}

func TestFulfilAllOrNothing(t *testing.T) {
	s := NewStock()
	s.Add("a", 5)
	s.Add("b", 1)
	err := Fulfil(s, []Line{{"a", 2, 1}, {"b", 2, 1}})
	if !errors.Is(err, ErrInsufficient) {
		t.Fatalf("err = %v, want wrapping ErrInsufficient", err)
	}
	if !strings.Contains(err.Error(), "sku b") {
		t.Fatalf("err %q does not name sku b", err)
	}
	if s.Count("a") != 5 || s.Count("b") != 1 {
		t.Fatalf("stock changed on failure: a=%d b=%d", s.Count("a"), s.Count("b"))
	}
}

func TestFulfilSuccess(t *testing.T) {
	s := NewStock()
	s.Add("a", 5)
	if err := Fulfil(s, []Line{{"a", 5, 1}}); err != nil {
		t.Fatal(err)
	}
	if len(s.SKUs()) != 0 {
		t.Fatalf("SKUs = %v", s.SKUs())
	}
}
