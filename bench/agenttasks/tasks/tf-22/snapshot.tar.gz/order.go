package shop

import "fmt"

type Line struct {
	SKU       string
	Qty       int
	UnitCents int
}

// Total is the sum of Qty*UnitCents, discounted by pct, then taxed by bps.
func Total(lines []Line, pct, bps int) int {
	sum := 0
	for _, l := range lines {
		sum += l.UnitCents
	}
	return WithTax(Discount(sum, pct), bps)
}

// Fulfil removes every line from the stock or none of them. A shortage is
// reported as an error wrapping ErrInsufficient and names the SKU.
func Fulfil(s *Stock, lines []Line) error {
	for _, l := range lines {
		if err := s.Remove(l.SKU, l.Qty); err != nil {
			return fmt.Errorf("sku %s: %v", l.SKU, err)
		}
	}
	return nil
}
