import test from 'node:test';
import assert from 'node:assert/strict';
import { Emitter } from '../src/emitter.ts';

type Ev = { greet: [name: string]; tick: []; sum: [a: number, b: number] };

test('emit returns whether anything listened', () => {
  const e = new Emitter<Ev>();
  assert.equal(e.emit('tick'), false);
  e.on('tick', () => {});
  assert.equal(e.emit('tick'), true);
});

test('on returns an unsubscribe function', () => {
  const e = new Emitter<Ev>();
  const seen: string[] = [];
  const off = e.on('greet', (n) => seen.push(n));
  e.emit('greet', 'a');
  off();
  e.emit('greet', 'b');
  assert.deepEqual(seen, ['a']);
  assert.equal(e.listenerCount('greet'), 0);
  off(); // idempotent
});

test('off removes one listener by reference', () => {
  const e = new Emitter<Ev>();
  const calls: number[] = [];
  const f = (a: number, b: number) => calls.push(a + b);
  const g = (a: number, b: number) => calls.push(a * b);
  e.on('sum', f);
  e.on('sum', g);
  e.off('sum', f);
  e.emit('sum', 3, 4);
  assert.deepEqual(calls, [12]);
});

test('once fires a single time and can be cancelled', () => {
  const e = new Emitter<Ev>();
  let n = 0;
  e.once('tick', () => { n += 1; });
  e.emit('tick');
  e.emit('tick');
  assert.equal(n, 1);
  assert.equal(e.listenerCount('tick'), 0);
  const cancel = e.once('tick', () => { n += 100; });
  cancel();
  e.emit('tick');
  assert.equal(n, 1);
});

test('listeners added during emit run on the next emit; removals during emit still run this round', () => {
  const e = new Emitter<Ev>();
  const order: string[] = [];
  const second = () => order.push('second');
  e.on('tick', () => { order.push('first'); e.off('tick', second); e.on('tick', () => order.push('late')); });
  e.on('tick', second);
  e.emit('tick');
  assert.deepEqual(order, ['first', 'second']);
  e.emit('tick');
  assert.deepEqual(order, ['first', 'second', 'first', 'late']);
});

test('a throwing listener does not stop the others and the first error is rethrown after', () => {
  const e = new Emitter<Ev>();
  const ran: string[] = [];
  e.on('tick', () => { throw new Error('one'); });
  e.on('tick', () => { ran.push('two'); });
  assert.throws(() => e.emit('tick'), /one/);
  assert.deepEqual(ran, ['two']);
});
