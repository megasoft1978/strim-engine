import { Emitter } from '../src/emitter.ts';

type Ev = { greet: [name: string]; tick: []; sum: [a: number, b: number] };
const e = new Emitter<Ev>();

e.on('greet', (n) => {
  const s: string = n;
  void s;
});
const off: () => void = e.on('tick', () => {});
const cancel: () => void = e.once('sum', (a, b) => void (a + b));
const n: number = e.listenerCount('greet');
void off; void cancel; void n;

// @ts-expect-error unknown event name
e.on('nope', () => {});
// @ts-expect-error wrong argument type
e.emit('greet', 42);
// @ts-expect-error missing arguments
e.emit('sum', 1);
// @ts-expect-error listener parameter types are checked
e.off('greet', (n: number) => void n);
