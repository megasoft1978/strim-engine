/** Map of event name to the tuple of its listener arguments. */
export type EventMap = Record<string, unknown[]>;

// Stored listeners are type-erased; the public methods keep the per-event argument types.
// deno-lint-ignore no-explicit-any
type AnyFn = (...args: any[]) => void;

export class Emitter<E extends EventMap> {
  private listeners = new Map<keyof E, Array<AnyFn>>();

  on<K extends keyof E>(event: K, fn: (...args: E[K]) => void): void {
    const list = this.listeners.get(event) ?? [];
    list.push(fn);
    this.listeners.set(event, list);
  }

  emit<K extends keyof E>(event: K, ...args: E[K]): boolean {
    const list = this.listeners.get(event);
    if (!list || list.length === 0) return false;
    for (const fn of [...list]) fn(...args);
    return true;
  }
}
