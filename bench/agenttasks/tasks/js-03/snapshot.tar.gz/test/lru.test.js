'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { LRU } = require('../lib/lru.js');

test('basic get/set and eviction order', () => {
  const c = new LRU({ max: 2 });
  c.set('a', 1).set('b', 2);
  assert.equal(c.get('a'), 1);
  c.set('c', 3);
  assert.equal(c.has('b'), false);
  assert.deepEqual(c.keys(), ['a', 'c']);
});

test('invalid max', () => {
  assert.throws(() => new LRU({ max: 0 }), RangeError);
});

// --- new behaviour: peek, TTL, eviction callback ---

test('peek reads without refreshing recency', () => {
  const c = new LRU({ max: 2 });
  c.set('a', 1).set('b', 2);
  assert.equal(c.peek('a'), 1);
  assert.equal(c.peek('zzz'), undefined);
  c.set('c', 3);
  assert.equal(c.has('a'), false, 'a was only peeked, so it is still the oldest');
});

test('entries expire after ttl (injected clock)', () => {
  let now = 1000;
  const c = new LRU({ max: 5, ttl: 100, now: () => now });
  c.set('a', 1);
  now = 1099;
  assert.equal(c.get('a'), 1);
  now = 1100;
  assert.equal(c.get('a'), undefined, 'expired exactly at ttl');
  assert.equal(c.has('a'), false);
  assert.equal(c.size, 0, 'expired entries are removed when touched');
});

test('set refreshes the ttl and per-entry ttl overrides the default', () => {
  let now = 0;
  const c = new LRU({ ttl: 100, now: () => now });
  c.set('a', 1);
  now = 90;
  c.set('a', 2);
  now = 150;
  assert.equal(c.get('a'), 2);
  c.set('b', 1, { ttl: 10 });
  now = 161;
  assert.equal(c.get('b'), undefined);
  assert.equal(c.peek('a'), 2);
});

test('size and keys ignore expired entries', () => {
  let now = 0;
  const c = new LRU({ ttl: 10, now: () => now });
  c.set('a', 1);
  now = 5;
  c.set('b', 2);
  now = 12;
  assert.equal(c.size, 1);
  assert.deepEqual(c.keys(), ['b']);
});

test('onEvict reports why an entry left', () => {
  let now = 0;
  const log = [];
  const c = new LRU({ max: 2, ttl: 50, now: () => now, onEvict: (k, v, why) => log.push([k, v, why]) });
  c.set('a', 1).set('b', 2).set('c', 3);
  assert.deepEqual(log, [['a', 1, 'capacity']]);
  c.delete('b');
  assert.deepEqual(log.at(-1), ['b', 2, 'deleted']);
  now = 60;
  c.get('c');
  assert.deepEqual(log.at(-1), ['c', 3, 'expired']);
  c.set('c', 9);
  c.set('c', 10);
  assert.deepEqual(log.at(-1), ['c', 9, 'replaced']);
});
