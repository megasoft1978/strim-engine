use matrix::{Matrix, ShapeError};

// New API under test: from_rows, identity, transpose, add, mul, Display. Existing: zeros, get, set.

fn m(rows: &[&[f64]]) -> Matrix {
    Matrix::from_rows(rows.iter().map(|r| r.to_vec()).collect()).unwrap()
}

#[test]
fn existing_basics() {
    let mut z = Matrix::zeros(2, 3);
    assert_eq!((z.rows(), z.cols()), (2, 3));
    assert!(z.set(1, 2, 4.5));
    assert_eq!(z.get(1, 2), Some(4.5));
    assert_eq!(z.get(2, 0), None);
}

#[test]
fn from_rows_validates_shape() {
    let a = m(&[&[1.0, 2.0], &[3.0, 4.0]]);
    assert_eq!(a.get(1, 0), Some(3.0));
    assert_eq!(
        Matrix::from_rows(vec![vec![1.0, 2.0], vec![3.0]]).unwrap_err(),
        ShapeError::Ragged { row: 1, expected: 2, found: 1 }
    );
    assert_eq!(Matrix::from_rows(vec![]).unwrap_err(), ShapeError::Empty);
    assert_eq!(Matrix::from_rows(vec![vec![]]).unwrap_err(), ShapeError::Empty);
}

#[test]
fn identity_and_transpose() {
    let i = Matrix::identity(3);
    assert_eq!(i.get(0, 0), Some(1.0));
    assert_eq!(i.get(0, 1), Some(0.0));
    let a = m(&[&[1.0, 2.0, 3.0], &[4.0, 5.0, 6.0]]);
    let t = a.transpose();
    assert_eq!((t.rows(), t.cols()), (3, 2));
    assert_eq!(t.get(2, 1), Some(6.0));
    assert_eq!(t.transpose(), a);
}

#[test]
fn add_requires_equal_shapes() {
    let a = m(&[&[1.0, 2.0], &[3.0, 4.0]]);
    let b = m(&[&[10.0, 20.0], &[30.0, 40.0]]);
    assert_eq!(a.add(&b).unwrap(), m(&[&[11.0, 22.0], &[33.0, 44.0]]));
    let c = m(&[&[1.0, 2.0, 3.0]]);
    assert_eq!(a.add(&c).unwrap_err(), ShapeError::Mismatch { left: (2, 2), right: (1, 3) });
}

#[test]
fn multiplication() {
    let a = m(&[&[1.0, 2.0, 3.0], &[4.0, 5.0, 6.0]]);
    let b = m(&[&[7.0, 8.0], &[9.0, 10.0], &[11.0, 12.0]]);
    assert_eq!(a.mul(&b).unwrap(), m(&[&[58.0, 64.0], &[139.0, 154.0]]));
    assert_eq!(a.mul(&Matrix::identity(3)).unwrap(), a);
    assert_eq!(a.mul(&a).unwrap_err(), ShapeError::Mismatch { left: (2, 3), right: (2, 3) });
}

#[test]
fn display_aligns_columns() {
    let a = m(&[&[1.0, 22.5], &[-3.0, 4.0]]);
    assert_eq!(format!("{}", a), "[ 1.0 22.5]\n[-3.0  4.0]");
    assert_eq!(format!("{}", Matrix::identity(1)), "[1.0]");
}
