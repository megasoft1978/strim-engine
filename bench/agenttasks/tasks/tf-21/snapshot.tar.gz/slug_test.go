package textkit

import "testing"

func TestSlugify(t *testing.T) {
	cases := map[string]string{
		"Hello, World!":      "hello-world",
		"  Leading space":    "leading-space",
		"trailing   dots...": "trailing-dots",
		"a--b__c":            "a-b-c",
		"Caf\u00e9 2024":     "caf\u00e9-2024",
		"!!!":                "",
	}
	for in, want := range cases {
		if got := Slugify(in); got != want {
			t.Errorf("Slugify(%q) = %q, want %q", in, got, want)
		}
	}
}
