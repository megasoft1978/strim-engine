package textkit

import (
	"reflect"
	"testing"
)

func TestSplitCSV(t *testing.T) {
	cases := []struct {
		in   string
		want []string
	}{
		{"a,b,c", []string{"a", "b", "c"}},
		{`a,"b,c",d`, []string{"a", "b,c", "d"}},
		{`"say ""hi""",x`, []string{`say "hi"`, "x"}},
		{"a,,c,", []string{"a", "", "c", ""}},
		{"", []string{""}},
	}
	for _, c := range cases {
		if got := SplitCSV(c.in); !reflect.DeepEqual(got, c.want) {
			t.Errorf("SplitCSV(%q) = %q, want %q", c.in, got, c.want)
		}
	}
}
