package textkit

import (
	"reflect"
	"testing"
)

func TestWrap(t *testing.T) {
	got := Wrap("the quick brown fox jumps", 10)
	want := []string{"the quick", "brown fox", "jumps"}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("Wrap = %q, want %q", got, want)
	}
}

func TestWrapExactFit(t *testing.T) {
	got := Wrap("abc de", 6)
	if want := []string{"abc de"}; !reflect.DeepEqual(got, want) {
		t.Fatalf("Wrap = %q, want %q", got, want)
	}
}

func TestWrapLongWordAndNoWidth(t *testing.T) {
	if got, want := Wrap("a extraordinarily b", 5), []string{"a", "extraordinarily", "b"}; !reflect.DeepEqual(got, want) {
		t.Fatalf("Wrap = %q, want %q", got, want)
	}
	if got, want := Wrap("a  b   c", 0), []string{"a b c"}; !reflect.DeepEqual(got, want) {
		t.Fatalf("Wrap width 0 = %q, want %q", got, want)
	}
}
