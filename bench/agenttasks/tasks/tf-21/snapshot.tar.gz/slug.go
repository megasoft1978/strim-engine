package textkit

import (
	"strings"
	"unicode"
)

// Slugify lowercases s and joins runs of letters/digits with single dashes.
// No leading or trailing dash.
func Slugify(s string) string {
	var b strings.Builder
	dash := false
	for _, r := range strings.ToLower(s) {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			b.WriteRune(r)
			dash = false
		} else if !dash {
			b.WriteByte('-')
			dash = true
		}
	}
	return b.String()
}
