package textkit

import "strings"

// SplitCSV splits one CSV line. Fields may be double-quoted; inside quotes a
// comma is literal and "" is an escaped quote. An empty line is one empty field.
func SplitCSV(line string) []string {
	var out []string
	var cur strings.Builder
	inQ := false
	for i := 0; i < len(line); i++ {
		c := line[i]
		switch {
		case c == '"':
			inQ = !inQ
		case c == ',':
			out = append(out, cur.String())
			cur.Reset()
		default:
			cur.WriteByte(c)
		}
	}
	return append(out, cur.String())
}
