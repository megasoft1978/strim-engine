package textkit

import "strings"

// Wrap greedily wraps s into lines of at most width bytes. A word longer than
// width gets its own line. width <= 0 means no wrapping (one line).
func Wrap(s string, width int) []string {
	words := strings.Fields(s)
	var lines []string
	cur := ""
	for _, w := range words {
		switch {
		case cur == "":
			cur = w
		case len(cur)+1+len(w) < width:
			cur += " " + w
		default:
			lines = append(lines, cur)
			cur = w
		}
	}
	if cur != "" {
		lines = append(lines, cur)
	}
	return lines
}
