// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "Ledger",
    targets: [
        .target(name: "Ledger"),
        .testTarget(name: "LedgerTests", dependencies: ["Ledger"]),
    ]
)
