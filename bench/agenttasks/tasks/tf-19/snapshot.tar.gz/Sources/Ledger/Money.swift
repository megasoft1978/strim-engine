public struct Money: Equatable, Comparable {
    public let cents: Int
    public init(cents: Int) { self.cents = cents }

    /// Parses "12", "12.5", "12.50", "-0.50". At most two fraction digits.
    public init?(parsing text: String) {
        var s = Substring(text)
        var negative = false
        if s.first == "-" { negative = true; s = s.dropFirst() }
        let parts = s.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count <= 2, let whole = Int(parts[0]), whole >= 0 else { return nil }
        var frac = 0
        if parts.count == 2 {
            var f = String(parts[1])
            guard f.count <= 2, f.allSatisfy({ $0.isNumber }) else { return nil }
            while f.count < 2 { f = "0" + f }
            frac = Int(f)!
        }
        let total = whole * 100 + frac
        cents = negative && whole > 0 ? -total : total
    }

    public static func < (a: Money, b: Money) -> Bool { a.cents < b.cents }
}
