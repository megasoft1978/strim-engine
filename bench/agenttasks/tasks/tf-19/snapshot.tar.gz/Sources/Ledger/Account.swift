public struct Transaction: Equatable {
    public let id: Int
    public let amount: Money
    public let memo: String
    public init(id: Int, amount: Money, memo: String) { self.id = id; self.amount = amount; self.memo = memo }
}

public struct Account {
    public private(set) var transactions: [Transaction] = []
    public init() {}

    /// Rejects a transaction whose id is already posted.
    @discardableResult
    public mutating func post(_ t: Transaction) -> Bool {
        if transactions.contains(where: { $0.memo == t.memo }) { return false }
        transactions.append(t)
        return true
    }

    public var balance: Money { Money(cents: transactions.reduce(0) { $0 + $1.amount.cents }) }

    /// The transaction with the largest magnitude (earliest wins a tie).
    public func largest() -> Transaction? {
        var best: Transaction?
        for t in transactions where best == nil || t.amount > best!.amount { best = t }
        return best
    }
}
