public enum Report {
    /// "$1,234.50", "-$0.05".
    public static func format(_ m: Money) -> String {
        let c = abs(m.cents)
        let digits = Array(String(c / 100))
        var grouped = ""
        for (i, ch) in digits.enumerated() {
            if i > 0 && i % 3 == 0 { grouped += "," }
            grouped.append(ch)
        }
        let frac = c % 100
        let f = "\(frac)"
        return (m.cents < 0 ? "-" : "") + "$" + grouped + "." + f
    }

    /// One line per transaction ordered by id, then the balance.
    public static func statement(_ a: Account) -> [String] {
        var lines = a.transactions.map { "\($0.id): \(format($0.amount)) \($0.memo)" }
        lines.append("Balance: " + format(a.balance))
        return lines
    }
}
