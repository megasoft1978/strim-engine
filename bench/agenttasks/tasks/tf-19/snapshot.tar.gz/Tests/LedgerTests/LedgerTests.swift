import XCTest
@testable import Ledger

final class MoneyTests: XCTestCase {
    func testParsesWholeAndFraction() {
        XCTAssertEqual(Money(parsing: "12")?.cents, 1200)
        XCTAssertEqual(Money(parsing: "12.5")?.cents, 1250)
        XCTAssertEqual(Money(parsing: "12.05")?.cents, 1205)
        XCTAssertEqual(Money(parsing: "0.99")?.cents, 99)
    }
    func testNegativeKeepsSignForSubDollar() {
        XCTAssertEqual(Money(parsing: "-3.07")?.cents, -307)
        XCTAssertEqual(Money(parsing: "-0.50")?.cents, -50)
    }
    func testRejectsGarbage() {
        XCTAssertNil(Money(parsing: "1.234"))
        XCTAssertNil(Money(parsing: "1.2.3"))
        XCTAssertNil(Money(parsing: "abc"))
        XCTAssertNil(Money(parsing: "1.x"))
    }
}

final class AccountTests: XCTestCase {
    private func t(_ id: Int, _ s: String, _ memo: String) -> Transaction {
        Transaction(id: id, amount: Money(parsing: s)!, memo: memo)
    }
    func testDuplicateIdRejectedButSameMemoAllowed() {
        var a = Account()
        XCTAssertTrue(a.post(t(1, "5", "coffee")))
        XCTAssertTrue(a.post(t(2, "5", "coffee")))
        XCTAssertFalse(a.post(t(1, "9", "other")))
        XCTAssertEqual(a.transactions.count, 2)
        XCTAssertEqual(a.balance.cents, 1000)
    }
    func testLargestIsByMagnitude() {
        var a = Account()
        a.post(t(1, "10", "a")); a.post(t(2, "-50", "b")); a.post(t(3, "20", "c"))
        XCTAssertEqual(a.largest()?.id, 2)
    }
    func testLargestTieEarliestWins() {
        var a = Account()
        a.post(t(1, "7", "a")); a.post(t(2, "-7", "b"))
        XCTAssertEqual(a.largest()?.id, 1)
        XCTAssertNil(Account().largest())
    }
}

final class ReportTests: XCTestCase {
    func testFormatPadsCents() {
        XCTAssertEqual(Report.format(Money(cents: 505)), "$5.05")
        XCTAssertEqual(Report.format(Money(cents: 550)), "$5.50")
        XCTAssertEqual(Report.format(Money(cents: -5)), "-$0.05")
    }
    func testFormatGroupsThousandsFromTheRight() {
        XCTAssertEqual(Report.format(Money(cents: 123_450)), "$1,234.50")
        XCTAssertEqual(Report.format(Money(cents: 100_000_000)), "$1,000,000.00")
        XCTAssertEqual(Report.format(Money(cents: 99_900)), "$999.00")
    }
    func testStatementOrderedById() {
        var a = Account()
        a.post(Transaction(id: 3, amount: Money(cents: 100), memo: "c"))
        a.post(Transaction(id: 1, amount: Money(cents: -250), memo: "a"))
        XCTAssertEqual(Report.statement(a), ["1: -$2.50 a", "3: $1.00 c", "Balance: -$1.50"])
    }
}
