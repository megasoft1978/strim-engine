export type Ok<T> = { ok: true; value: T };
export type Err<E> = { ok: false; error: E };
export type Result<T, E> = Ok<T> | Err<E>;

export const ok = <T>(value: T): Ok<T> => ({ ok: true, value });
export const err = <E>(error: E): Err<E> => ({ ok: false, error });

/** Applies f to the value of an Ok; an Err passes through unchanged. */
export function map<T, U, E>(r: Result<T, E>, f: (t: T) => U): Result<U, E> {
  if (r.ok) return ok(f(r.value));
  return err(r);
}

/** Chains a fallible step after a successful one. */
export function andThen<T, U, E>(r: Result<T, E>, f: (t: T) => Result<U, E>): Result<U, E> {
  return r.ok ? f(r.value) : r;
}

/** All values when every result is Ok, else the FIRST error. */
export function collect<T, E>(rs: Result<T, E>[]): Result<T[], E> {
  const values: T[] = [];
  let failure: Err<E> | undefined;
  for (const r of rs) {
    if (r.ok) values.push(r.value);
    else failure = r;
  }
  return failure ?? ok(values);
}

/** The value of an Ok, otherwise the fallback (a falsy value such as 0 or "" is still a value). */
export function unwrapOr<T, E>(r: Result<T, E>, fallback: T): T {
  return r.ok && r.value ? r.value : fallback;
}
