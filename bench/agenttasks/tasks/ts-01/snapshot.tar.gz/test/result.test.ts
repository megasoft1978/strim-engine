import test from 'node:test';
import assert from 'node:assert/strict';
import { ok, err, map, andThen, collect, unwrapOr } from '../src/result.ts';

test('map transforms Ok and passes Err through', () => {
  assert.deepEqual(map(ok(2), (n) => n * 3), ok(6));
  assert.deepEqual(map(err('boom'), (n: number) => n * 3), err('boom'));
});

test('andThen chains', () => {
  const half = (n: number) => (n % 2 === 0 ? ok(n / 2) : err('odd'));
  assert.deepEqual(andThen(ok(8), half), ok(4));
  assert.deepEqual(andThen(ok(7), half), err('odd'));
  assert.deepEqual(andThen(err('first'), half), err('first'));
});

test('collect returns the first error', () => {
  assert.deepEqual(collect([ok(1), ok(2)]), ok([1, 2]));
  assert.deepEqual(collect([ok(1), err('a'), err('b')]), err('a'));
  assert.deepEqual(collect([]), ok([]));
});

test('unwrapOr keeps falsy values', () => {
  assert.equal(unwrapOr(ok(0), 9), 0);
  assert.equal(unwrapOr(ok(''), 'x'), '');
  assert.equal(unwrapOr(err('e'), 9), 9);
});
