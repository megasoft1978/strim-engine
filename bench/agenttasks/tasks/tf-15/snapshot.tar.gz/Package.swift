// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "WordWrap",
    targets: [
        .target(name: "WordWrap"),
        .testTarget(name: "WordWrapTests", dependencies: ["WordWrap"]),
    ]
)
