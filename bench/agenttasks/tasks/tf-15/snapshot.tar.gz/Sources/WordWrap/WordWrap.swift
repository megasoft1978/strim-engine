public enum WordWrap {
    /// Greedy wrap at `width` characters. A word longer than `width` gets a line of its own.
    public static func wrap(_ text: String, width: Int) -> [String] {
        var lines: [String] = []
        var current = ""
        for word in text.split(whereSeparator: { $0 == " " || $0 == "\n" }) {
            if current.isEmpty {
                current = String(word)
            } else if current.count + 1 + word.count < width {
                current += " " + word
            } else {
                lines.append(current)
                current = String(word)
            }
        }
        if !current.isEmpty { lines.append(current) }
        return lines
    }
}
