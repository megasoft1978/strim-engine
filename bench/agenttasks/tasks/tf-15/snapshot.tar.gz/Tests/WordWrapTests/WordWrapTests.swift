import XCTest
@testable import WordWrap

final class WordWrapTests: XCTestCase {
    func testSimpleWrap() {
        XCTAssertEqual(WordWrap.wrap("the quick brown fox", width: 10), ["the quick", "brown fox"])
    }

    func testLineExactlyAtWidthIsKept() {
        XCTAssertEqual(WordWrap.wrap("aaaa bbbb cc", width: 9), ["aaaa bbbb", "cc"])
        XCTAssertEqual(WordWrap.wrap("abc def", width: 7), ["abc def"])
    }

    func testLongWordStaysAlone() {
        XCTAssertEqual(WordWrap.wrap("a extraordinarily b", width: 5), ["a", "extraordinarily", "b"])
    }

    func testWhitespaceAndEmpty() {
        XCTAssertEqual(WordWrap.wrap("  one\n\ntwo  ", width: 20), ["one two"])
        XCTAssertEqual(WordWrap.wrap("", width: 5), [])
    }
}
