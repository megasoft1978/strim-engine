import unittest

from pageranges import format_ranges, parse_ranges


class ParseTests(unittest.TestCase):
    def test_single_pages_and_ranges(self):
        self.assertEqual(parse_ranges("1-3,5,7-9"), [1, 2, 3, 5, 7, 8, 9])

    def test_ranges_are_inclusive(self):
        self.assertEqual(parse_ranges("4-4"), [4])
        self.assertEqual(parse_ranges("2-3"), [2, 3])

    def test_duplicates_and_spaces_and_empty_items(self):
        self.assertEqual(parse_ranges(" 3 , 1-2 ,, 2-4 "), [1, 2, 3, 4])
        self.assertEqual(parse_ranges(""), [])

    def test_errors(self):
        for bad in ["a", "3-1", "0", "1-0", "1--2", "-3", "2-"]:
            with self.assertRaises(ValueError, msg=bad):
                parse_ranges(bad)

    def test_max_page(self):
        self.assertEqual(parse_ranges("1-5", max_page=5), [1, 2, 3, 4, 5])
        with self.assertRaises(ValueError):
            parse_ranges("1-6", max_page=5)


class FormatTests(unittest.TestCase):
    def test_format(self):
        self.assertEqual(format_ranges([1, 2, 3, 5, 7, 8]), "1-3,5,7-8")
        self.assertEqual(format_ranges([5, 3, 4, 4]), "3-5")
        self.assertEqual(format_ranges([]), "")

    def test_round_trip(self):
        text = "1-3,6,9-12"
        self.assertEqual(format_ranges(parse_ranges(text)), text)


if __name__ == "__main__":
    unittest.main()
