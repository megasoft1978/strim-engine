"""Page range expressions such as "1-3,5,7-9"."""


def parse_ranges(text, max_page=None):
    """Return the sorted list of distinct page numbers named by `text`.

    Items are separated by commas; each is "N" or "A-B" (inclusive, A <= B). Spaces are ignored.
    Raises ValueError for malformed items, reversed ranges, page 0, or pages above max_page.
    """
    pages = set()
    for item in text.replace(" ", "").split(","):
        if item == "":
            continue
        if "-" in item:
            a, b = item.split("-", 1)
            lo, hi = _num(a), _num(b)
            if lo > hi:
                raise ValueError(f"reversed range: {item}")
            pages.update(range(lo, hi))
        else:
            pages.add(_num(item))
    if max_page is not None and pages and max(pages) > max_page:
        raise ValueError(f"page {max(pages)} is beyond the last page ({max_page})")
    return sorted(pages)


def _num(s):
    if not s.isdigit():
        raise ValueError(f"not a page number: {s!r}")
    n = int(s)
    if n < 1:
        raise ValueError("pages start at 1")
    return n


def format_ranges(pages):
    """Inverse of parse_ranges: [1, 2, 3, 5, 7, 8] -> "1-3,5,7-8"."""
    out = []
    run = []
    for p in sorted(set(pages)):
        if run and p == run[-1] + 1:
            run.append(p)
            continue
        if run:
            out.append(_fmt(run))
        run = [p]
    if run:
        out.append(_fmt(run))
    return ",".join(out)


def _fmt(run):
    return str(run[0]) if len(run) == 1 else f"{run[0]}-{run[-1]}"
