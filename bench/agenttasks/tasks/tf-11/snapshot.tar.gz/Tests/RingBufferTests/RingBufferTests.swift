import XCTest
@testable import RingBuffer

final class RingBufferTests: XCTestCase {
    func testAppendBelowCapacity() {
        var b = RingBuffer<Int>(capacity: 3)
        b.append(1); b.append(2)
        XCTAssertEqual(b.elements, [1, 2])
        XCTAssertEqual(b.count, 2)
        XCTAssertFalse(b.isFull)
    }

    func testOverwriteDropsOldest() {
        var b = RingBuffer<Int>(capacity: 3)
        for i in 1...5 { b.append(i) }
        XCTAssertEqual(b.elements, [3, 4, 5])
        XCTAssertTrue(b.isFull)
        XCTAssertEqual(b.count, 3)
    }

    func testRemoveFirstAfterWrap() {
        var b = RingBuffer<String>(capacity: 2)
        b.append("a"); b.append("b"); b.append("c")
        XCTAssertEqual(b.removeFirst(), "b")
        XCTAssertEqual(b.removeFirst(), "c")
        XCTAssertNil(b.removeFirst())
        XCTAssertTrue(b.isEmpty)
    }

    func testReuseAfterDrain() {
        var b = RingBuffer<Int>(capacity: 2)
        b.append(1); b.append(2); _ = b.removeFirst(); b.append(3); b.append(4)
        XCTAssertEqual(b.elements, [3, 4])
    }
}
