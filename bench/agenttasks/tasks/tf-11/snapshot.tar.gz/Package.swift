// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "RingBuffer",
    targets: [
        .target(name: "RingBuffer"),
        .testTarget(name: "RingBufferTests", dependencies: ["RingBuffer"]),
    ]
)
