/// Fixed-capacity FIFO. Appending to a full buffer overwrites the oldest element.
public struct RingBuffer<Element> {
    private var storage: [Element?]
    private var head = 0
    private var stored = 0
    public let capacity: Int

    public init(capacity: Int) {
        precondition(capacity > 0, "capacity must be positive")
        self.capacity = capacity
        storage = Array(repeating: nil, count: capacity)
    }

    public var count: Int { stored }
    public var isEmpty: Bool { stored == 0 }
    public var isFull: Bool { stored == capacity }

    public mutating func append(_ element: Element) {
        let tail = (head + stored) % capacity
        storage[tail] = element
        if stored < capacity {
            stored += 1
        }
    }

    public mutating func removeFirst() -> Element? {
        guard stored > 0 else { return nil }
        let element = storage[head]
        storage[head] = nil
        head = (head + 1) % capacity
        stored -= 1
        return element
    }

    /// Oldest first.
    public var elements: [Element] {
        (0..<stored).map { storage[(head + $0) % capacity]! }
    }
}
