# Loads every *_test.rb file in this directory: ruby -Ilib -Itest test/all_test.rb
Dir[File.join(__dir__, '*_test.rb')].sort.each { |f| require f unless f == __FILE__ }
