require 'minitest/autorun'
require 'ini'

class IniTest < Minitest::Test
  def test_sections_and_pairs
    cfg = Ini.parse("name = demo\n[db]\nhost = localhost\nport = 5432\n")
    assert_equal 'demo', cfg[''] ['name']
    assert_equal 'localhost', cfg['db']['host']
    assert_equal 5432, cfg['db']['port']
  end

  def test_value_types
    cfg = Ini.parse("[t]\na = true\nb = FALSE\nc = -7\nd = 2.5\ne = text here\n")
    assert_equal({ 'a' => true, 'b' => false, 'c' => -7, 'd' => 2.5, 'e' => 'text here' }, cfg['t'])
  end

  def test_comments_outside_quotes_are_removed
    cfg = Ini.parse("# top\n[a]\nx = 1 # one\ny = 2 ; two\n; whole line\n")
    assert_equal({ 'x' => 1, 'y' => 2 }, cfg['a'])
  end

  def test_hash_inside_quotes_is_kept
    cfg = Ini.parse(%([a]\ncolor = "#ff00ff"\nnote = "a;b" # trailing\n))
    assert_equal '#ff00ff', cfg['a']['color']
    assert_equal 'a;b', cfg['a']['note']
  end

  def test_quoted_numbers_stay_strings
    assert_equal '42', Ini.parse(%([a]\nid = "42"\n))['a']['id']
  end

  def test_repeated_sections_merge
    cfg = Ini.parse("[a]\nx = 1\ny = 2\n[b]\nz = 3\n[a]\ny = 20\nw = 4\n")
    assert_equal({ 'x' => 1, 'y' => 20, 'w' => 4 }, cfg['a'])
    assert_equal ['', 'a', 'b'], cfg.keys
  end

  def test_errors_report_the_line
    err = assert_raises(Ini::ParseError) { Ini.parse("[a]\nx = 1\nnonsense\n") }
    assert_match(/line 3/, err.message)
  end
end
