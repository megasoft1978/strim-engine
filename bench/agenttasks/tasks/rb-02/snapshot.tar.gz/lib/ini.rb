require 'ini/lexer'
require 'ini/parser'

# INI reader: sections, key = value, comments (# or ;), quoted values, typed values.
module Ini
  class ParseError < StandardError; end

  def self.parse(text)
    Parser.new(Lexer.tokenize(text)).parse
  end
end
