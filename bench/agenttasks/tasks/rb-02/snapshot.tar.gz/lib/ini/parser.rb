module Ini
  class Parser
    def initialize(tokens)
      @tokens = tokens
    end

    # => { "" => {global keys}, "section" => {...} }. A section that appears twice is merged, later keys win.
    def parse
      result = { '' => {} }
      current = result['']
      @tokens.each do |t|
        case t.type
        when :section
          result[t.a] = {}
          current = result[t.a]
        when :pair
          current[t.a] = convert(t.b)
        end
      end
      result
    end

    # "quoted" => String, true/false => booleans, 12 => Integer, 1.5 => Float, anything else => String.
    def convert(raw)
      v = raw.strip
      return v[1..-2] if v.start_with?('"') && v.end_with?('"') && v.length >= 2

      case v
      when /\Atrue\z/i then true
      when /\Afalse\z/i then false
      when /\A-?\d+\z/ then v.to_i
      when /\A-?\d+\.\d+\z/ then v.to_f
      else v
      end
    end
  end
end
