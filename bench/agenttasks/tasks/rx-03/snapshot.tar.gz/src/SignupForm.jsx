import { Field } from './Field.jsx';

export function SignupForm({ values = {} }) {
  return (
    <form className="signup" noValidate>
      <Field name="email" label="Email" type="email" value={values.email} />
      <Field name="password" label="Password" type="password" />
      <button type="submit">Create account</button>
    </form>
  );
}
