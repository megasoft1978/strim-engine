export function Field({ name, label, type = 'text', value = '' }) {
  return (
    <div className="field">
      <label htmlFor={name}>{label}</label>
      <input id={name} name={name} type={type} defaultValue={value} />
    </div>
  );
}
