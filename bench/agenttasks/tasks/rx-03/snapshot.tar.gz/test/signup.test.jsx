import { test, expect } from 'bun:test';
import { renderToStaticMarkup } from 'react-dom/server';
import { validate } from '../src/validate.js';
import { Field } from '../src/Field.jsx';
import { SignupForm } from '../src/SignupForm.jsx';

// New behaviour (not implemented yet): src/validate.js, Field error output, SignupForm error summary.

const rules = {
  email: { required: true, pattern: /^[^@\s]+@[^@\s]+\.[^@\s]+$/, message: 'Enter a valid email' },
  password: { required: true, minLength: 8 },
};

test('validate: required fields', () => {
  expect(validate({}, rules)).toEqual({ email: 'Email is required', password: 'Password is required' });
  expect(validate({ email: '  ', password: '' }, rules).email).toBe('Email is required');
});

test('validate: pattern uses the rule message, minLength has a default message', () => {
  expect(validate({ email: 'nope', password: 'short' }, rules)).toEqual({
    email: 'Enter a valid email',
    password: 'Password must be at least 8 characters',
  });
});

test('validate: valid input gives no errors', () => {
  expect(validate({ email: 'a@b.co', password: 'longenough' }, rules)).toEqual({});
});

test('validate: optional empty fields skip other rules', () => {
  expect(validate({ nick: '' }, { nick: { minLength: 3 } })).toEqual({});
  expect(validate({ nick: 'ab' }, { nick: { minLength: 3 } })).toEqual({ nick: 'Nick must be at least 3 characters' });
});

test('Field without an error has no aria-invalid', () => {
  const html = renderToStaticMarkup(<Field name="email" label="Email" />);
  expect(html).not.toContain('aria-invalid');
  expect(html).not.toContain('role="alert"');
});

test('Field with an error links the message and flags the input', () => {
  const html = renderToStaticMarkup(<Field name="email" label="Email" error="Enter a valid email" />);
  expect(html).toContain('aria-invalid="true"');
  expect(html).toContain('aria-describedby="email-error"');
  expect(html).toContain('<p id="email-error" role="alert" class="error">Enter a valid email</p>');
});

test('Field escapes error text', () => {
  const html = renderToStaticMarkup(<Field name="x" label="X" error={'<b>"no"</b>'} />);
  expect(html).toContain('&lt;b&gt;&quot;no&quot;&lt;/b&gt;');
});

test('SignupForm lists errors in a summary and passes them to the fields', () => {
  const errors = { email: 'Email is required', password: 'Password must be at least 8 characters' };
  const html = renderToStaticMarkup(<SignupForm errors={errors} />);
  expect(html).toContain('<div class="summary" role="alert"><p>2 problems</p><ul><li><a href="#email">Email is required</a></li><li><a href="#password">Password must be at least 8 characters</a></li></ul></div>');
  expect(html).toContain('id="password-error"');
});

test('SignupForm with one error says "1 problem"; with none shows no summary', () => {
  expect(renderToStaticMarkup(<SignupForm errors={{ email: 'bad' }} />)).toContain('<p>1 problem</p>');
  expect(renderToStaticMarkup(<SignupForm errors={{}} />)).not.toContain('summary');
  expect(renderToStaticMarkup(<SignupForm />)).not.toContain('summary');
});
