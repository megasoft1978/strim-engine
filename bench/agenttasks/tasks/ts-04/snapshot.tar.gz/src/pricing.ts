import type { Cents, Line, Order } from './model.ts';

/** Money rounding: half away from zero to whole cents. */
export function roundCents(x: number): Cents {
  return Math.sign(x) * Math.round(Math.abs(x));
}

/** Net price of one line after its percent discount, rounded once per line. */
export function lineTotal(l: Line): Cents {
  const gross = l.unitPrice * l.qty;
  const off = gross * ((l.discountPct ?? 0) / 100);
  return roundCents(gross - off);
}

export function subtotal(o: Order): Cents {
  return o.lines.reduce((sum, l) => sum + lineTotal(l), 0);
}

/** Tax on the discounted subtotal, rounded to whole cents. */
export function tax(o: Order): Cents {
  return roundCents((subtotal(o) * o.taxBp) / 10000);
}

export function total(o: Order): Cents {
  return subtotal(o) + tax(o);
}
