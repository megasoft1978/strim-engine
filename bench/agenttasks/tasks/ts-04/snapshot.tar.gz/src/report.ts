import type { Order } from './model.ts';
import { subtotal, tax, total } from './pricing.ts';

export function formatCents(c: number): string {
  const sign = c < 0 ? '-' : '';
  const abs = Math.abs(c);
  const dollars = Math.floor(abs / 100);
  const cents = String(abs % 100).padStart(2, '0');
  return `${sign}$${dollars}.${cents}`;
}

export interface Summary {
  customer: string;
  orders: number;
  spent: number;
}

/** Per customer: order count and total spent, biggest spender first (ties by customer name). */
export function summarize(orders: Order[]): Summary[] {
  const by = new Map<string, Summary>();
  for (const o of orders) {
    const s = by.get(o.customer) ?? { customer: o.customer, orders: 0, spent: 0 };
    s.orders += 1;
    s.spent += total(o);
    by.set(o.customer, s);
  }
  return [...by.values()].sort((a, b) => b.spent - a.spent || a.customer.localeCompare(b.customer));
}

export function receipt(o: Order): string {
  const rows = o.lines.map((l) => `${l.sku} x${l.qty}`);
  rows.push(`subtotal ${formatCents(subtotal(o))}`, `tax ${formatCents(tax(o))}`, `total ${formatCents(total(o))}`);
  return rows.join('\n');
}
