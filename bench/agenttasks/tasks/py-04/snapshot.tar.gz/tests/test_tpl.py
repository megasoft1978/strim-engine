import unittest

from tpl import render
from tpl.filters import escape, truncate
from tpl.lexer import lex
from tpl.render import TemplateError


class Obj:
    def __init__(self, **kw):
        self.__dict__.update(kw)


class LexTests(unittest.TestCase):
    def test_parts(self):
        self.assertEqual(list(lex("a {{ x }} b{{y}}")), [("text", "a "), ("expr", "x"), ("text", " b"), ("expr", "y")])
        self.assertEqual(list(lex("no tags {{ open")), [("text", "no tags {{ open")])


class FilterTests(unittest.TestCase):
    def test_escape_does_not_double_escape_its_own_output(self):
        self.assertEqual(escape('<a href="x">&</a>'), "&lt;a href=&quot;x&quot;&gt;&amp;&lt;/a&gt;")
        self.assertEqual(escape("a & b"), "a &amp; b")

    def test_truncate(self):
        self.assertEqual(truncate("hello", 5), "hello")
        self.assertEqual(truncate("hello world", 5), "hell…")


class RenderTests(unittest.TestCase):
    def test_variables_and_dotted_lookup(self):
        ctx = {"user": {"name": "Ann"}, "obj": Obj(city="Rome")}
        self.assertEqual(render("Hi {{ user.name }} from {{ obj.city }}", ctx), "Hi Ann from Rome")

    def test_missing_renders_empty(self):
        self.assertEqual(render("[{{ nope }}][{{ a.b.c }}]", {"a": {}}), "[][]")

    def test_zero_and_false_are_values_not_missing(self):
        self.assertEqual(render("{{ n }}/{{ f }}", {"n": 0, "f": False}), "0/False")

    def test_autoescape(self):
        self.assertEqual(render("{{ v }}", {"v": "<b>&"}), "&lt;b&gt;&amp;")
        self.assertEqual(render("{{ v }}", {"v": "<b>"}, autoescape=False), "<b>")

    def test_filters_apply_left_to_right(self):
        self.assertEqual(render("{{ s|upper|truncate:4 }}", {"s": "abcdefgh"}), "ABC…")
        self.assertEqual(render("{{ x|default:abcdefgh|truncate:4 }}", {}), "abc…")
        self.assertEqual(render("{{ s|title }}", {"s": "hello big world"}), "Hello Big World")

    def test_default_filter_on_missing_value(self):
        self.assertEqual(render("{{ who|default:nobody }}", {}), "nobody")
        self.assertEqual(render("{{ who|default:nobody }}", {"who": "Bo"}), "Bo")

    def test_unknown_filter(self):
        with self.assertRaises(TemplateError):
            render("{{ x|shout }}", {"x": 1})


if __name__ == "__main__":
    unittest.main()
