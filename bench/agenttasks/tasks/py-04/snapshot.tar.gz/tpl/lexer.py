"""Splits a template into text and {{ expression }} parts."""
import re

_TAG = re.compile(r"\{\{(.*?)\}\}", re.S)


def lex(source):
    """Yield ("text", str) and ("expr", str) pairs. `{{{{` is not special; unmatched `{{` stays text."""
    pos = 0
    for m in _TAG.finditer(source):
        if m.start() > pos:
            yield ("text", source[pos:m.start()])
        yield ("expr", m.group(1).strip())
        pos = m.end()
    if pos < len(source):
        yield ("text", source[pos:])
