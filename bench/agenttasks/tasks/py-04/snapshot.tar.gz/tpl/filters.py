"""Filters usable as {{ name|upper|truncate:5 }}."""


def escape(value):
    s = str(value)
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def upper(value):
    return str(value).upper()


def title(value):
    return str(value).title()


def truncate(value, n):
    s = str(value)
    n = int(n)
    return s if len(s) <= n else s[: n - 1] + "…"


def default(value, fallback):
    return fallback if value in (None, "") else value


FILTERS = {"escape": escape, "upper": upper, "title": title, "truncate": truncate, "default": default}
