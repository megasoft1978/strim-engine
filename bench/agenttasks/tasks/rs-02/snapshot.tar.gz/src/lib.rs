//! A small CSV reader: quoted fields, escaped quotes, CRLF, header-based access.

pub mod field;
pub mod record;

use std::collections::HashMap;

#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    UnterminatedQuote { line: usize },
    RaggedRow { line: usize, expected: usize, found: usize },
    Empty,
}

#[derive(Debug)]
pub struct Table {
    pub headers: Vec<String>,
    pub rows: Vec<Vec<String>>,
}

impl Table {
    /// Parses text whose first record is the header. Every row must have as many fields as the header.
    pub fn parse(text: &str) -> Result<Table, Error> {
        let mut records = record::split_records(text)?;
        if records.is_empty() {
            return Err(Error::Empty);
        }
        let headers = records.remove(0);
        for (i, r) in records.iter().enumerate() {
            if r.len() != headers.len() {
                return Err(Error::RaggedRow { line: i + 2, expected: headers.len(), found: r.len() });
            }
        }
        Ok(Table { headers, rows: records })
    }

    /// Row `i` as a header -> value map.
    pub fn get(&self, i: usize) -> Option<HashMap<&str, &str>> {
        let row = self.rows.get(i)?;
        Some(self.headers.iter().map(|h| h.as_str()).zip(row.iter().map(|v| v.as_str())).collect())
    }

    /// All values of a column, or None for an unknown header.
    pub fn column(&self, name: &str) -> Option<Vec<&str>> {
        let idx = self.headers.iter().position(|h| h == name)?;
        Some(self.rows.iter().map(|r| r[idx].as_str()).collect())
    }
}
