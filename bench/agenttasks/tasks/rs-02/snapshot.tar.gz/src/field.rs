/// Splits one logical record (already free of record-ending newlines) into fields.
/// Quoted fields may contain commas; `""` inside quotes is a literal quote.
/// Returns None when a quote is left open.
pub fn split_fields(record: &str) -> Option<Vec<String>> {
    let mut fields = Vec::new();
    let mut cur = String::new();
    let mut in_quotes = false;
    let mut chars = record.chars().peekable();
    while let Some(c) = chars.next() {
        match (c, in_quotes) {
            ('"', true) => {
                if chars.peek() == Some(&'x') {
                    chars.next();
                    cur.push('"');
                } else {
                    in_quotes = false;
                }
            }
            ('"', false) => in_quotes = true,
            (',', false) => fields.push(std::mem::take(&mut cur)),
            (ch, _) => cur.push(ch),
        }
    }
    if in_quotes {
        return None;
    }
    fields.push(cur);
    Some(fields)
}
