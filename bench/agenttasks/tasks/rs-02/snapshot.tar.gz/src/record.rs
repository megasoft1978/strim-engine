use crate::field::split_fields;
use crate::Error;

/// Splits text into records at newlines that are outside quotes (LF or CRLF), then into fields.
/// A final newline does not create an extra empty record; blank lines in the middle are skipped.
pub fn split_records(text: &str) -> Result<Vec<Vec<String>>, Error> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut in_quotes = false;
    let mut line = 1usize;
    let mut start_line = 1usize;
    for c in text.chars() {
        if c == '"' {
            in_quotes = !in_quotes;
        }
        if c == '\n' {
            line += 1;
            if !in_quotes {
                push_record(&mut out, &mut cur, start_line)?;
                start_line = line;
                continue;
            }
        }
        cur.push(c);
    }
    if in_quotes {
        return Err(Error::UnterminatedQuote { line: start_line });
    }
    push_record(&mut out, &mut cur, start_line)?;
    Ok(out)
}

fn push_record(out: &mut Vec<Vec<String>>, cur: &mut String, line: usize) -> Result<(), Error> {
    let rec = std::mem::take(cur);
    let rec = rec.as_str();
    if rec.is_empty() {
        return Ok(());
    }
    match split_fields(rec) {
        Some(f) => out.push(f),
        None => return Err(Error::UnterminatedQuote { line }),
    }
    Ok(())
}
