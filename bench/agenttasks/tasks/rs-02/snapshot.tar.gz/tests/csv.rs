use minicsv::field::split_fields;
use minicsv::record::split_records;
use minicsv::{Error, Table};

#[test]
fn plain_and_quoted_fields() {
    assert_eq!(split_fields("a,b,c").unwrap(), vec!["a", "b", "c"]);
    assert_eq!(split_fields("\"a,b\",c").unwrap(), vec!["a,b", "c"]);
    assert_eq!(split_fields("a,,c").unwrap(), vec!["a", "", "c"]);
    assert_eq!(split_fields("").unwrap(), vec![""]);
}

#[test]
fn doubled_quotes_are_literal() {
    assert_eq!(split_fields("\"say \"\"hi\"\"\",x").unwrap(), vec!["say \"hi\"", "x"]);
    assert_eq!(split_fields("\"\"\"\"").unwrap(), vec!["\""]);
    assert!(split_fields("\"open").is_none());
}

#[test]
fn records_lf_crlf_and_trailing_newline() {
    assert_eq!(split_records("a,b\n1,2\n").unwrap(), vec![vec!["a", "b"], vec!["1", "2"]]);
    assert_eq!(split_records("a,b\r\n1,2\r\n").unwrap(), vec![vec!["a", "b"], vec!["1", "2"]]);
    assert_eq!(split_records("a\n\n\nb").unwrap(), vec![vec!["a"], vec!["b"]]);
}

#[test]
fn newline_inside_quotes_stays_in_the_field() {
    let r = split_records("id,note\n1,\"line one\nline two\"\n2,ok\n").unwrap();
    assert_eq!(r.len(), 3);
    assert_eq!(r[1][1], "line one\nline two");
}

#[test]
fn escaped_quotes_do_not_confuse_record_splitting() {
    let r = split_records("a,b\n\"x\"\"\ny\",2\n3,4\n").unwrap();
    assert_eq!(r, vec![vec!["a", "b"], vec!["x\"\ny", "2"], vec!["3", "4"]]);
}

#[test]
fn unterminated_quote_reports_the_starting_line() {
    assert_eq!(split_records("a\nb,\"oops\nc\n").unwrap_err(), Error::UnterminatedQuote { line: 2 });
}

#[test]
fn table_access() {
    let t = Table::parse("name,qty\nbolt,10\nnut,25\n").unwrap();
    assert_eq!(t.column("qty").unwrap(), vec!["10", "25"]);
    assert!(t.column("price").is_none());
    assert_eq!(t.get(1).unwrap()["name"], "nut");
    assert!(t.get(2).is_none());
}

#[test]
fn table_errors() {
    assert_eq!(Table::parse("").unwrap_err(), Error::Empty);
    assert_eq!(
        Table::parse("a,b\n1,2\n3\n").unwrap_err(),
        Error::RaggedRow { line: 3, expected: 2, found: 1 }
    );
}
