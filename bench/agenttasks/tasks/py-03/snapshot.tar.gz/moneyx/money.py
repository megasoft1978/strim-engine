from dataclasses import dataclass


@dataclass(frozen=True)
class Money:
    """An amount in minor units (cents) of one currency."""

    cents: int
    currency: str = "USD"

    @classmethod
    def of(cls, amount, currency="USD"):
        """Money.of("12.34") -> Money(1234). Accepts str or int dollars; no floats."""
        if isinstance(amount, float):
            raise TypeError("use a string or int, not float")
        text = str(amount)
        whole, _, frac = text.partition(".")
        frac = (frac + "00")[:2]
        sign = -1 if whole.startswith("-") else 1
        return cls(sign * (abs(int(whole)) * 100 + int(frac)), currency)
