import unittest

from moneyx import Money


# New behaviour: str, add/sub/neg, scalar multiply with rounding, allocate, comparisons.
class MoneyTests(unittest.TestCase):
    def test_of(self):
        self.assertEqual(Money.of("12.34"), Money(1234))
        self.assertEqual(Money.of(5), Money(500))
        self.assertEqual(Money.of("-0.50"), Money(-50))
        with self.assertRaises(TypeError):
            Money.of(1.5)

    def test_str(self):
        self.assertEqual(str(Money(1234)), "USD 12.34")
        self.assertEqual(str(Money(5, "EUR")), "EUR 0.05")
        self.assertEqual(str(Money(-250)), "USD -2.50")
        self.assertEqual(str(Money(0)), "USD 0.00")

    def test_add_sub_neg(self):
        self.assertEqual(Money(100) + Money(250), Money(350))
        self.assertEqual(Money(100) - Money(250), Money(-150))
        self.assertEqual(-Money(100), Money(-100))
        with self.assertRaises(ValueError):
            Money(1) + Money(1, "EUR")

    def test_multiply_rounds_half_even(self):
        self.assertEqual(Money(1000) * 3, Money(3000))
        self.assertEqual(Money(1) * 0.5, Money(0))      # 0.5 -> 0 (even)
        self.assertEqual(Money(3) * 0.5, Money(2))      # 1.5 -> 2 (even)
        self.assertEqual(Money(5) * 0.5, Money(2))      # 2.5 -> 2 (even)
        self.assertEqual(3 * Money(10), Money(30))

    def test_allocate_spreads_the_remainder_front_first(self):
        self.assertEqual(Money(100).allocate(3), [Money(34), Money(33), Money(33)])
        self.assertEqual(sum((m.cents for m in Money(1001).allocate(4)), 0), 1001)
        self.assertEqual(Money(-100).allocate(3), [Money(-34), Money(-33), Money(-33)])
        with self.assertRaises(ValueError):
            Money(100).allocate(0)

    def test_allocate_by_ratios(self):
        self.assertEqual(Money(100).allocate_ratios([1, 1, 1]), [Money(34), Money(33), Money(33)])
        self.assertEqual(Money(1000).allocate_ratios([70, 30]), [Money(700), Money(300)])
        self.assertEqual(sum(m.cents for m in Money(5).allocate_ratios([3, 7])), 5)

    def test_ordering_requires_same_currency(self):
        self.assertTrue(Money(1) < Money(2))
        self.assertTrue(Money(2) >= Money(2))
        with self.assertRaises(ValueError):
            Money(1) < Money(2, "EUR")

    def test_is_zero_and_abs(self):
        self.assertTrue(Money(0).is_zero())
        self.assertEqual(abs(Money(-7)), Money(7))


if __name__ == "__main__":
    unittest.main()
