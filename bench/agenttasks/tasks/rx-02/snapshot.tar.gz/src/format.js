/** 1999 -> "$19.99"; negative amounts keep the sign in front: -250 -> "-$2.50". */
export function formatPrice(cents) {
  const sign = cents < 0 ? '-' : '';
  const abs = Math.abs(cents);
  const dollars = Math.floor(abs / 100);
  const rest = abs % 100;
  return `${sign}$${dollars}.${rest}`;
}

/** "3 items", "1 item", "no items". */
export function itemCount(n) {
  if (n === 0) return 'no items';
  return n === 1 ? '1 item' : `${n} items`;
}
