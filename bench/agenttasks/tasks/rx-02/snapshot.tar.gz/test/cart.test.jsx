import { test, expect } from 'bun:test';
import { renderToStaticMarkup } from 'react-dom/server';
import { formatPrice, itemCount } from '../src/format.js';
import { Cart, cartTotal } from '../src/Cart.jsx';
import { CartRow } from '../src/CartRow.jsx';

const pen = { sku: 'p1', name: 'Pen', price: 250, qty: 3 };
const ink = { sku: 'i1', name: 'Ink', price: 1999, qty: 1 };

test('formatPrice pads cents', () => {
  expect(formatPrice(1999)).toBe('$19.99');
  expect(formatPrice(5)).toBe('$0.05');
  expect(formatPrice(100)).toBe('$1.00');
  expect(formatPrice(-250)).toBe('-$2.50');
});

test('itemCount', () => {
  expect(itemCount(0)).toBe('no items');
  expect(itemCount(1)).toBe('1 item');
  expect(itemCount(4)).toBe('4 items');
});

test('a row shows price times quantity', () => {
  const html = renderToStaticMarkup(<table><tbody><CartRow item={pen} /></tbody></table>);
  expect(html).toContain('<td class="total">$7.50</td>');
  expect(html).toContain('<td class="qty">3</td>');
});

test('cartTotal sums lines', () => {
  expect(cartTotal([pen, ink])).toBe(2749);
  expect(cartTotal([])).toBe(0);
});

test('cart with items renders rows and the grand total', () => {
  const html = renderToStaticMarkup(<Cart items={[pen, ink]} />);
  expect(html).toContain('Cart (4 items)');
  expect(html).toContain('<td class="grand">$27.49</td>');
  expect(html).not.toContain('empty');
});

test('an empty cart shows the message and no stray zero', () => {
  const html = renderToStaticMarkup(<Cart items={[]} />);
  expect(html).toBe('<section class="cart"><h2>Cart (no items)</h2><p class="empty">Your cart is empty.</p></section>');
});
