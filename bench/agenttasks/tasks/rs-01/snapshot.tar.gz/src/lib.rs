//! Closed integer intervals: merging and set arithmetic.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Interval {
    pub start: i64,
    pub end: i64,
}

impl Interval {
    pub fn new(start: i64, end: i64) -> Option<Interval> {
        if start <= end {
            Some(Interval { start, end })
        } else {
            None
        }
    }

    pub fn len(&self) -> i64 {
        self.end - self.start
    }

    pub fn contains(&self, x: i64) -> bool {
        self.start <= x && x < self.end
    }

    /// True when the two intervals share at least one integer point.
    pub fn overlaps(&self, other: &Interval) -> bool {
        self.start <= other.end && other.start <= self.end
    }
}

/// Merges overlapping or directly adjacent intervals (1..=3 and 4..=6 become 1..=6). The result is sorted.
pub fn merge(mut items: Vec<Interval>) -> Vec<Interval> {
    items.sort_by_key(|i| i.end);
    let mut out: Vec<Interval> = Vec::new();
    for it in items {
        match out.last_mut() {
            Some(last) if it.start <= last.end => {
                last.end = last.end.max(it.end);
            }
            _ => out.push(it),
        }
    }
    out
}

/// Total number of integer points covered by the (possibly overlapping) intervals.
pub fn covered(items: &[Interval]) -> i64 {
    merge(items.to_vec()).iter().map(|i| i.len()).sum()
}
