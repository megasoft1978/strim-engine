use intervals::{covered, merge, Interval};

fn iv(a: i64, b: i64) -> Interval {
    Interval::new(a, b).unwrap()
}

#[test]
fn new_rejects_reversed() {
    assert!(Interval::new(5, 4).is_none());
    assert_eq!(Interval::new(3, 3), Some(Interval { start: 3, end: 3 }));
}

#[test]
fn closed_interval_semantics() {
    let i = iv(2, 5);
    assert_eq!(i.len(), 4); // points 2,3,4,5
    assert!(i.contains(2) && i.contains(5));
    assert!(!i.contains(6) && !i.contains(1));
    assert!(iv(1, 3).overlaps(&iv(3, 6)));
    assert!(!iv(1, 3).overlaps(&iv(4, 6)));
}

#[test]
fn merge_overlapping_and_adjacent() {
    let m = merge(vec![iv(8, 10), iv(1, 3), iv(2, 6), iv(4, 5), iv(7, 7)]);
    assert_eq!(m, vec![iv(1, 10)]);
    assert_eq!(merge(vec![iv(5, 6), iv(1, 3)]), vec![iv(1, 3), iv(5, 6)]);
}

#[test]
fn merge_is_sorted_and_handles_nested() {
    let m = merge(vec![iv(20, 30), iv(0, 100), iv(5, 6)]);
    assert_eq!(m, vec![iv(0, 100)]);
    assert!(merge(vec![]).is_empty());
}

#[test]
fn covered_counts_points_once() {
    assert_eq!(covered(&[iv(1, 3), iv(2, 4)]), 4);
    assert_eq!(covered(&[iv(1, 1), iv(5, 5)]), 2);
}
