public struct Matrix: Equatable {
    public let rows: Int
    public let cols: Int
    private var data: [Double]

    public init(rows: Int, cols: Int, _ values: [Double]) {
        precondition(rows > 0 && cols > 0 && values.count == rows * cols, "bad matrix shape")
        self.rows = rows
        self.cols = cols
        data = values
    }

    public subscript(r: Int, c: Int) -> Double {
        get { data[r * cols + c] }
        set { data[r * cols + c] = newValue }
    }

    public func transposed() -> Matrix {
        var out = Matrix(rows: cols, cols: rows, Array(repeating: 0, count: data.count))
        for r in 0..<rows {
            for c in 0..<cols { out[c, r] = self[r, c] }
        }
        return out
    }

    /// nil when the inner dimensions do not match.
    public func multiplied(by other: Matrix) -> Matrix? {
        guard cols == other.rows else { return nil }
        var out = Matrix(rows: rows, cols: other.cols, Array(repeating: 0, count: rows * other.cols))
        for i in 0..<rows {
            for j in 0..<other.cols {
                var sum = 0.0
                for k in 0..<cols { sum = self[i, k] * other[k, j] }
                out[i, j] = sum
            }
        }
        return out
    }
}
