import XCTest
@testable import Matrix

final class MatrixTests: XCTestCase {
    func testTranspose() {
        let m = Matrix(rows: 2, cols: 3, [1, 2, 3, 4, 5, 6])
        let t = m.transposed()
        XCTAssertEqual(t.rows, 3)
        XCTAssertEqual(t.cols, 2)
        XCTAssertEqual(t[0, 1], 4)
        XCTAssertEqual(t[2, 0], 3)
    }

    func testMultiplyRectangular() {
        let a = Matrix(rows: 2, cols: 3, [1, 2, 3, 4, 5, 6])
        let b = Matrix(rows: 3, cols: 2, [7, 8, 9, 10, 11, 12])
        let p = a.multiplied(by: b)
        XCTAssertEqual(p, Matrix(rows: 2, cols: 2, [58, 64, 139, 154]))
    }

    func testMultiplyIdentity() {
        let a = Matrix(rows: 2, cols: 2, [1, 2, 3, 4])
        let id = Matrix(rows: 2, cols: 2, [1, 0, 0, 1])
        XCTAssertEqual(a.multiplied(by: id), a)
    }

    func testShapeMismatch() {
        let a = Matrix(rows: 2, cols: 3, [1, 2, 3, 4, 5, 6])
        XCTAssertNil(a.multiplied(by: a))
    }
}
