package inventory;

public final class Item {
    public final String sku;
    public final String category;
    public final int quantity;

    public Item(String sku, String category, int quantity) {
        if (quantity < 0) throw new IllegalArgumentException("negative quantity");
        this.sku = sku;
        this.category = category;
        this.quantity = quantity;
    }

    public Item withQuantity(int q) {
        return new Item(sku, category, q);
    }

    @Override
    public String toString() {
        return sku + "x" + quantity;
    }
}
