package inventory;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public final class Inventory {
    private final Map<String, Item> items = new LinkedHashMap<>();

    public void add(Item item) {
        items.put(item.sku, item);
    }

    public Optional<Item> find(String sku) {
        return Optional.ofNullable(items.get(sku));
    }

    public int size() {
        return items.size();
    }
}
