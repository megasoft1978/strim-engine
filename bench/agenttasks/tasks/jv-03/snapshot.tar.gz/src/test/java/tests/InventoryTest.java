package tests;

import static mini.Assert.*;

import inventory.Inventory;
import inventory.Item;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// New behaviour: remove, restock, lowStock, totalByCategory, take. Existing: add, find, size.
public class InventoryTest {
    private static Inventory sample() {
        Inventory inv = new Inventory();
        inv.add(new Item("bolt", "hardware", 40));
        inv.add(new Item("nut", "hardware", 5));
        inv.add(new Item("glue", "supplies", 0));
        inv.add(new Item("tape", "supplies", 12));
        return inv;
    }

    private static List<String> skus(List<Item> items) {
        return items.stream().map(i -> i.sku).collect(Collectors.toList());
    }

    public void testRemove() {
        Inventory inv = sample();
        assertTrue(inv.remove("nut").isPresent());
        assertEquals(3, inv.size());
        assertFalse(inv.remove("nut").isPresent());
    }

    public void testRestockAddsToExistingAndRejectsUnknown() {
        Inventory inv = sample();
        assertEquals(45, inv.restock("bolt", 5).quantity);
        assertEquals(45, inv.find("bolt").get().quantity);
        assertThrows(IllegalArgumentException.class, () -> inv.restock("zzz", 1));
        assertThrows(IllegalArgumentException.class, () -> inv.restock("bolt", 0));
    }

    public void testTakeReducesStockAndNeverGoesNegative() {
        Inventory inv = sample();
        assertEquals(2, inv.take("nut", 3).quantity);
        assertThrows(IllegalStateException.class, () -> inv.take("nut", 3));
        assertEquals(2, inv.find("nut").get().quantity);
    }

    public void testLowStockIsStrictlyBelowThresholdSortedBySku() {
        Inventory inv = sample();
        assertEquals(Arrays.asList("glue", "nut"), skus(inv.lowStock(12)));
        assertEquals(Arrays.asList("glue"), skus(inv.lowStock(5)));
        assertEquals(0, inv.lowStock(0).size());
    }

    public void testTotalByCategoryKeepsFirstSeenOrder() {
        Map<String, Integer> totals = sample().totalByCategory();
        assertEquals(Arrays.asList("hardware", "supplies"), Arrays.asList(totals.keySet().toArray()));
        assertEquals(45, (long) totals.get("hardware"));
        assertEquals(12, (long) totals.get("supplies"));
    }
}
