package textwrap;

import java.util.ArrayList;
import java.util.List;

/** Greedy word wrapping. */
public final class Wrapper {
    private Wrapper() {}

    /**
     * Breaks text into lines of at most {@code width} characters, splitting on whitespace.
     * A word longer than width is placed on its own line unchanged. Runs of whitespace collapse to one space.
     * Existing blank-line paragraph breaks (an empty line) are kept as one empty line in the output.
     */
    public static List<String> wrap(String text, int width) {
        if (width < 1) throw new IllegalArgumentException("width must be >= 1");
        List<String> lines = new ArrayList<>();
        for (String para : text.split("\n\\s*\n", -1)) {
            if (!lines.isEmpty()) lines.add("");
            StringBuilder cur = new StringBuilder();
            for (String word : para.trim().split("\\s+")) {
                if (word.isEmpty()) continue;
                if (cur.length() == 0) {
                    cur.append(word);
                } else if (cur.length() + 1 + word.length() < width) {
                    cur.append(' ').append(word);
                } else {
                    lines.add(cur.toString());
                    cur = new StringBuilder(word);
                }
            }
            if (cur.length() > 0) lines.add(cur.toString());
        }
        return lines;
    }

    /** Left-pads every line with the given indent (empty lines stay empty). */
    public static List<String> indent(List<String> lines, int spaces) {
        String pad = " ".repeat(spaces);
        List<String> out = new ArrayList<>();
        for (String l : lines) out.add(l.isEmpty() ? l : pad + l);
        return out;
    }
}
