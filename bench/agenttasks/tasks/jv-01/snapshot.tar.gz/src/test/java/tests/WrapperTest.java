package tests;

import static mini.Assert.*;

import java.util.Arrays;
import java.util.List;
import textwrap.Wrapper;

public class WrapperTest {
    public void testFitsExactlyOnALine() {
        assertEquals(Arrays.asList("aaa bbb"), Wrapper.wrap("aaa bbb", 7));
    }

    public void testWrapsAtWidth() {
        assertEquals(Arrays.asList("the quick", "brown fox", "jumps"), Wrapper.wrap("the quick brown fox jumps", 9));
    }

    public void testLongWordGetsItsOwnLine() {
        assertEquals(Arrays.asList("a", "extraordinarily", "b"), Wrapper.wrap("a extraordinarily b", 5));
    }

    public void testWhitespaceCollapses() {
        assertEquals(Arrays.asList("a b c"), Wrapper.wrap("  a \t b\n c  ", 10));
    }

    public void testParagraphsKeepOneBlankLine() {
        List<String> got = Wrapper.wrap("one two\n\n\nthree four", 7);
        assertEquals(Arrays.asList("one two", "", "three", "four"), got);
    }

    public void testEmptyInput() {
        assertEquals(0, Wrapper.wrap("", 10).size());
        assertEquals(0, Wrapper.wrap("   ", 10).size());
    }

    public void testBadWidth() {
        assertThrows(IllegalArgumentException.class, () -> Wrapper.wrap("x", 0));
    }

    public void testIndentSkipsBlankLines() {
        assertEquals(Arrays.asList("  a", "", "  b"), Wrapper.indent(Arrays.asList("a", "", "b"), 2));
    }
}
