import XCTest
@testable import CSV

final class CSVTests: XCTestCase {
    func testPlain() {
        XCTAssertEqual(CSV.parseLine("a,b,c"), ["a", "b", "c"])
    }

    func testEmptyFields() {
        XCTAssertEqual(CSV.parseLine("a,,c,"), ["a", "", "c", ""])
        XCTAssertEqual(CSV.parseLine(""), [""])
    }

    func testQuotedComma() {
        XCTAssertEqual(CSV.parseLine("\"a,b\",c"), ["a,b", "c"])
    }

    func testEscapedQuote() {
        XCTAssertEqual(CSV.parseLine("\"say \"\"hi\"\"\",x"), ["say \"hi\"", "x"])
        XCTAssertEqual(CSV.parseLine("\"\"\"\""), ["\""])
    }
}
