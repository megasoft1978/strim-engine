// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "CSV",
    targets: [
        .target(name: "CSV"),
        .testTarget(name: "CSVTests", dependencies: ["CSV"]),
    ]
)
