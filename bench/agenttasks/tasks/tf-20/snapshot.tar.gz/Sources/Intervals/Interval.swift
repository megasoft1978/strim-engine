public struct Interval: Equatable {
    public let start: Int
    public let end: Int

    /// Half-open [start, end). Empty intervals (start == end) are allowed; start > end is not.
    public init?(_ start: Int, _ end: Int) {
        guard start < end else { return nil }
        self.start = start; self.end = end
    }

    public var length: Int { end - start }

    /// Share at least one point of positive length.
    public func overlaps(_ o: Interval) -> Bool { start <= o.end && o.start <= end }

    /// Overlap or are adjacent (end of one == start of the other).
    public func touches(_ o: Interval) -> Bool { start <= o.end && o.start <= end }
}
