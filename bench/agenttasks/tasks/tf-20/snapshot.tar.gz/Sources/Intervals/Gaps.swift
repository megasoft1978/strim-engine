public enum Gaps {
    /// Non-empty free slots inside `window` that no busy interval covers, in order.
    public static func free(within window: Interval, busy: [Interval]) -> [Interval] {
        var out: [Interval] = []
        var cursor = window.start
        for b in Merge.merge(busy) {
            if b.end <= window.start { continue }
            if b.start >= window.end { break }
            if b.start > cursor { out.append(Interval(cursor, b.start)!) }
            cursor = b.end
        }
        if cursor <= window.end { out.append(Interval(cursor, window.end)!) }
        return out
    }
}
