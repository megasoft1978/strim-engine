public enum Merge {
    /// Sorted, non-touching union of the input.
    public static func merge(_ xs: [Interval]) -> [Interval] {
        var out: [Interval] = []
        for x in xs {
            if let last = out.last, last.touches(x) {
                out[out.count - 1] = Interval(last.start, x.end)!
            } else {
                out.append(x)
            }
        }
        return out
    }

    public static func totalLength(_ xs: [Interval]) -> Int { merge(xs).reduce(0) { $0 + $1.length } }
}
