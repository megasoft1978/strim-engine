import XCTest
@testable import Intervals

private func iv(_ a: Int, _ b: Int) -> Interval { Interval(a, b)! }

final class IntervalTests: XCTestCase {
    func testInitRules() {
        XCTAssertNil(Interval(5, 4))
        XCTAssertNotNil(Interval(3, 3))
        XCTAssertEqual(iv(3, 3).length, 0)
    }
    func testOverlapsIsStrictTouchesIsNot() {
        XCTAssertFalse(iv(1, 3).overlaps(iv(3, 5)))
        XCTAssertTrue(iv(1, 3).touches(iv(3, 5)))
        XCTAssertTrue(iv(1, 4).overlaps(iv(3, 5)))
        XCTAssertFalse(iv(1, 2).touches(iv(3, 5)))
    }
}

final class MergeTests: XCTestCase {
    func testSortsBeforeMerging() {
        XCTAssertEqual(Merge.merge([iv(8, 10), iv(1, 3), iv(2, 5)]), [iv(1, 5), iv(8, 10)])
    }
    func testAdjacentIntervalsMerge() {
        XCTAssertEqual(Merge.merge([iv(1, 3), iv(3, 5)]), [iv(1, 5)])
    }
    func testContainedIntervalDoesNotShrinkEnd() {
        XCTAssertEqual(Merge.merge([iv(1, 10), iv(2, 4), iv(9, 12)]), [iv(1, 12)])
        XCTAssertEqual(Merge.merge([iv(1, 10), iv(2, 4)]), [iv(1, 10)])
    }
    func testTotalLength() {
        XCTAssertEqual(Merge.totalLength([iv(0, 4), iv(2, 6), iv(10, 11)]), 7)
        XCTAssertEqual(Merge.totalLength([]), 0)
    }
}

final class GapsTests: XCTestCase {
    func testFreeSlots() {
        let g = Gaps.free(within: iv(0, 24), busy: [iv(9, 12), iv(10, 11), iv(14, 15)])
        XCTAssertEqual(g, [iv(0, 9), iv(12, 14), iv(15, 24)])
    }
    func testNoEmptyTrailingOrLeadingSlot() {
        XCTAssertEqual(Gaps.free(within: iv(0, 10), busy: [iv(0, 3), iv(7, 10)]), [iv(3, 7)])
        XCTAssertEqual(Gaps.free(within: iv(0, 10), busy: [iv(0, 10)]), [])
    }
    func testBusyOutsideWindowIgnored() {
        XCTAssertEqual(Gaps.free(within: iv(5, 10), busy: [iv(0, 4), iv(12, 20), iv(4, 6)]), [iv(6, 10)])
    }
    func testUnsortedBusy() {
        XCTAssertEqual(Gaps.free(within: iv(0, 10), busy: [iv(6, 8), iv(1, 2)]), [iv(0, 1), iv(2, 6), iv(8, 10)])
    }
}
