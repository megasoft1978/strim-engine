from .filters import FILTERS, escape
from .lexer import lex


class TemplateError(Exception):
    pass


def _lookup(name, context):
    """Dotted lookup: user.name -> context["user"]["name"] (dict keys or attributes). Missing -> None."""
    cur = context
    for part in name.split("."):
        if isinstance(cur, dict):
            cur = cur.get(part)
        else:
            cur = getattr(cur, part, None)
        if cur is None:
            return None
    return cur


def _evaluate(expr, context):
    parts = [p.strip() for p in expr.split("|")]
    value = _lookup(parts[0], context)
    for f in reversed(parts[1:]):
        name, _, arg = f.partition(":")
        fn = FILTERS.get(name.strip())
        if fn is None:
            raise TemplateError(f"unknown filter {name.strip()!r}")
        value = fn(value, arg.strip()) if arg else fn(value)
    return value


def render(source, context, autoescape=True):
    """Render `source`. Values are HTML-escaped unless autoescape is False; missing names render as ''."""
    out = []
    for kind, text in lex(source):
        if kind == "text":
            out.append(text)
            continue
        value = _evaluate(text, context)
        if value is None:
            continue
        out.append(escape(value) if autoescape else str(value))
    return "".join(out)
