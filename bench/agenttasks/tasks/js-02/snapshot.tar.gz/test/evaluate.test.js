'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { evaluate } = require('../lib/evaluate.js');
const { tokenize } = require('../lib/tokenize.js');

test('basic arithmetic and precedence', () => {
  assert.equal(evaluate('1 + 2 * 3'), 7);
  assert.equal(evaluate('(1 + 2) * 3'), 9);
  assert.equal(evaluate('10 - 4 - 3'), 3);
  assert.equal(evaluate('100 / 10 / 5'), 2);
});

test('decimals', () => {
  assert.equal(evaluate('1.5 + 2.25'), 3.75);
  assert.equal(evaluate('.5 * 4'), 2);
  assert.deepEqual(tokenize('3.14'), [{ type: 'num', value: 3.14 }]);
});

test('exponent is right associative and binds tighter than unary minus', () => {
  assert.equal(evaluate('2 ^ 3 ^ 2'), 512);
  assert.equal(evaluate('-2 ^ 2'), -4);
  assert.equal(evaluate('(-2) ^ 2'), 4);
  assert.equal(evaluate('2 * -3'), -6);
});

test('unary minus', () => {
  assert.equal(evaluate('-5 + 2'), -3);
  assert.equal(evaluate('--4'), 4);
  assert.equal(evaluate('3 - -3'), 6);
});

test('errors', () => {
  assert.throws(() => evaluate('1 / 0'), RangeError);
  assert.throws(() => evaluate('1 + '), SyntaxError);
  assert.throws(() => evaluate('(1 + 2'), SyntaxError);
  assert.throws(() => evaluate('2 $ 3'), SyntaxError);
});
