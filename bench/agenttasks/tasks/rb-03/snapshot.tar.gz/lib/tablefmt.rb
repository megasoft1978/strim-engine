# Plain-text tables.
class TableFmt
  attr_reader :headers, :rows

  def initialize(headers)
    @headers = headers.map(&:to_s)
    @rows = []
  end

  def <<(row)
    raise ArgumentError, "expected #{@headers.size} cells, got #{row.size}" unless row.size == @headers.size

    @rows << row.map(&:to_s)
    self
  end
end
