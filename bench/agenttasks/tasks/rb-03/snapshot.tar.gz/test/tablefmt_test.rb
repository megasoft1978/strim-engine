require 'minitest/autorun'
require 'tablefmt'

# New behaviour: widths, align:, to_s, to_markdown, sort_by!, max_width truncation.
class TableFmtTest < Minitest::Test
  def table
    TableFmt.new(%w[name qty price]).tap do |t|
      t << ['bolt', 40, 0.25]
      t << ['nut', 5, 0.1]
      t << ['washer', 1200, 0.05]
    end
  end

  def test_widths_cover_headers_and_cells
    assert_equal [6, 4, 5], table.widths
  end

  def test_to_s_left_aligns_by_default
    expected = <<~TXT.chomp
      name   qty  price
      ------ ---- -----
      bolt   40   0.25
      nut    5    0.1
      washer 1200 0.05
    TXT
    assert_equal expected, table.to_s
  end

  def test_right_alignment_per_column
    t = table
    t.align(qty: :right, price: :right)
    expected = <<~TXT.chomp
      name    qty price
      ------ ---- -----
      bolt     40  0.25
      nut       5   0.1
      washer 1200  0.05
    TXT
    assert_equal expected, t.to_s
  end

  def test_unknown_column_in_align
    assert_raises(KeyError) { table.align(nope: :left) }
    assert_raises(ArgumentError) { table.align(qty: :middle) }
  end

  def test_markdown
    t = table
    t.align(qty: :right)
    expected = <<~TXT.chomp
      | name   |  qty | price |
      |:-------|-----:|:------|
      | bolt   |   40 | 0.25  |
      | nut    |    5 | 0.1   |
      | washer | 1200 | 0.05  |
    TXT
    assert_equal expected, t.to_markdown
  end

  def test_markdown_escapes_pipes
    t = TableFmt.new(%w[a])
    t << ['x|y']
    assert_includes t.to_markdown, 'x\\|y'
  end

  def test_sort_by_numeric_column_is_stable_and_chainable
    t = table
    assert_same t, t.sort_by!('qty') { |v| v.to_i }
    assert_equal %w[nut bolt washer], t.rows.map(&:first)
    t.sort_by!('name')
    assert_equal %w[bolt nut washer], t.rows.map(&:first)
  end

  def test_max_width_truncates_with_ellipsis
    t = TableFmt.new(%w[text])
    t << ['abcdefghij']
    t << ['abc']
    assert_equal ['abcdefg…', 'abc'], t.to_s(max_width: 8).lines.map(&:chomp).drop(2)
  end
end
