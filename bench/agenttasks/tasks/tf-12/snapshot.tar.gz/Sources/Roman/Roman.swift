public enum Roman {
    static let table: [(value: Int, numeral: String)] = [
        (1000, "M"), (500, "D"), (400, "CD"),
        (100, "C"), (90, "XC"), (50, "L"), (40, "XL"),
        (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I"),
    ]

    /// 1...3999 only.
    public static func encode(_ number: Int) -> String? {
        guard (1...3999).contains(number) else { return nil }
        var rest = number
        var out = ""
        for (value, numeral) in table {
            while rest >= value {
                out += numeral
                rest -= value
            }
        }
        return out
    }

    /// Accepts only canonical numerals ("IIII" and "IC" are invalid).
    public static func decode(_ text: String) -> Int? {
        let values: [Character: Int] = ["I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000]
        var total = 0
        var previous = 0
        for ch in text.reversed() {
            guard let v = values[ch] else { return nil }
            if v < previous {
                total -= v
            } else {
                total += v
                previous = v
            }
        }
        return total > 0 && encode(total) == text ? total : nil
    }
}
