import XCTest
@testable import Roman

final class RomanTests: XCTestCase {
    func testEncodeBasics() {
        XCTAssertEqual(Roman.encode(1), "I")
        XCTAssertEqual(Roman.encode(4), "IV")
        XCTAssertEqual(Roman.encode(9), "IX")
        XCTAssertEqual(Roman.encode(14), "XIV")
        XCTAssertEqual(Roman.encode(40), "XL")
        XCTAssertEqual(Roman.encode(90), "XC")
    }

    func testEncodeHundreds() {
        XCTAssertEqual(Roman.encode(400), "CD")
        XCTAssertEqual(Roman.encode(900), "CM")
        XCTAssertEqual(Roman.encode(1994), "MCMXCIV")
        XCTAssertEqual(Roman.encode(3999), "MMMCMXCIX")
    }

    func testRange() {
        XCTAssertNil(Roman.encode(0))
        XCTAssertNil(Roman.encode(4000))
    }

    func testRoundTrip() {
        for n in 1...3999 { XCTAssertEqual(Roman.decode(Roman.encode(n)!), n) }
    }

    func testRejectsNonCanonical() {
        XCTAssertNil(Roman.decode("IIII"))
        XCTAssertNil(Roman.decode("IC"))
        XCTAssertNil(Roman.decode("ABC"))
        XCTAssertNil(Roman.decode(""))
    }
}
