// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "Roman",
    targets: [
        .target(name: "Roman"),
        .testTarget(name: "RomanTests", dependencies: ["Roman"]),
    ]
)
