import { formatPrice } from './format.js';

export function CartRow({ item }) {
  const lineTotal = item.price * item.qty;
  return (
    <tr data-sku={item.sku}>
      <td className="name">{item.name}</td>
      <td className="qty">{item.qty}</td>
      <td className="price">{formatPrice(item.price)}</td>
      <td className="total">{formatPrice(lineTotal)}</td>
    </tr>
  );
}
