import { CartRow } from './CartRow.jsx';
import { formatPrice, itemCount } from './format.js';

export function cartTotal(items) {
  return items.reduce((sum, it) => sum + it.price * it.qty, 0);
}

export function Cart({ items }) {
  const count = items.reduce((n, it) => n + it.qty, 0);
  return (
    <section className="cart">
      <h2>Cart ({itemCount(count)})</h2>
      {items.length > 0 && (
        <table>
          <tbody>
            {items.map((it) => (
              <CartRow key={it.sku} item={it} />
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td colSpan={3}>Total</td>
              <td className="grand">{formatPrice(cartTotal(items))}</td>
            </tr>
          </tfoot>
        </table>
      )}
      {items.length === 0 && <p className="empty">Your cart is empty.</p>}
    </section>
  );
}
