module Ini
  Token = Struct.new(:type, :a, :b, :line)

  # Turns text into [:section, name], [:pair, key, raw_value] tokens. Blank lines and comments are dropped.
  module Lexer
    module_function

    def tokenize(text)
      text.each_line.with_index(1).filter_map do |raw, line|
        s = strip_comment(raw.chomp).strip
        next if s.empty?

        if (m = s.match(/\A\[([^\]]+)\]\z/))
          Token.new(:section, m[1].strip, nil, line)
        elsif (m = s.match(/\A([^=]+?)\s*=\s*(.*)\z/))
          Token.new(:pair, m[1].strip, m[2], line)
        else
          raise Ini::ParseError, "line #{line}: cannot parse #{s.inspect}"
        end
      end
    end

    # Removes a trailing comment that starts with # or ; outside double quotes.
    def strip_comment(s)
      in_quotes = false
      s.each_char.with_index do |c, i|
        in_quotes = !in_quotes if c == '"'
        return s[0...i] if (c == "#" || c == ";") && !in_quotes
      end
      s
    end
  end
end
