import XCTest
@testable import Calc

final class LexerTests: XCTestCase {
    func testDecimalsAndOperators() throws {
        XCTAssertEqual(try Lexer.tokens("1.5+2"), [.num(1.5), .plus, .num(2)])
        XCTAssertEqual(try Lexer.tokens("(3)^2"), [.lparen, .num(3), .rparen, .caret, .num(2)])
    }
    func testBadCharacter() {
        XCTAssertThrowsError(try Lexer.tokens("2 $ 3"))
        XCTAssertThrowsError(try Lexer.tokens("1.2.3"))
    }
}

final class ParserTests: XCTestCase {
    private func p(_ s: String) throws -> Expr { try Parser.parse(try Lexer.tokens(s)) }
    func testSubtractionIsLeftAssociative() throws {
        XCTAssertEqual(try p("10-4-3"), .bin("-", .bin("-", .num(10), .num(4)), .num(3)))
    }
    func testDivisionIsLeftAssociative() throws {
        XCTAssertEqual(try p("8/4/2"), .bin("/", .bin("/", .num(8), .num(4)), .num(2)))
    }
    func testPowerIsRightAssociative() throws {
        XCTAssertEqual(try p("2^3^2"), .bin("^", .num(2), .bin("^", .num(3), .num(2))))
    }
    func testUnaryMinusBindsLooserThanPower() throws {
        XCTAssertEqual(try p("-2^2"), .neg(.bin("^", .num(2), .num(2))))
    }
    func testTrailingGarbageRejected() {
        XCTAssertThrowsError(try p("1 2"))
        XCTAssertThrowsError(try p("(1+2"))
        XCTAssertThrowsError(try p("1+"))
    }
}

final class EvalTests: XCTestCase {
    private func v(_ s: String) throws -> Double { try Eval.eval(try Parser.parse(try Lexer.tokens(s))) }
    func testArithmetic() throws {
        XCTAssertEqual(try v("10-4-3"), 3)
        XCTAssertEqual(try v("2+3*4"), 14)
        XCTAssertEqual(try v("(2+3)*4"), 20)
        XCTAssertEqual(try v("2^3^2"), 512)
        XCTAssertEqual(try v("-2^2"), -4)
        XCTAssertEqual(try v("--3"), 3)
    }
    func testDivisionByZeroThrows() {
        XCTAssertThrowsError(try v("1/0")) { XCTAssertEqual($0 as? CalcError, .divZero) }
        XCTAssertThrowsError(try v("5/(2-2)"))
    }
}

final class FormatTests: XCTestCase {
    func testRender() {
        XCTAssertEqual(Format.render(3), "3")
        XCTAssertEqual(Format.render(-0.0), "0")
        XCTAssertEqual(Format.render(1.5), "1.5")
        XCTAssertEqual(Format.render(2.0 / 3.0), "0.666667")
        XCTAssertEqual(Format.render(0.1 + 0.2), "0.3")
    }
}

final class CalculatorTests: XCTestCase {
    func testRunRendersResultsAndErrors() {
        XCTAssertEqual(Calculator.run("1.5 * 4"), "6")
        XCTAssertEqual(Calculator.run("10 / 4"), "2.5")
        XCTAssertEqual(Calculator.run("1/0"), "div by zero")
        XCTAssertEqual(Calculator.run("2 +"), "error")
        XCTAssertEqual(Calculator.run("abc"), "error")
        XCTAssertEqual(Calculator.run("(1+2)*(3+4)"), "21")
    }
}
