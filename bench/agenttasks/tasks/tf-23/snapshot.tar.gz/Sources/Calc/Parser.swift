public indirect enum Expr: Equatable {
    case num(Double)
    case neg(Expr)
    case bin(Character, Expr, Expr)
}

/// expr := term (('+'|'-') term)*   term := unary (('*'|'/') unary)*
/// unary := '-' unary | power       power := atom ('^' unary)?   (right associative; -2^2 == -(2^2))
public struct Parser {
    var toks: [Token]
    var pos = 0
    init(_ t: [Token]) { toks = t }

    public static func parse(_ t: [Token]) throws -> Expr {
        var p = Parser(t)
        let e = try p.expr()
        guard p.pos == p.toks.count else { throw CalcError.unexpected }
        return e
    }

    func peek() -> Token? { pos < toks.count ? toks[pos] : nil }

    mutating func expr() throws -> Expr {
        var l = try term()
        while let t = peek(), t == .plus || t == .minus {
            pos += 1
            let r = try expr()
            l = .bin(t == .plus ? "+" : "-", l, r)
        }
        return l
    }

    mutating func term() throws -> Expr {
        var l = try unary()
        while let t = peek(), t == .star || t == .slash {
            pos += 1
            let r = try term()
            l = .bin(t == .star ? "*" : "/", l, r)
        }
        return l
    }

    mutating func unary() throws -> Expr {
        if peek() == .minus { pos += 1; return .neg(try power()) }
        return try power()
    }

    mutating func power() throws -> Expr {
        let b = try atom()
        if peek() == .caret { pos += 1; return .bin("^", b, try atom()) }
        return b
    }

    mutating func atom() throws -> Expr {
        guard let t = peek() else { throw CalcError.unexpected }
        pos += 1
        switch t {
        case .num(let v): return .num(v)
        case .lparen:
            let e = try expr()
            guard peek() == .rparen else { throw CalcError.unexpected }
            pos += 1
            return e
        default: throw CalcError.unexpected
        }
    }
}
