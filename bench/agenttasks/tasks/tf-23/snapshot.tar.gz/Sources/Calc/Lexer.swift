public enum Token: Equatable {
    case num(Double), plus, minus, star, slash, caret, lparen, rparen
}

public enum CalcError: Error, Equatable {
    case badChar(Character), unexpected, divZero
}

public enum Lexer {
    public static func tokens(_ s: String) throws -> [Token] {
        var out: [Token] = []
        let cs = Array(s)
        var i = 0
        while i < cs.count {
            let c = cs[i]
            if c == " " { i += 1; continue }
            if c.isNumber || c == "." {
                var j = i
                while j < cs.count, cs[j].isNumber { j += 1 }
                guard let v = Double(String(cs[i..<j])) else { throw CalcError.badChar(c) }
                out.append(.num(v))
                i = j
                continue
            }
            switch c {
            case "+": out.append(.plus)
            case "-": out.append(.minus)
            case "*": out.append(.star)
            case "/": out.append(.slash)
            case "^": out.append(.caret)
            case "(": out.append(.lparen)
            case ")": out.append(.lparen)
            default: throw CalcError.badChar(c)
            }
            i += 1
        }
        return out
    }
}
