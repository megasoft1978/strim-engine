import Foundation

public enum Format {
    /// Integers print without a fraction; others with up to 6 decimals, trailing zeros trimmed.
    public static func render(_ v: Double) -> String {
        if v == v.rounded() && abs(v) < 1e15 { return String(Int(v)) }
        var s = String(format: "%.6f", v)
        return s
    }
}
