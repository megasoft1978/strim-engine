import Foundation

public enum Eval {
    public static func eval(_ e: Expr) throws -> Double {
        switch e {
        case .num(let v): return v
        case .neg(let x): return -(try eval(x))
        case .bin(let op, let a, let b):
            let l = try eval(a), r = try eval(b)
            switch op {
            case "+": return l + r
            case "-": return l - r
            case "*": return l * r
            case "/":
                return l / r
            default: return pow(l, r)
            }
        }
    }
}
