public enum Calculator {
    /// Evaluates `input` and renders the result, or "div by zero" / "error".
    public static func run(_ input: String) -> String {
        do {
            let e = try Parser.parse(try Lexer.tokens(input))
            return Format.render(try Eval.eval(e))
        } catch CalcError.divZero {
            return "error"
        } catch {
            return "error"
        }
    }
}
