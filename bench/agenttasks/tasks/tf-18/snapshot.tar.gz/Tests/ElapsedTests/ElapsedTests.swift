import XCTest
@testable import Elapsed

final class ElapsedTests: XCTestCase {
    func testFormat() {
        XCTAssertEqual(Elapsed.format(seconds: 0), "0s")
        XCTAssertEqual(Elapsed.format(seconds: 59), "59s")
        XCTAssertEqual(Elapsed.format(seconds: 60), "1m")
        XCTAssertEqual(Elapsed.format(seconds: 3600), "1h")
        XCTAssertEqual(Elapsed.format(seconds: 3661), "1h 1m 1s")
        XCTAssertEqual(Elapsed.format(seconds: 86400), "24h")
        XCTAssertEqual(Elapsed.format(seconds: 7384), "2h 3m 4s")
    }

    func testParse() {
        XCTAssertEqual(Elapsed.parse("1h 1m 1s"), 3661)
        XCTAssertEqual(Elapsed.parse("90s"), 90)
        XCTAssertNil(Elapsed.parse(""))
        XCTAssertNil(Elapsed.parse("5x"))
        XCTAssertNil(Elapsed.parse("m"))
    }

    func testRoundTrip() {
        for n in [1, 59, 60, 61, 3599, 3600, 3601, 7384, 86399] {
            XCTAssertEqual(Elapsed.parse(Elapsed.format(seconds: n)), n)
        }
    }
}
