// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "Elapsed",
    targets: [
        .target(name: "Elapsed"),
        .testTarget(name: "ElapsedTests", dependencies: ["Elapsed"]),
    ]
)
