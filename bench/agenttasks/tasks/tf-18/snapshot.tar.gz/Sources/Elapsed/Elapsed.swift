public enum Elapsed {
    /// 3661 -> "1h 1m 1s"; zero units are skipped; 0 -> "0s".
    public static func format(seconds: Int) -> String {
        guard seconds > 0 else { return "0s" }
        let h = seconds / 3600
        let m = seconds / 60
        let s = seconds % 60
        var parts: [String] = []
        if h > 0 { parts.append("\(h)h") }
        if m > 0 { parts.append("\(m)m") }
        if s > 0 { parts.append("\(s)s") }
        return parts.joined(separator: " ")
    }

    /// Inverse of `format`: space separated "<n>h", "<n>m", "<n>s" tokens.
    public static func parse(_ text: String) -> Int? {
        var total = 0
        var any = false
        for token in text.split(separator: " ") {
            guard let unit = token.last, let n = Int(token.dropLast()), n >= 0 else { return nil }
            switch unit {
            case "h": total += n * 3600
            case "m": total += n * 60
            case "s": total += n
            default: return nil
            }
            any = true
        }
        return any ? total : nil
    }
}
