import XCTest
@testable import LRUCache

final class LRUCacheTests: XCTestCase {
    func testEvictsLeastRecentlyInserted() {
        var c = LRUCache<String, Int>(capacity: 2)
        c.set("a", 1); c.set("b", 2); c.set("c", 3)
        XCTAssertNil(c.get("a"))
        XCTAssertEqual(c.get("b"), 2)
        XCTAssertEqual(c.count, 2)
    }

    func testGetRefreshesRecency() {
        var c = LRUCache<String, Int>(capacity: 2)
        c.set("a", 1); c.set("b", 2)
        XCTAssertEqual(c.get("a"), 1)
        c.set("c", 3)
        XCTAssertEqual(c.get("a"), 1)
        XCTAssertNil(c.get("b"))
    }

    func testOverwriteRefreshes() {
        var c = LRUCache<String, Int>(capacity: 2)
        c.set("a", 1); c.set("b", 2); c.set("a", 10); c.set("c", 3)
        XCTAssertEqual(c.get("a"), 10)
        XCTAssertNil(c.get("b"))
        XCTAssertEqual(c.keysLeastRecentFirst, ["c", "a"])
    }
}
