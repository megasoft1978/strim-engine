// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "LRUCache",
    targets: [
        .target(name: "LRUCache"),
        .testTarget(name: "LRUCacheTests", dependencies: ["LRUCache"]),
    ]
)
