/// Least-recently-used cache. Both `get` and `set` count as a use.
public struct LRUCache<Key: Hashable, Value> {
    public let capacity: Int
    private var values: [Key: Value] = [:]
    /// Least recently used first.
    private var order: [Key] = []

    public init(capacity: Int) {
        precondition(capacity > 0, "capacity must be positive")
        self.capacity = capacity
    }

    public var count: Int { values.count }
    public var keysLeastRecentFirst: [Key] { order }

    public mutating func get(_ key: Key) -> Value? {
        guard let value = values[key] else { return nil }
        return value
    }

    public mutating func set(_ key: Key, _ value: Value) {
        values[key] = value
        touch(key)
        if order.count > capacity {
            let evicted = order.removeFirst()
            values[evicted] = nil
        }
    }

    private mutating func touch(_ key: Key) {
        order.removeAll { $0 == key }
        order.append(key)
    }
}
