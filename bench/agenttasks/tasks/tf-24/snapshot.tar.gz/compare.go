package semver

import "strconv"

func cmpInt(a, b int) int {
	switch {
	case a < b:
		return -1
	case a > b:
		return 1
	}
	return 0
}

// Compare orders versions by precedence: -1, 0, +1. A release is greater than any
// of its pre-releases; pre-release identifiers compare numerically when both are
// numbers, numbers sort before text, text compares lexically, a longer list wins a tie.
func Compare(a, b Version) int {
	if c := cmpInt(a.Major, b.Major); c != 0 {
		return c
	}
	if c := cmpInt(a.Minor, b.Minor); c != 0 {
		return c
	}
	switch {
	case len(a.Pre) == 0 && len(b.Pre) == 0:
		return 0
	case len(a.Pre) == 0:
		return -1
	case len(b.Pre) == 0:
		return 1
	}
	for i := 0; i < len(a.Pre) && i < len(b.Pre); i++ {
		if c := cmpIdent(a.Pre[i], b.Pre[i]); c != 0 {
			return c
		}
	}
	return cmpInt(len(a.Pre), len(b.Pre))
}

func cmpIdent(x, y string) int {
	xn, xe := strconv.Atoi(x)
	yn, ye := strconv.Atoi(y)
	switch {
	case xe == nil && ye == nil:
		return cmpIdent2(x, y)
	case xe == nil:
		return -1
	case ye == nil:
		return 1
	case x < y:
		return -1
	case x > y:
		return 1
	}
	return 0
}
