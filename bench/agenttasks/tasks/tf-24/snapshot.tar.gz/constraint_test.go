package semver

import "testing"

func TestSatisfies(t *testing.T) {
	cases := []struct {
		v, c string
		want bool
	}{
		{"1.5.0", ">=1.2.0 <2.0.0", true},
		{"2.0.0", ">=1.2.0 <2.0.0", false},
		{"1.2.0", ">1.2.0", false},
		{"1.2.0", "<=1.2.0", true},
		{"1.2.0", "=1.2.0", true},
		{"1.2.0", "1.2.0", true},
		{"1.2.1", "=1.2.0", false},
		{"1.9.9", "^1.2.3", true},
		{"2.0.0", "^1.2.3", false},
		{"1.2.2", "^1.2.3", false},
		{"0.2.9", "^0.2.3", true},
		{"0.3.0", "^0.2.3", false},
		{"0.0.3", "^0.0.3", true},
		{"0.0.4", "^0.0.3", false},
		{"1.2.9", "~1.2.3", true},
		{"1.3.0", "~1.2.3", false},
		{"1.2.2", "~1.2.3", false},
	}
	for _, c := range cases {
		got, err := Satisfies(mustParse(t, c.v), c.c)
		if err != nil {
			t.Errorf("Satisfies(%s, %q): %v", c.v, c.c, err)
			continue
		}
		if got != c.want {
			t.Errorf("Satisfies(%s, %q) = %v, want %v", c.v, c.c, got, c.want)
		}
	}
}

func TestSatisfiesBadConstraint(t *testing.T) {
	if _, err := Satisfies(mustParse(t, "1.0.0"), ">=banana"); err == nil {
		t.Fatal("want error")
	}
}
