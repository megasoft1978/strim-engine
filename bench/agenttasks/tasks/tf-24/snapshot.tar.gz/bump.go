package semver

import "fmt"

// Bump returns the next version: "major", "minor" or "patch". Lower parts reset to
// zero and pre-release is dropped; bumping the patch of a pre-release only drops the
// pre-release (1.2.3-rc.1 -> 1.2.3).
func Bump(v Version, kind string) (Version, error) {
	switch kind {
	case "major":
		return Version{Major: v.Major + 1}, nil
	case "minor":
		return Version{Major: v.Major, Minor: v.Minor + 1, Patch: v.Patch}, nil
	case "patch":
		return Version{Major: v.Major, Minor: v.Minor, Patch: v.Patch + 1}, nil
	}
	return v, fmt.Errorf("semver: unknown bump %q", kind)
}
