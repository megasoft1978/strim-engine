package semver

import "testing"

func TestParseOK(t *testing.T) {
	cases := map[string]string{
		"1.2.3":          "1.2.3",
		"v1.2.3":         "1.2.3",
		" 1.2.3 ":        "1.2.3",
		"1.2.3-rc.1":     "1.2.3-rc.1",
		"1.2.3+build.5":  "1.2.3",
		"1.2.3-rc.1+b-7": "1.2.3-rc.1",
		"0.0.0":          "0.0.0",
	}
	for in, want := range cases {
		v, err := Parse(in)
		if err != nil {
			t.Errorf("Parse(%q): %v", in, err)
			continue
		}
		if got := v.String(); got != want {
			t.Errorf("Parse(%q).String() = %q, want %q", in, got, want)
		}
	}
}

func TestParseErrors(t *testing.T) {
	for _, in := range []string{"1.2", "1.2.3.4", "a.b.c", "01.2.3", "1.02.3", "1.2.-3", ""} {
		if _, err := Parse(in); err == nil {
			t.Errorf("Parse(%q) succeeded, want error", in)
		}
	}
}
