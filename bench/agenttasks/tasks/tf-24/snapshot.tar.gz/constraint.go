package semver

import "strings"

// Satisfies reports whether v meets every space-separated term of c:
// ">=1.2.0 <2.0.0", "^1.2.3", "~1.2.3", "=1.0.0", "1.0.0".
// ^ allows changes that keep the left-most non-zero part; ~ allows patch changes.
func Satisfies(v Version, c string) (bool, error) {
	for _, term := range strings.Fields(c) {
		ok, err := check(v, term)
		if err != nil {
			return false, err
		}
		if !ok {
			return false, nil
		}
	}
	return true, nil
}

func check(v Version, t string) (bool, error) {
	op, rest := "=", t
	for _, p := range []string{">", "<", ">=", "<=", "=", "^", "~"} {
		if strings.HasPrefix(t, p) {
			op, rest = p, t[len(p):]
			break
		}
	}
	lo, err := Parse(rest)
	if err != nil {
		return false, err
	}
	switch op {
	case ">=":
		return Compare(v, lo) >= 0, nil
	case "<=":
		return Compare(v, lo) <= 0, nil
	case ">":
		return Compare(v, lo) > 0, nil
	case "<":
		return Compare(v, lo) < 0, nil
	case "^":
		hi := Version{Major: lo.Major + 1}
		return Compare(v, lo) >= 0 && Compare(v, hi) < 0, nil
	case "~":
		hi := Version{Major: lo.Major + 1}
		return Compare(v, lo) >= 0 && Compare(v, hi) < 0, nil
	}
	return Compare(v, lo) == 0, nil
}
