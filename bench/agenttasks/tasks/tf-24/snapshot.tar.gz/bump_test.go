package semver

import "testing"

func TestBump(t *testing.T) {
	cases := []struct{ in, kind, want string }{
		{"1.2.3", "major", "2.0.0"},
		{"1.2.3", "minor", "1.3.0"},
		{"1.2.3", "patch", "1.2.4"},
		{"1.2.3-rc.1", "patch", "1.2.3"},
		{"1.2.3-rc.1", "minor", "1.3.0"},
		{"1.2.3-rc.1", "major", "2.0.0"},
	}
	for _, c := range cases {
		got, err := Bump(mustParse(t, c.in), c.kind)
		if err != nil {
			t.Errorf("Bump(%s,%s): %v", c.in, c.kind, err)
			continue
		}
		if got.String() != c.want {
			t.Errorf("Bump(%s,%s) = %s, want %s", c.in, c.kind, got, c.want)
		}
	}
	if _, err := Bump(mustParse(t, "1.0.0"), "huge"); err == nil {
		t.Error("unknown kind: want error")
	}
}
