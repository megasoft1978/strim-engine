package tests;

import mini.MiniTest;

public class AllTests {
    public static void main(String[] args) {
        System.exit(MiniTest.run(args, BankTest.class) == 0 ? 0 : 1);
    }
}
