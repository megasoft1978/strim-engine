package mini;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Comparator;

/** Minimal test runner (no JUnit, no network): runs every public no-arg method whose name starts with "test". */
public final class MiniTest {
    private MiniTest() {}

    /** Optional filter: only classes whose simple name contains one of the given strings run. Returns the failure count. */
    public static int run(String[] filter, Class<?>... classes) {
        int pass = 0, fail = 0;
        for (Class<?> c : classes) {
            if (filter.length > 0 && Arrays.stream(filter).noneMatch(f -> c.getSimpleName().contains(f))) continue;
            Method[] methods = c.getDeclaredMethods();
            Arrays.sort(methods, Comparator.comparing(Method::getName));
            for (Method m : methods) {
                if (!m.getName().startsWith("test") || !Modifier.isPublic(m.getModifiers()) || m.getParameterCount() != 0) continue;
                String name = c.getSimpleName() + "." + m.getName();
                try {
                    Object o = c.getDeclaredConstructor().newInstance();
                    m.invoke(o);
                    pass++;
                    System.out.println("ok   " + name);
                } catch (InvocationTargetException e) {
                    fail++;
                    System.out.println("FAIL " + name + ": " + e.getCause());
                } catch (ReflectiveOperationException e) {
                    fail++;
                    System.out.println("FAIL " + name + ": cannot run: " + e);
                }
            }
        }
        System.out.println(pass + " passed, " + fail + " failed");
        return fail;
    }
}
