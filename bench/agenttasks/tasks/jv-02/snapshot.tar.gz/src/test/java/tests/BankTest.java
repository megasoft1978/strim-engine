package tests;

import static mini.Assert.*;

import bank.Account;
import bank.Bank;
import java.math.BigDecimal;

public class BankTest {
    private static BigDecimal d(String s) {
        return new BigDecimal(s);
    }

    public void testPostRoundsHalfUp() {
        Account a = new Account("a");
        a.post("x", d("10.005"));
        assertEquals(d("10.01"), a.balance());
        a.post("y", d("-0.005"));
        assertEquals(d("10.00"), a.balance());
        assertEquals(2, a.history().size());
    }

    public void testInterestRoundsHalfUp() {
        Account a = new Account("a");
        a.post("open", d("1000.00"));
        a.applyMonthlyInterest(d("3.5"));
        assertEquals(d("1002.92"), a.balance());
        Account b = new Account("b");
        b.post("open", d("100.00"));
        b.applyMonthlyInterest(d("1.0"));
        assertEquals(d("100.08"), b.balance());
    }

    public void testNoInterestOnZeroOrNegative() {
        Account a = new Account("a");
        a.applyMonthlyInterest(d("5"));
        assertEquals(0, a.history().size());
    }

    public void testTransferMovesMoney() {
        Bank bank = new Bank();
        bank.open("a").post("seed", d("100.00"));
        bank.open("b");
        bank.transfer("a", "b", d("40.25"));
        assertEquals(d("59.75"), bank.get("a").balance());
        assertEquals(d("40.25"), bank.get("b").balance());
        assertEquals(d("100.00"), bank.total());
    }

    public void testTransferOfExactBalanceIsAllowed() {
        Bank bank = new Bank();
        bank.open("a").post("seed", d("10.00"));
        bank.open("b");
        bank.transfer("a", "b", d("10.00"));
        assertEquals(d("0.00"), bank.get("a").balance());
    }

    public void testTransferDebitsTheSource() {
        Bank bank = new Bank();
        bank.open("a").post("seed", d("10.00"));
        bank.open("b");
        bank.transfer("a", "b", d("3.00"));
        assertEquals(d("-3.00"), bank.get("a").history().get(1).amount);
        assertEquals("transfer to b", bank.get("a").history().get(1).memo);
    }

    public void testRejectedTransfersChangeNothing() {
        Bank bank = new Bank();
        bank.open("a").post("seed", d("10.00"));
        bank.open("b");
        assertThrows(IllegalStateException.class, () -> bank.transfer("a", "b", d("10.01")));
        assertThrows(IllegalArgumentException.class, () -> bank.transfer("a", "b", d("0")));
        assertThrows(IllegalArgumentException.class, () -> bank.transfer("a", "zzz", d("1")));
        assertEquals(d("10.00"), bank.get("a").balance());
        assertEquals(1, bank.get("a").history().size());
    }

    public void testDuplicateAccount() {
        Bank bank = new Bank();
        bank.open("a");
        assertThrows(IllegalArgumentException.class, () -> bank.open("a"));
    }
}
