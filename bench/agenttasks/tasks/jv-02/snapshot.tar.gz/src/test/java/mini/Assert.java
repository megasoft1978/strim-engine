package mini;

import java.util.Objects;

public final class Assert {
    private Assert() {}

    public interface Thrower { void run() throws Throwable; }

    public static void assertEquals(Object expected, Object actual) {
        if (!Objects.equals(expected, actual)) throw new AssertionError("expected <" + expected + "> but was <" + actual + ">");
    }

    public static void assertEquals(long expected, long actual) {
        if (expected != actual) throw new AssertionError("expected <" + expected + "> but was <" + actual + ">");
    }

    public static void assertTrue(boolean cond, String message) {
        if (!cond) throw new AssertionError(message);
    }

    public static void assertTrue(boolean cond) {
        assertTrue(cond, "expected true");
    }

    public static void assertFalse(boolean cond) {
        assertTrue(!cond, "expected false");
    }

    public static <T extends Throwable> T assertThrows(Class<T> type, Thrower body) {
        try {
            body.run();
        } catch (Throwable t) {
            if (type.isInstance(t)) return type.cast(t);
            throw new AssertionError("expected " + type.getSimpleName() + " but got " + t);
        }
        throw new AssertionError("expected " + type.getSimpleName() + " but nothing was thrown");
    }
}
