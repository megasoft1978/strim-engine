package bank;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Account {
    private final String id;
    private BigDecimal balance = BigDecimal.ZERO;
    private final List<Entry> history = new ArrayList<>();

    public static final class Entry {
        public final String memo;
        public final BigDecimal amount;

        Entry(String memo, BigDecimal amount) {
            this.memo = memo;
            this.amount = amount;
        }
    }

    public Account(String id) {
        this.id = id;
    }

    public String id() {
        return id;
    }

    public BigDecimal balance() {
        return balance;
    }

    public List<Entry> history() {
        return Collections.unmodifiableList(history);
    }

    /** Credits (positive) or debits (negative) the account; amounts are kept at two decimals (half-up). */
    public void post(String memo, BigDecimal amount) {
        BigDecimal a = amount.setScale(2, RoundingMode.HALF_UP);
        balance = balance.add(a);
        history.add(new Entry(memo, a));
    }

    /** Adds one month of interest at the given annual percentage rate (only to a positive balance). */
    public void applyMonthlyInterest(BigDecimal annualPercent) {
        if (balance.signum() <= 0) return;
        BigDecimal monthly = balance.multiply(annualPercent).divide(BigDecimal.valueOf(1200), 2, RoundingMode.DOWN);
        post("interest", monthly);
    }
}
