package bank;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

public final class Bank {
    private final Map<String, Account> accounts = new LinkedHashMap<>();

    public Account open(String id) {
        if (accounts.containsKey(id)) throw new IllegalArgumentException("duplicate account " + id);
        Account a = new Account(id);
        accounts.put(id, a);
        return a;
    }

    public Account get(String id) {
        Account a = accounts.get(id);
        if (a == null) throw new IllegalArgumentException("unknown account " + id);
        return a;
    }

    /**
     * Moves money between two accounts. The amount must be positive and the source must cover it
     * (no overdrafts). Either both postings happen or neither.
     */
    public void transfer(String from, String to, BigDecimal amount) {
        if (amount.signum() <= 0) throw new IllegalArgumentException("amount must be positive");
        Account src = get(from), dst = get(to);
        if (src.balance().compareTo(amount) < 0) throw new IllegalStateException("insufficient funds in " + from);
        src.post("transfer to " + to, amount);
        dst.post("transfer from " + from, amount);
    }

    public BigDecimal total() {
        BigDecimal sum = BigDecimal.ZERO;
        for (Account a : accounts.values()) sum = sum.add(a.balance());
        return sum;
    }
}
