import { test, expect } from 'bun:test';
import { renderToStaticMarkup } from 'react-dom/server';
import { edgeIndex, stepIndex } from '../src/keys.js';
import { initTabs, tabsReducer } from '../src/tabsState.js';
import { Tabs } from '../src/Tabs.jsx';

const tabs = [
  { id: 'a', label: 'Alpha', content: 'A body' },
  { id: 'b', label: 'Beta', content: 'B body', disabled: true, count: 4 },
  { id: 'c', label: 'Gamma', content: 'C body', count: 120 },
  { id: 'd', label: 'Delta', content: 'D body', count: 0 },
];
const render = (props) => renderToStaticMarkup(<Tabs tabs={tabs} {...props} />);
const run = (state, ...actions) => actions.reduce(tabsReducer, state);

test('stepIndex skips disabled tabs and wraps in both directions', () => {
  expect(stepIndex(tabs, 0, 1)).toBe(2);
  expect(stepIndex(tabs, 3, 1)).toBe(0);
  expect(stepIndex(tabs, 0, -1)).toBe(3);
  expect(stepIndex(tabs, 2, -1)).toBe(0);
  expect(stepIndex([{ id: 'x', disabled: true }], 0, 1)).toBe(-1);
});

test('edgeIndex finds the first and last enabled tab', () => {
  const t = [{ id: 'x', disabled: true }, { id: 'y' }, { id: 'z' }, { id: 'w', disabled: true }];
  expect(edgeIndex(t, 'first')).toBe(1);
  expect(edgeIndex(t, 'last')).toBe(2);
  expect(edgeIndex([{ id: 'x', disabled: true }], 'first')).toBe(-1);
});

test('initTabs honours a usable requested id, otherwise picks the first enabled tab', () => {
  expect(initTabs(tabs, 'c')).toEqual({ tabs, active: 2, focus: 2 });
  expect(initTabs(tabs, 'b').active).toBe(0);
  expect(initTabs(tabs, 'nope').active).toBe(0);
  expect(initTabs(tabs).focus).toBe(0);
  expect(initTabs([{ id: 'x', disabled: true }]).active).toBe(-1);
  expect(initTabs([]).active).toBe(-1);
});

test('select moves active and focus; disabled, unknown and repeated ids are no-ops', () => {
  const s = initTabs(tabs);
  expect(tabsReducer(s, { type: 'select', id: 'd' })).toMatchObject({ active: 3, focus: 3 });
  expect(tabsReducer(s, { type: 'select', id: 'b' })).toBe(s);
  expect(tabsReducer(s, { type: 'select', id: 'zzz' })).toBe(s);
  expect(tabsReducer(s, { type: 'select', id: 'a' })).toBe(s);
});

test('move changes only the focus, skipping disabled tabs and wrapping', () => {
  const s = initTabs(tabs);
  const next = tabsReducer(s, { type: 'move', to: 'next' });
  expect(next).toMatchObject({ active: 0, focus: 2 });
  expect(run(s, { type: 'move', to: 'prev' })).toMatchObject({ active: 0, focus: 3 });
  expect(run(s, { type: 'move', to: 'last' }).focus).toBe(3);
  expect(run(next, { type: 'move', to: 'first' }).focus).toBe(0);
  expect(tabsReducer(s, { type: 'move', to: 'first' })).toBe(s);
  expect(tabsReducer(s, { type: 'move', to: 'sideways' })).toBe(s);
});

test('activate commits the focused tab and does nothing when focus is already active', () => {
  const s = initTabs(tabs);
  expect(run(s, { type: 'move', to: 'next' }, { type: 'activate' })).toMatchObject({ active: 2, focus: 2 });
  expect(tabsReducer(s, { type: 'activate' })).toBe(s);
  const none = initTabs([{ id: 'x', disabled: true }]);
  expect(tabsReducer(none, { type: 'activate' })).toBe(none);
  expect(tabsReducer(none, { type: 'move', to: 'next' })).toBe(none);
  expect(tabsReducer(s, { type: 'unknown' })).toBe(s);
});

test('tablist, tab and panel roles are wired together with ids', () => {
  const html = render({ id: 'x', activeId: 'c' });
  expect(html).toContain('<div role="tablist">');
  expect(html).toContain('role="tab" id="x-tab-c" aria-controls="x-panel-c" aria-selected="true"');
  expect(html).toContain('role="tab" id="x-tab-a" aria-controls="x-panel-a" aria-selected="false"');
  expect(html).toContain('role="tabpanel" id="x-panel-c" aria-labelledby="x-tab-c"');
  expect(html.match(/role="tab"/g)).toHaveLength(4);
});

test('roving tabindex: only the selected tab is in the tab order', () => {
  const html = render({ activeId: 'c' });
  expect(html.match(/tabindex="0"/g)).toHaveLength(2); // selected tab + visible panel
  expect(html).toMatch(/aria-selected="true"[^>]*tabindex="0"/);
  expect(html).toMatch(/id="tabs-tab-a"[^>]*tabindex="-1"/);
});

test('disabled tabs are marked both natively and with aria-disabled', () => {
  const html = render({});
  expect(html).toMatch(/id="tabs-tab-b"[^>]*aria-disabled="true"[^>]*disabled=""/);
  expect(html.match(/aria-disabled/g)).toHaveLength(1);
});

test('only the active panel is rendered unless keepMounted is set', () => {
  const html = render({ activeId: 'd' });
  expect(html).toContain('D body');
  expect(html).not.toContain('A body');
  expect(html.match(/role="tabpanel"/g)).toHaveLength(1);
});

test('keepMounted keeps inactive panels hidden, but never for disabled tabs', () => {
  const html = render({ keepMounted: true });
  expect(html.match(/role="tabpanel"/g)).toHaveLength(3);
  expect(html).toMatch(/id="tabs-panel-c"[^>]*hidden=""/);
  expect(html).not.toMatch(/id="tabs-panel-a"[^>]*hidden/);
  expect(html).not.toContain('B body');
});

test('count badges show only for positive counts and cap at 99+', () => {
  const html = render({});
  expect(html).toContain('Gamma<span class="count">99+</span>');
  expect(html).toContain('Beta<span class="count">4</span>');
  expect(html).not.toContain('Delta<span');
  expect(html).not.toContain('Alpha<span');
});

test('empty and fully disabled tab sets render without a selected tab or panel', () => {
  expect(renderToStaticMarkup(<Tabs tabs={[]} />)).toBe('<p class="tabs-empty">No tabs</p>');
  const html = renderToStaticMarkup(<Tabs tabs={[{ id: 'x', label: 'X', content: 'X body', disabled: true }]} />);
  expect(html).not.toContain('tabpanel');
  expect(html).not.toContain('X body');
  expect(html).toContain('aria-selected="false"');
  expect(html).not.toContain('tabindex="0"');
});
