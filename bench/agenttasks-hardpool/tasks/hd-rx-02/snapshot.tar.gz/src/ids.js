/** DOM ids shared by a tab and its panel: tabId('t', 'a') -> "t-tab-a". */
export const tabId = (root, tab) => `${root}-tab-${tab.id}`;
export const panelId = (root, tab) => `${root}-panel-${tab.id}`;
