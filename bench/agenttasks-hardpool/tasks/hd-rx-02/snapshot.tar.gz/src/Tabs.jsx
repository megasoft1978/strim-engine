export function Tabs({ tabs }) {
  return <div className="tabs" />;
}
