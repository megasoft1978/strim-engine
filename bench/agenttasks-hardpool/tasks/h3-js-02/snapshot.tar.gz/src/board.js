import * as commands from './commands.js';
import { BoardProjection } from './projection.js';
import { MemoryJournal } from './journal.js';

export class Board {
  constructor(journal = new MemoryJournal()) {
    this.journal = journal;
    const stored = journal.read();
    this.projection = new BoardProjection(stored.snapshot?.state);
    for (const record of stored.events) this.projection.apply(record.event);
  }

  execute(event) {
    this.journal.append({ action: 'command', event });
    this.projection.apply(event);
  }

  create(id, title, lane) { this.execute(commands.create(this.projection.state, id, title, lane)); }
  rename(id, title) { this.execute(commands.rename(this.projection.state, id, title)); }
  move(id, lane) { this.execute(commands.move(this.projection.state, id, lane)); }
  remove(id) { this.execute(commands.remove(this.projection.state, id)); }

  undo() { return false; }
  redo() { return false; }

  snapshot() {
    this.journal.compact({ state: this.projection.state });
  }

  list(lane) { return this.projection.list(lane); }
  counts() { return this.projection.counts(); }
}
