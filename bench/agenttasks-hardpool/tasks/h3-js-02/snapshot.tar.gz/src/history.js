// History is separate from the visible board projection.
export function emptyHistory() {
  return { undo: [], redo: [] };
}

export function copyHistory(history) {
  return JSON.parse(JSON.stringify(history));
}

export function inverse(event) {
  switch (event.type) {
    case 'created':
      return { type: 'removed', id: event.task.id, task: event.task, index: -1 };
    case 'removed':
      return { type: 'restored', task: event.task, index: event.index };
    case 'renamed':
      return { ...event, title: event.previous, previous: event.title };
    case 'moved':
      return { ...event, lane: event.previous, previous: event.lane };
    default:
      throw new Error('event cannot be undone');
  }
}
