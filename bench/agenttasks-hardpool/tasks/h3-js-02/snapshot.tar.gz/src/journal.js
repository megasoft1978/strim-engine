// A journal owns its data: callers never receive mutable internal objects.
const clone = value => JSON.parse(JSON.stringify(value));

export class MemoryJournal {
  constructor() {
    this.snapshot = null;
    this.events = [];
  }

  append(record) {
    this.events.push(clone(record));
  }

  read() {
    return clone({ snapshot: this.snapshot, events: this.events });
  }

  compact(snapshot) {
    this.snapshot = clone(snapshot);
    this.events = [];
  }
}
