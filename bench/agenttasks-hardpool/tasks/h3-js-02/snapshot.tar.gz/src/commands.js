import { lane, nonempty, taskId } from './validate.js';
import { task } from './state.js';

export function create(state, id, title, destination = 'todo') {
  id = taskId(id);
  if (state.tasks[id]) throw new Error('task already exists');
  return { type: 'created', task: { id, title: nonempty(title, 'title'), lane: lane(destination) } };
}

export function rename(state, id, title) {
  id = taskId(id);
  const previous = task(state, id).title;
  return { type: 'renamed', id, title: nonempty(title, 'title'), previous };
}

export function move(state, id, destination) {
  id = taskId(id);
  const previous = task(state, id).lane;
  return { type: 'moved', id, lane: lane(destination), previous };
}

export function remove(state, id) {
  id = taskId(id);
  return { type: 'removed', id, task: { ...task(state, id) }, index: state.order.indexOf(id) };
}
