import { copyState, emptyState } from './state.js';
import { reduce } from './reducer.js';

export class BoardProjection {
  constructor(state = emptyState()) {
    this.state = copyState(state);
  }

  apply(event) {
    this.state = reduce(this.state, event);
  }

  list(destination) {
    return this.state.order
      .map(id => ({ ...this.state.tasks[id] }))
      .filter(item => !destination || item.lane === destination);
  }

  counts() {
    const result = { todo: 0, doing: 0, done: 0 };
    for (const item of this.list()) result[item.lane]++;
    return result;
  }
}
