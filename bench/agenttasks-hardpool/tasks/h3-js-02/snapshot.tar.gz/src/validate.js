export function nonempty(value, label) {
  if (typeof value !== 'string' || !value.trim()) {
    throw new Error(`${label} must be a nonempty string`);
  }
  return value.trim();
}

export function lane(value) {
  const name = nonempty(value, 'lane');
  if (!['todo', 'doing', 'done'].includes(name)) {
    throw new Error('unknown lane');
  }
  return name;
}

export function taskId(value) {
  return nonempty(value, 'task id');
}
