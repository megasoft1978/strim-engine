// Read-only diagnostics over a board projection.
export function findByTitle(projection, query) {
  if (typeof query !== 'string') throw new Error('query must be a string');
  const needle = query.trim().toLocaleLowerCase();
  return projection.list().filter(item => item.title.toLocaleLowerCase().includes(needle));
}

export function grouped(projection) {
  const lanes = { todo: [], doing: [], done: [] };
  for (const item of projection.list()) {
    lanes[item.lane].push(item);
  }
  return lanes;
}

export function duplicateTitles(projection) {
  const groups = new Map();
  for (const item of projection.list()) {
    const key = item.title.toLocaleLowerCase();
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(item.id);
  }
  return [...groups.values()].filter(ids => ids.length > 1);
}

export function laneSummary(projection, lane) {
  const items = projection.list(lane);
  return {
    lane,
    count: items.length,
    first: items[0]?.id ?? null,
    last: items.at(-1)?.id ?? null,
  };
}

