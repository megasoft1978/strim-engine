export function laneReport(projection) {
  const counts = projection.counts();
  return ['todo', 'doing', 'done'].map(lane => ({ lane, count: counts[lane] }));
}

export function titles(projection, lane) {
  return projection.list(lane).map(item => item.title);
}

export function completionRate(projection) {
  const counts = projection.counts();
  const total = counts.todo + counts.doing + counts.done;
  return total ? counts.done / total : 0;
}
