import { readExport } from './export.js';
import { lane, nonempty, taskId } from './validate.js';

// Validate the entire import before returning commands to the caller.
export function planImport(text, existingIds = []) {
  const seen = new Set(existingIds);
  const items = readExport(text);
  const commands = [];
  for (const item of items) {
    if (!item || typeof item !== 'object') throw new Error('invalid task');
    const id = taskId(item.id);
    if (seen.has(id)) throw new Error('duplicate task id');
    seen.add(id);
    commands.push({
      id,
      title: nonempty(item.title, 'title'),
      lane: lane(item.lane),
    });
  }
  return commands;
}

export function importBoard(board, text) {
  const commands = planImport(text, board.list().map(item => item.id));
  for (const item of commands) {
    board.create(item.id, item.title, item.lane);
  }
  return commands.length;
}
