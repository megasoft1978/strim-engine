export function emptyState() {
  return { tasks: {}, order: [] };
}

export function copyState(state) {
  return {
    tasks: Object.fromEntries(Object.entries(state.tasks).map(([id, task]) => [id, { ...task }])),
    order: [...state.order],
  };
}

export function task(state, id) {
  const item = state.tasks[id];
  if (!item) throw new Error(`unknown task: ${id}`);
  return item;
}
