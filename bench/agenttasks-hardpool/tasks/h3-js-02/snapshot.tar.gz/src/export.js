export function exportBoard(projection) {
  return JSON.stringify({ version: 1, tasks: projection.list() });
}

export function readExport(text) {
  const data = JSON.parse(text);
  if (!data || data.version !== 1 || !Array.isArray(data.tasks)) {
    throw new Error('invalid board export');
  }
  return data.tasks.map(item => ({ ...item }));
}
