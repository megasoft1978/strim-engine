import { copyState } from './state.js';

// Events contain complete before/after values so projections can replay them.
export function reduce(state, event) {
  const next = copyState(state);
  switch (event.type) {
    case 'created':
      next.tasks[event.task.id] = { ...event.task };
      next.order.push(event.task.id);
      break;
    case 'renamed':
      next.tasks[event.id].title = event.title;
      break;
    case 'moved':
      next.tasks[event.id].lane = event.lane;
      break;
    case 'removed':
      delete next.tasks[event.id];
      next.order = next.order.filter(id => id !== event.id);
      break;
    case 'restored':
      next.tasks[event.task.id] = { ...event.task };
      next.order.splice(event.index, 0, event.task.id);
      break;
    default:
      throw new Error(`unknown event: ${event.type}`);
  }
  return next;
}

export function replay(initial, events) {
  return events.reduce(reduce, copyState(initial));
}
