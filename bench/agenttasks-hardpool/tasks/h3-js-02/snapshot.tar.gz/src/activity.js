// An operational view of physical journal records, not the board state.
export function summarize(records) {
  const counts = {};
  for (const record of records) {
    const type = record.event.type;
    counts[type] = (counts[type] || 0) + 1;
  }
  return counts;
}

export function recent(records, limit = 10) {
  if (!Number.isInteger(limit) || limit < 0) throw new Error('invalid limit');
  if (!limit) return [];
  return records.slice(-limit).map(record => ({
    action: record.action,
    type: record.event.type,
  }));
}
