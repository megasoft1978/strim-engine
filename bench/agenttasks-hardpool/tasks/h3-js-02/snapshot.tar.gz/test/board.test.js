import test from 'node:test';
import assert from 'node:assert/strict';
import { Board } from '../src/board.js';
import { MemoryJournal } from '../src/journal.js';
import { laneReport, completionRate } from '../src/report.js';
import { exportBoard, readExport } from '../src/export.js';
import { recent, summarize } from '../src/activity.js';

const titles = board => board.list().map(item => item.title);

test('ordinary commands update independent projections and validate input', () => {
  const board = new Board();
  board.create('a', ' Alpha ');
  board.create('b', 'Beta', 'doing');
  board.rename('a', 'First');
  board.move('a', 'done');
  assert.deepEqual(titles(board), ['First', 'Beta']);
  assert.deepEqual(laneReport(board.projection), [
    { lane: 'todo', count: 0 }, { lane: 'doing', count: 1 }, { lane: 'done', count: 1 },
  ]);
  assert.equal(completionRate(board.projection), 0.5);
  assert.deepEqual(readExport(exportBoard(board.projection)), board.list());
  assert.throws(() => board.create('a', 'duplicate'), /exists/);
  assert.throws(() => board.move('a', 'invalid'), /lane/);
  assert.throws(() => board.remove('missing'), /unknown/);
});

test('undo and redo restore task values, ordering and reports', () => {
  const board = new Board();
  board.create('a', 'Alpha');
  board.create('b', 'Beta');
  board.move('a', 'done');
  board.rename('b', 'Second');
  board.remove('a');
  assert.equal(board.undo(), true);
  assert.deepEqual(titles(board), ['Alpha', 'Second']);
  assert.equal(board.undo(), true);
  assert.deepEqual(titles(board), ['Alpha', 'Beta']);
  assert.equal(board.undo(), true);
  assert.deepEqual(board.counts(), { todo: 2, doing: 0, done: 0 });
  assert.equal(board.redo(), true);
  assert.equal(board.redo(), true);
  assert.equal(board.redo(), true);
  assert.deepEqual(titles(board), ['Second']);
  assert.equal(board.redo(), false);
});

test('history survives compaction and a new board can continue both stacks', () => {
  const journal = new MemoryJournal();
  let board = new Board(journal);
  board.create('a', 'Alpha');
  board.create('b', 'Beta');
  board.move('a', 'done');
  board.undo();
  board.snapshot();
  board = new Board(journal);
  assert.deepEqual(board.counts(), { todo: 2, doing: 0, done: 0 });
  assert.equal(board.redo(), true);
  board.snapshot();
  board = new Board(journal);
  assert.equal(board.undo(), true);
  assert.equal(board.undo(), true);
  assert.deepEqual(titles(board), ['Alpha']);
  assert.equal(board.redo(), true);
  assert.deepEqual(titles(board), ['Alpha', 'Beta']);
});

test('replay after snapshot retains branch and rejects stale redo', () => {
  const journal = new MemoryJournal();
  let board = new Board(journal);
  board.create('a', 'Alpha');
  board.snapshot();
  board.rename('a', 'First');
  board.move('a', 'doing');
  board.undo();
  board = new Board(journal);
  assert.equal(board.redo(), true);
  assert.equal(board.undo(), true);
  board.rename('a', 'New branch');
  assert.equal(board.redo(), false);
  board = new Board(journal);
  assert.deepEqual(board.list(), [{ id: 'a', title: 'New branch', lane: 'todo' }]);
  assert.equal(board.redo(), false);
  assert.equal(board.undo(), true);
  assert.equal(board.undo(), true);
  assert.deepEqual(titles(board), ['Alpha']);
  assert.equal(board.undo(), true);
  assert.deepEqual(board.list(), []);
  assert.equal(board.undo(), false);
  assert.equal(board.redo(), true);
  assert.deepEqual(titles(board), ['Alpha']);
});

test('journal copies and activity describe physical events', () => {
  const journal = new MemoryJournal();
  const board = new Board(journal);
  board.create('a', 'Alpha');
  board.move('a', 'done');
  const records = journal.read().events;
  assert.deepEqual(summarize(records), { created: 1, moved: 1 });
  assert.deepEqual(recent(records, 1), [{ action: 'command', type: 'moved' }]);
  records[0].event.task.title = 'changed';
  assert.equal(new Board(journal).list()[0].title, 'Alpha');
});

test('import validates before changing a board and diagnostics group tasks', async () => {
  const { importBoard } = await import('../src/import.js');
  const { grouped, duplicateTitles, findByTitle, laneSummary } = await import('../src/inspect.js');
  const board = new Board();
  board.create('a', 'Alpha');
  const data = JSON.stringify({ version: 1, tasks: [
    { id: 'b', title: 'alpha', lane: 'doing' },
    { id: 'c', title: 'Third', lane: 'done' },
  ] });
  assert.equal(importBoard(board, data), 2);
  assert.deepEqual(duplicateTitles(board.projection), [['a', 'b']]);
  assert.equal(grouped(board.projection).done[0].id, 'c');
  assert.deepEqual(findByTitle(board.projection, ' ALP ').map(x => x.id), ['a', 'b']);
  assert.deepEqual(laneSummary(board.projection, 'doing'), { lane: 'doing', count: 1, first: 'b', last: 'b' });
  assert.throws(() => importBoard(board, data), /duplicate/);
  assert.equal(board.list().length, 3);
});
