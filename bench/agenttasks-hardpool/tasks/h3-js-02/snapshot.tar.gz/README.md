# Board Journal

A small in-memory event-sourced board. `Board` accepts task commands, and
`MemoryJournal` can be shared between board instances to simulate a restart.
Snapshots compact the event log while preserving the state needed to resume.
Run the offline suite with `node --test`.
