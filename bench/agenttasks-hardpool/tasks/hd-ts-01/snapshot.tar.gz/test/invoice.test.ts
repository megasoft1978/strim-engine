import { test } from "node:test";
import assert from "node:assert/strict";
import { buildInvoice } from "../src/invoice.ts";
import { mulBps } from "../src/money.ts";
import { discountAmount } from "../src/discount.ts";
import { shippingFor } from "../src/shipping.ts";
import { groupLines } from "../src/group.ts";
import { renderInvoice } from "../src/format.ts";
import type { Line } from "../src/types.ts";

const line = (sku: string, group: string, unit: number, qty: number, taxBps = 0): Line => ({ sku, group, unit, qty, taxBps });

test("mulBps rounds half up to the nearest cent", () => {
  assert.equal(mulBps(1000, 825), 83); // 82.5 -> 83
  assert.equal(mulBps(999, 1000), 100); // 99.9 -> 100
  assert.equal(mulBps(1001, 1000), 100); // 100.1 -> 100
  assert.equal(mulBps(0, 1000), 0);
});

test("percent discounts are expressed in basis points", () => {
  assert.equal(discountAmount(20000, { kind: "percent", value: 1000 }), 2000);
  assert.equal(discountAmount(1999, { kind: "percent", value: 2500 }), 500);
});

test("fixed discounts never exceed the subtotal", () => {
  assert.equal(discountAmount(1500, { kind: "fixed", value: 400 }), 400);
  assert.equal(discountAmount(300, { kind: "fixed", value: 400 }), 300);
  assert.equal(discountAmount(300, undefined), 0);
});

test("shipping is free exactly at the threshold", () => {
  assert.equal(shippingFor(4999, 1), 599);
  assert.equal(shippingFor(5000, 1), 0);
  assert.equal(shippingFor(0, 0), 0);
});

test("groups are sorted by name and keep input order inside a group", () => {
  const groups = groupLines([
    line("b1", "toys", 100, 1),
    line("a1", "books", 200, 1),
    line("b2", "toys", 300, 1),
    line("a2", "books", 400, 1),
    line("b3", "toys", 500, 1),
  ]);
  assert.deepEqual(
    groups.map((g) => [g.name, g.skus, g.subtotal]),
    [
      ["books", ["a1", "a2"], 600],
      ["toys", ["b1", "b2", "b3"], 900],
    ],
  );
});

test("invoice without discount", () => {
  const inv = buildInvoice([line("x", "g", 1250, 2, 825), line("y", "g", 333, 1, 825)]);
  assert.equal(inv.subtotal, 2833);
  assert.equal(inv.tax, 206 + 27); // 2500*8.25% = 206.25, 333*8.25% = 27.47
  assert.equal(inv.shipping, 599);
  assert.equal(inv.total, 2833 + 233 + 599);
});

test("percent discount reduces the subtotal but not the per-line tax base", () => {
  const inv = buildInvoice([line("x", "g", 6000, 1, 1000)], { kind: "percent", value: 500 });
  assert.equal(inv.discount, 300);
  assert.equal(inv.tax, 600);
  assert.equal(inv.shipping, 0);
  assert.equal(inv.total, 6000 - 300 + 600);
});

test("free shipping is decided after the discount", () => {
  const inv = buildInvoice([line("x", "g", 5500, 1)], { kind: "fixed", value: 500 });
  assert.equal(inv.shipping, 0); // 5000 net is exactly the threshold
  const inv2 = buildInvoice([line("x", "g", 5500, 1)], { kind: "fixed", value: 501 });
  assert.equal(inv2.shipping, 599);
});

test("an empty invoice is all zeros", () => {
  assert.deepEqual(buildInvoice([]), { groups: [], subtotal: 0, discount: 0, tax: 0, shipping: 0, total: 0 });
});

test("renderInvoice prints groups then totals", () => {
  const inv = buildInvoice([line("b", "toys", 2000, 1), line("a", "books", 3500, 1)], { kind: "percent", value: 500 });
  assert.equal(
    renderInvoice(inv),
    ["books: a 35.00", "toys: b 20.00", "subtotal 55.00", "discount -2.75", "tax 0.00", "shipping 0.00", "total 52.25"].join("\n"),
  );
});
