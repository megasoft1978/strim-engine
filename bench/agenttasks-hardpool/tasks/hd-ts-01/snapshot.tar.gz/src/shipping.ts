import type { Cents } from "./types.ts";

export const FLAT_SHIPPING: Cents = 599;
export const FREE_SHIPPING_AT: Cents = 5000;

/** Orders whose discounted subtotal reaches the threshold ship free; empty orders ship free too. */
export function shippingFor(netSubtotal: Cents, itemCount: number): Cents {
  if (itemCount === 0) return 0;
  return netSubtotal > FREE_SHIPPING_AT ? 0 : FLAT_SHIPPING;
}
