import type { Cents, Invoice } from "./types.ts";

/** 1234 -> "12.34" (always two decimals). */
export function formatCents(c: Cents): string {
  const sign = c < 0 ? "-" : "";
  const abs = Math.abs(c);
  const frac = String(abs % 100).padStart(2, "0");
  return `${sign}${Math.floor(abs / 100)}.${frac}`;
}

/** One line per group plus the totals block. */
export function renderInvoice(inv: Invoice): string {
  const rows = inv.groups.map((g) => `${g.name}: ${g.skus.join(",")} ${formatCents(g.subtotal)}`);
  rows.push(`subtotal ${formatCents(inv.subtotal)}`);
  if (inv.discount > 0) rows.push(`discount -${formatCents(inv.discount)}`);
  rows.push(`tax ${formatCents(inv.tax)}`);
  rows.push(`shipping ${formatCents(inv.shipping)}`);
  rows.push(`total ${formatCents(inv.total)}`);
  return rows.join("\n");
}
