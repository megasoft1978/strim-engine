/** Money is always integer cents. Rates and percentages are always integer basis points (1 bps = 0.01%). */
export type Cents = number;
export type Bps = number;

export interface Line {
  sku: string;
  group: string;
  unit: Cents;
  qty: number;
  taxBps: Bps;
}

/** percent: `value` is in basis points (1000 = 10%). fixed: `value` is in cents. */
export interface Discount {
  kind: "percent" | "fixed";
  value: number;
}

export interface Group {
  name: string;
  skus: string[];
  subtotal: Cents;
}

export interface Invoice {
  groups: Group[];
  subtotal: Cents;
  discount: Cents;
  tax: Cents;
  shipping: Cents;
  total: Cents;
}
