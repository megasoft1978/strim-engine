import { lineTotal } from "./money.ts";
import type { Group, Line } from "./types.ts";

/** Groups sorted by name; within a group, lines keep their input order. */
export function groupLines(lines: Line[]): Group[] {
  const sorted = [...lines].sort((a, b) => (a.group > b.group ? 1 : -1));
  const out: Group[] = [];
  for (const l of sorted) {
    let g = out[out.length - 1];
    if (!g || g.name !== l.group) {
      g = { name: l.group, skus: [], subtotal: 0 };
      out.push(g);
    }
    g.skus.push(l.sku);
    g.subtotal += lineTotal(l.unit, l.qty);
  }
  return out;
}
