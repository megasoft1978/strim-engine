import type { Bps, Cents } from "./types.ts";

/** cents * bps / 10000, rounded half up to a whole cent. */
export function mulBps(cents: Cents, bps: Bps): Cents {
  return Math.floor((cents * bps) / 10000);
}

export function lineTotal(unit: Cents, qty: number): Cents {
  return unit * qty;
}
