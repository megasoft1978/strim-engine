import { mulBps } from "./money.ts";
import type { Cents, Discount } from "./types.ts";

/** The amount taken off `subtotal`; never more than the subtotal itself. */
export function discountAmount(subtotal: Cents, d: Discount | undefined): Cents {
  if (!d) return 0;
  const raw = d.kind === "percent" ? mulBps(subtotal, d.value * 100) : d.value;
  return Math.min(raw, subtotal);
}
