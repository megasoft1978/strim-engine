import { discountAmount } from "./discount.ts";
import { groupLines } from "./group.ts";
import { lineTotal, mulBps } from "./money.ts";
import { shippingFor } from "./shipping.ts";
import type { Discount, Invoice, Line } from "./types.ts";

/** Tax is computed per line on the pre-discount line amount, each line rounded on its own. */
export function buildInvoice(lines: Line[], discount?: Discount): Invoice {
  const groups = groupLines(lines);
  const subtotal = groups.reduce((s, g) => s + g.subtotal, 0);
  const off = discountAmount(subtotal, discount);
  const tax = lines.reduce((s, l) => s + mulBps(lineTotal(l.unit, l.qty), l.taxBps), 0);
  const shipping = shippingFor(subtotal - off, lines.length);
  return { groups, subtotal, discount: off, tax, shipping, total: subtotal - off + tax + shipping };
}
