/**
 * Stable priority queue. Higher `priority` comes out first; entries with equal priority come out in the
 * order of their `seq` (lower first). `seq` is chosen by the caller, so an entry that is pushed again later
 * with its old `seq` goes back in front of entries that were queued after it.
 *
 *   push(item, priority, seq)       add an entry
 *   takeFirst(accept)               remove and return the first item (in queue order) for which
 *                                   accept(item) is true, or undefined when there is none
 *   remove(item)                    remove that item; returns true when it was queued
 *   size                            number of queued entries
 */
export class PriorityQueue {
  push(item, priority, seq) {
    throw new Error('not implemented');
  }

  takeFirst(accept) {
    throw new Error('not implemented');
  }

  remove(item) {
    throw new Error('not implemented');
  }

  get size() {
    throw new Error('not implemented');
  }
}
