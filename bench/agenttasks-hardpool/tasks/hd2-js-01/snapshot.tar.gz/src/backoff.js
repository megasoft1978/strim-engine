/**
 * Delay before the next attempt, after `attempt` (1-based) has just failed:
 *   min(maxMs, baseMs * factor ** (attempt - 1))
 * No jitter, so schedules stay deterministic.
 */
export function delayFor(attempt, { baseMs, factor, maxMs }) {
  throw new Error('not implemented');
}
