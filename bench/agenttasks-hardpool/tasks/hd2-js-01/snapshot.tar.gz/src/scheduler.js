import { CancelledError } from './errors.js';
import { delayFor } from './backoff.js';
import { deferred } from './deferred.js';
import { normalizeJobOptions, normalizeOptions } from './options.js';
import { PriorityQueue } from './pqueue.js';

/**
 * Async job scheduler. All timing goes through the injected `clock` ({ setTimeout(fn, ms) -> handle,
 * clearTimeout(handle) }); nothing here may use real timers.
 *
 *   const s = new Scheduler({ concurrency: 2, clock });
 *   const result = await s.schedule(async ({ attempt, signal }) => value, options);
 *
 * Job options (see normalizeJobOptions): key, priority, retries, backoff, signal, shouldRetry.
 *
 * Contract:
 *  1. At most `concurrency` job functions are running at once.
 *  2. Queue order is higher `priority` first, then first scheduled first (arrival order).
 *  3. `schedule` returns (invalid options throw a TypeError synchronously) a promise for the job function's result. When a slot is free the
 *     job function is called synchronously, inside `schedule`. Otherwise it is called synchronously from the
 *     moment a slot frees up (the settlement of a running job, a cancellation, or an expiring backoff timer).
 *  4. Jobs sharing a `key` never run at the same time. A queued job whose key is busy is skipped, not waited
 *     for: later jobs with free keys start before it. Jobs without a key never conflict.
 *  5. The job function receives { attempt, signal }; attempt is 1 for the first call. It may throw
 *     synchronously or return a rejected promise; both count as a failed attempt.
 *  6. `retries` is the number of retries after the first attempt (at most retries + 1 attempts). A failed
 *     attempt is retried while retries remain and shouldRetry(error, attempt) is true; otherwise the promise rejects with the last error. CancelledError is never retried.
 *  7. Before a retry the job waits delayFor(attempt, backoff) ms on the clock. While it waits it does not
 *     use a concurrency slot, but it keeps its key reserved (no other job with that key starts).
 *     When the wait ends the job re-enters the queue with its original priority and arrival order.
 *  8. If `signal` is already aborted when `schedule` is called, the promise rejects with CancelledError and
 *     the job function is never called.
 *  9. Aborting a queued job removes it from the queue and rejects with CancelledError.
 * 10. Aborting a job that is waiting for a retry cancels the timer, releases its key and rejects with CancelledError.
 * 11. Aborting a running job rejects its promise with CancelledError immediately and aborts the `signal`
 *     passed to the job function. The function may still be running: its slot and key stay occupied until it
 *     settles, and its result or error is then ignored (no retry).
 * 12. `idle()` returns a promise that resolves when no job is queued, running or waiting for a retry
 *     (immediately when that already holds). `stats()` returns { queued, running, waiting }, where
 *     `running` counts occupied slots (including aborted jobs whose function has not settled yet).
 */
export class Scheduler {
  #opts;

  constructor(opts) {
    this.#opts = normalizeOptions(opts);
  }

  schedule(fn, options) {
    throw new Error('not implemented');
  }

  idle() {
    throw new Error('not implemented');
  }

  stats() {
    throw new Error('not implemented');
  }
}
