/** Validates and defaults the Scheduler options. */
export function normalizeOptions(opts = {}) {
  const { concurrency = 1, clock } = opts;
  if (!Number.isInteger(concurrency) || concurrency < 1) throw new TypeError('concurrency must be a positive integer');
  if (!clock || typeof clock.setTimeout !== 'function' || typeof clock.clearTimeout !== 'function') {
    throw new TypeError('clock with setTimeout/clearTimeout is required');
  }
  return { concurrency, clock };
}

/** Validates and defaults the per-job options passed to `schedule`. */
export function normalizeJobOptions(opts = {}) {
  const { key, priority = 0, retries = 0, backoff = {}, signal, shouldRetry = () => true } = opts;
  if (!Number.isInteger(retries) || retries < 0) throw new TypeError('retries must be a non-negative integer');
  const { baseMs = 100, factor = 2, maxMs = Infinity } = backoff;
  return { key, priority, retries, backoff: { baseMs, factor, maxMs }, signal, shouldRetry };
}
