import test from 'node:test';
import assert from 'node:assert/strict';
import { PriorityQueue, delayFor } from '../src/index.js';

test('delayFor grows geometrically from the first failed attempt and is capped', () => {
  const o = { baseMs: 100, factor: 3, maxMs: 1000 };
  assert.deepEqual([1, 2, 3, 4, 5].map((n) => delayFor(n, o)), [100, 300, 900, 1000, 1000]);
  assert.equal(delayFor(1, { baseMs: 7, factor: 2, maxMs: Infinity }), 7);
  assert.equal(delayFor(4, { baseMs: 7, factor: 1, maxMs: Infinity }), 7);
});

test('PriorityQueue orders by priority then seq and supports predicate removal', () => {
  const q = new PriorityQueue();
  q.push('b', 0, 2);
  q.push('a', 0, 1);
  q.push('c', 5, 9);
  assert.equal(q.size, 3);
  assert.equal(q.takeFirst((x) => x !== 'c'), 'a');
  assert.equal(q.takeFirst(() => false), undefined);
  assert.equal(q.remove('b'), true);
  assert.equal(q.remove('b'), false);
  assert.equal(q.takeFirst(() => true), 'c');
  assert.equal(q.size, 0);
});

test('PriorityQueue: an item pushed again with its old seq goes in front of later arrivals', () => {
  const q = new PriorityQueue();
  q.push('first', 0, 1);
  q.push('late', 0, 5);
  const f = q.takeFirst(() => true);
  q.push(f, 0, 1);
  assert.equal(q.takeFirst(() => true), 'first');
  assert.equal(q.takeFirst(() => true), 'late');
});
