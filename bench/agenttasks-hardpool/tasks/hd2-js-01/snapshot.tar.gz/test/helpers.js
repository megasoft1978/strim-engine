/** Deterministic clock: time only moves through advance(). */
export class FakeClock {
  #now = 0;
  #id = 0;
  #timers = new Map();

  now() {
    return this.#now;
  }

  setTimeout(fn, ms) {
    const id = ++this.#id;
    this.#timers.set(id, { at: this.#now + ms, fn, id });
    return id;
  }

  clearTimeout(id) {
    this.#timers.delete(id);
  }

  get pending() {
    return this.#timers.size;
  }

  /** Moves time forward, firing due timers in (time, creation) order, including timers they create. */
  advance(ms) {
    const target = this.#now + ms;
    for (;;) {
      const due = [...this.#timers.values()].filter((t) => t.at <= target).sort((a, b) => a.at - b.at || a.id - b.id)[0];
      if (!due) break;
      this.#timers.delete(due.id);
      this.#now = Math.max(this.#now, due.at);
      due.fn();
    }
    this.#now = target;
  }
}

/** Lets pending promise reactions run. */
export const flush = () => new Promise((resolve) => setImmediate(resolve));

/** A job function whose attempts are completed by hand. Every call is appended to `log` as `name#attempt`. */
export function job(log, name) {
  const j = { name, ctxs: [], pending: [] };
  j.fn = (ctx) => {
    log.push(`${name}#${ctx.attempt}`);
    j.ctxs.push(ctx);
    let resolve;
    let reject;
    const promise = new Promise((res, rej) => ((resolve = res), (reject = rej)));
    j.pending.push({ resolve, reject });
    return promise;
  };
  j.ok = (value) => j.pending.shift().resolve(value);
  j.fail = (error) => j.pending.shift().reject(error);
  return j;
}

/** Observes a promise without leaving an unhandled rejection. */
export function track(promise) {
  const t = { state: 'pending', value: undefined };
  promise.then(
    (value) => Object.assign(t, { state: 'ok', value }),
    (value) => Object.assign(t, { state: 'err', value }),
  );
  return t;
}
