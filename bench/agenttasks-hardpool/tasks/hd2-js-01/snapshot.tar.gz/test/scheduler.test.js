import test from 'node:test';
import assert from 'node:assert/strict';
import { Scheduler, CancelledError } from '../src/index.js';
import { FakeClock, flush, job, track } from './helpers.js';

function setup(concurrency = 1) {
  const clock = new FakeClock();
  const log = [];
  return { clock, log, s: new Scheduler({ concurrency, clock }) };
}

test('runs at most `concurrency` jobs at once and starts the next one when a slot frees', async () => {
  const { s, log } = setup(2);
  const [a, b, c, d] = ['a', 'b', 'c', 'd'].map((n) => job(log, n));
  const results = [a, b, c, d].map((j) => track(s.schedule(j.fn)));
  assert.deepEqual(log, ['a#1', 'b#1']);
  assert.deepEqual(s.stats(), { queued: 2, running: 2, waiting: 0 });
  b.ok('B');
  await flush();
  assert.deepEqual(log, ['a#1', 'b#1', 'c#1']);
  assert.deepEqual(results[1], { state: 'ok', value: 'B' });
  a.ok('A');
  c.ok('C');
  await flush();
  assert.deepEqual(log, ['a#1', 'b#1', 'c#1', 'd#1']);
  d.ok('D');
  await flush();
  assert.deepEqual(s.stats(), { queued: 0, running: 0, waiting: 0 });
});

test('a job starts synchronously inside schedule when a slot is free', () => {
  const { s, log } = setup(1);
  const a = job(log, 'a');
  s.schedule(a.fn);
  assert.deepEqual(log, ['a#1']);
});

test('higher priority first, arrival order among equals', async () => {
  const { s, log } = setup(1);
  const run = job(log, 'run');
  s.schedule(run.fn);
  const jobs = [['low', 0], ['high1', 5], ['neg', -3], ['high2', 5], ['mid', 2]].map(([n, p]) => [job(log, n), p]);
  for (const [j, p] of jobs) s.schedule(j.fn, { priority: p });
  run.ok();
  for (const [j] of jobs.slice().sort((x, y) => y[1] - x[1] || jobs.indexOf(x) - jobs.indexOf(y))) {
    await flush();
    j.ok();
  }
  await flush();
  assert.deepEqual(log, ['run#1', 'high1#1', 'high2#1', 'mid#1', 'low#1', 'neg#1']);
});

test('jobs with the same key never overlap, and a blocked job does not hold up others', async () => {
  const { s, log } = setup(3);
  const a1 = job(log, 'a1');
  const a2 = job(log, 'a2');
  const b1 = job(log, 'b1');
  const c1 = job(log, 'c1');
  s.schedule(a1.fn, { key: 'a' });
  s.schedule(a2.fn, { key: 'a' });
  s.schedule(b1.fn, { key: 'b' });
  s.schedule(c1.fn);
  assert.deepEqual(log, ['a1#1', 'b1#1', 'c1#1']);
  assert.deepEqual(s.stats(), { queued: 1, running: 3, waiting: 0 });
  a1.ok();
  await flush();
  assert.deepEqual(log, ['a1#1', 'b1#1', 'c1#1', 'a2#1']);
});

test('a key-blocked job keeps its place in line for its own key', async () => {
  const { s, log } = setup(2);
  const a1 = job(log, 'a1');
  const a2 = job(log, 'a2');
  const a3 = job(log, 'a3');
  const z = job(log, 'z');
  s.schedule(a1.fn, { key: 'a' });
  s.schedule(a2.fn, { key: 'a' });
  s.schedule(a3.fn, { key: 'a', priority: 1 });
  s.schedule(z.fn, { priority: -1 });
  assert.deepEqual(log, ['a1#1', 'z#1']);
  a1.ok();
  await flush();
  assert.deepEqual(log, ['a1#1', 'z#1', 'a3#1']);
  a3.ok();
  await flush();
  assert.deepEqual(log, ['a1#1', 'z#1', 'a3#1', 'a2#1']);
});

test('retries with exponential backoff measured on the injected clock', async () => {
  const { s, log, clock } = setup(1);
  const a = job(log, 'a');
  const r = track(s.schedule(a.fn, { retries: 2, backoff: { baseMs: 100, factor: 2 } }));
  a.fail(new Error('e1'));
  await flush();
  assert.deepEqual(s.stats(), { queued: 0, running: 0, waiting: 1 });
  clock.advance(99);
  assert.deepEqual(log, ['a#1']);
  clock.advance(1);
  assert.deepEqual(log, ['a#1', 'a#2']);
  a.fail(new Error('e2'));
  await flush();
  clock.advance(199);
  assert.deepEqual(log, ['a#1', 'a#2']);
  clock.advance(1);
  assert.deepEqual(log, ['a#1', 'a#2', 'a#3']);
  assert.equal(a.ctxs[2].attempt, 3);
  a.ok('done');
  await flush();
  assert.deepEqual(r, { state: 'ok', value: 'done' });
  assert.equal(clock.pending, 0);
});

test('backoff delay is capped by maxMs', async () => {
  const { s, log, clock } = setup(1);
  const a = job(log, 'a');
  s.schedule(a.fn, { retries: 3, backoff: { baseMs: 100, factor: 10, maxMs: 250 } }).catch(() => {});
  for (const wait of [100, 250, 250]) {
    a.fail(new Error('x'));
    await flush();
    const before = log.length;
    clock.advance(wait - 1);
    assert.equal(log.length, before);
    clock.advance(1);
    assert.equal(log.length, before + 1);
  }
});

test('rejects with the last error once retries are used up; sync throws count as failures', async () => {
  const { s, clock } = setup(1);
  let calls = 0;
  const r = track(
    s.schedule(
      () => {
        calls++;
        throw new Error(`boom${calls}`);
      },
      { retries: 1, backoff: { baseMs: 10 } },
    ),
  );
  await flush();
  clock.advance(10);
  await flush();
  assert.equal(calls, 2);
  assert.equal(r.state, 'err');
  assert.equal(r.value.message, 'boom2');
  assert.deepEqual(s.stats(), { queued: 0, running: 0, waiting: 0 });
});

test('shouldRetry sees (error, attempt) and can stop retries; CancelledError is never retried', async () => {
  const { s, clock } = setup(1);
  const seen = [];
  let n = 0;
  const r1 = track(
    s.schedule(
      async () => {
        n++;
        throw Object.assign(new Error('x'), { fatal: n === 2 });
      },
      { retries: 5, backoff: { baseMs: 1 }, shouldRetry: (e, attempt) => (seen.push(attempt), !e.fatal) },
    ),
  );
  await flush();
  clock.advance(1);
  await flush();
  assert.deepEqual(seen, [1, 2]);
  assert.equal(r1.state, 'err');
  assert.equal(n, 2);

  let m = 0;
  const r2 = track(s.schedule(async () => (m++, Promise.reject(new CancelledError())), { retries: 3 }));
  await flush();
  assert.equal(m, 1);
  assert.equal(r2.value instanceof CancelledError, true);
});

test('while backing off a job frees its slot but keeps its key', async () => {
  const { s, log, clock } = setup(2);
  const x = job(log, 'x');
  const y = job(log, 'y');
  const z = job(log, 'z');
  s.schedule(x.fn, { key: 'k', retries: 1, backoff: { baseMs: 50 } });
  s.schedule(z.fn, { key: 'k' });
  s.schedule(y.fn);
  assert.deepEqual(log, ['x#1', 'y#1']);
  x.fail(new Error('x'));
  await flush();
  assert.deepEqual(s.stats(), { queued: 1, running: 1, waiting: 1 });
  assert.deepEqual(log, ['x#1', 'y#1']);
  clock.advance(50);
  assert.deepEqual(log, ['x#1', 'y#1', 'x#2']);
  x.ok();
  await flush();
  assert.deepEqual(log, ['x#1', 'y#1', 'x#2', 'z#1']);
});

test('a retry goes back into the queue with its original priority and arrival order', async () => {
  const { s, log, clock } = setup(1);
  const x = job(log, 'x');
  const q = job(log, 'q');
  const w = job(log, 'w');
  const hi = job(log, 'hi');
  s.schedule(x.fn, { retries: 1, backoff: { baseMs: 10 } });
  s.schedule(q.fn);
  x.fail(new Error('x'));
  await flush();
  assert.deepEqual(log, ['x#1', 'q#1']);
  s.schedule(w.fn);
  s.schedule(hi.fn, { priority: 9 });
  clock.advance(10);
  q.ok();
  await flush();
  assert.deepEqual(log, ['x#1', 'q#1', 'hi#1']);
  hi.ok();
  await flush();
  assert.deepEqual(log, ['x#1', 'q#1', 'hi#1', 'x#2']);
  x.ok();
  await flush();
  assert.deepEqual(log, ['x#1', 'q#1', 'hi#1', 'x#2', 'w#1']);
});

test('an already aborted signal rejects without calling the job', async () => {
  const { s, log } = setup(1);
  const ac = new AbortController();
  ac.abort();
  const a = job(log, 'a');
  const r = track(s.schedule(a.fn, { signal: ac.signal }));
  await flush();
  assert.equal(r.state, 'err');
  assert.equal(r.value instanceof CancelledError, true);
  assert.deepEqual(log, []);
  assert.deepEqual(s.stats(), { queued: 0, running: 0, waiting: 0 });
});

test('aborting a queued job removes it and never runs it', async () => {
  const { s, log } = setup(1);
  const run = job(log, 'run');
  const q = job(log, 'q');
  const after = job(log, 'after');
  const ac = new AbortController();
  s.schedule(run.fn);
  const r = track(s.schedule(q.fn, { signal: ac.signal }));
  s.schedule(after.fn);
  ac.abort();
  await flush();
  assert.equal(r.value instanceof CancelledError, true);
  assert.deepEqual(s.stats(), { queued: 1, running: 1, waiting: 0 });
  run.ok();
  await flush();
  assert.deepEqual(log, ['run#1', 'after#1']);
});

test('aborting during backoff clears the timer, frees the key and rejects', async () => {
  const { s, log, clock } = setup(2);
  const x = job(log, 'x');
  const z = job(log, 'z');
  const ac = new AbortController();
  const r = track(s.schedule(x.fn, { key: 'k', retries: 2, signal: ac.signal, backoff: { baseMs: 100 } }));
  s.schedule(z.fn, { key: 'k' });
  x.fail(new Error('x'));
  await flush();
  assert.equal(clock.pending, 1);
  assert.deepEqual(log, ['x#1']);
  ac.abort();
  assert.equal(clock.pending, 0);
  assert.deepEqual(log, ['x#1', 'z#1']);
  await flush();
  assert.equal(r.value instanceof CancelledError, true);
  clock.advance(1000);
  assert.deepEqual(log, ['x#1', 'z#1']);
});

test('aborting a running job rejects at once but its slot and key stay busy until it settles', async () => {
  const { s, log } = setup(1);
  const x = job(log, 'x');
  const y = job(log, 'y');
  const ac = new AbortController();
  const r = track(s.schedule(x.fn, { key: 'k', retries: 3, signal: ac.signal }));
  s.schedule(y.fn);
  ac.abort();
  assert.equal(x.ctxs[0].signal.aborted, true);
  await flush();
  assert.equal(r.state, 'err');
  assert.equal(r.value instanceof CancelledError, true);
  assert.deepEqual(s.stats(), { queued: 1, running: 1, waiting: 0 });
  assert.deepEqual(log, ['x#1']);
  x.fail(new Error('late'));
  await flush();
  assert.deepEqual(log, ['x#1', 'y#1']);
  assert.equal(r.value instanceof CancelledError, true);
});

test('a result that arrives after an abort is ignored and the key is then free again', async () => {
  const { s, log } = setup(2);
  const x = job(log, 'x');
  const z = job(log, 'z');
  const ac = new AbortController();
  const r = track(s.schedule(x.fn, { key: 'k', signal: ac.signal }));
  s.schedule(z.fn, { key: 'k' });
  ac.abort();
  await flush();
  assert.deepEqual(log, ['x#1']);
  x.ok('late');
  await flush();
  assert.equal(r.value instanceof CancelledError, true);
  assert.deepEqual(log, ['x#1', 'z#1']);
});

test('idle() resolves only when queued, running and backing-off jobs are all done', async () => {
  const { s, log, clock } = setup(1);
  await s.idle();
  const a = job(log, 'a');
  const b = job(log, 'b');
  s.schedule(a.fn, { retries: 1, backoff: { baseMs: 20 } });
  s.schedule(b.fn);
  let idle = false;
  s.idle().then(() => (idle = true));
  a.fail(new Error('x'));
  await flush();
  b.ok();
  await flush();
  assert.equal(idle, false);
  clock.advance(20);
  await flush();
  assert.equal(idle, false);
  a.ok();
  await flush();
  assert.equal(idle, true);
});

test('constructor and option validation', () => {
  const clock = new FakeClock();
  assert.throws(() => new Scheduler({ concurrency: 0, clock }), TypeError);
  assert.throws(() => new Scheduler({ concurrency: 1 }), TypeError);
  const s = new Scheduler({ clock });
  assert.throws(() => s.schedule(async () => 1, { retries: -1 }), TypeError);
});
