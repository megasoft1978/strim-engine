import { test, expect } from 'bun:test';
import { renderToStaticMarkup } from 'react-dom/server';
import { pages } from '../src/pages.js';
import { Pagination } from '../src/Pagination.jsx';

test('pages without gaps for small totals', () => {
  expect(pages(1, 1)).toEqual([1]);
  expect(pages(2, 3)).toEqual([1, 2, 3]);
  expect(pages(1, 0)).toEqual([]);
});

test('pages collapses distant ranges', () => {
  expect(pages(5, 10)).toEqual([1, '…', 4, 5, 6, '…', 10]);
  expect(pages(1, 10)).toEqual([1, 2, '…', 10]);
  expect(pages(10, 10)).toEqual([1, '…', 9, 10]);
  expect(pages(4, 10)).toEqual([1, 2, 3, 4, 5, '…', 10]);
});

test('a gap of exactly one page shows that page instead of an ellipsis', () => {
  expect(pages(4, 8)).toEqual([1, 2, 3, 4, 5, '…', 8]);
  expect(pages(5, 8)).toEqual([1, '…', 4, 5, 6, 7, 8]);
});

test('siblings option', () => {
  expect(pages(6, 12, 2)).toEqual([1, '…', 4, 5, 6, 7, 8, '…', 12]);
});

test('markup marks the current page and links the others', () => {
  const html = renderToStaticMarkup(<Pagination current={2} total={3} />);
  expect(html).toContain('<a href="?page=2" aria-current="page">2</a>');
  expect(html).toContain('<a href="?page=3">3</a>');
  expect(html).not.toContain('gap');
});

test('prev and next are disabled at the ends', () => {
  const first = renderToStaticMarkup(<Pagination current={1} total={5} />);
  expect(first).toContain('<button type="button" class="prev" disabled="">Prev</button>');
  expect(first).toContain('<button type="button" class="next">Next</button>');
  const last = renderToStaticMarkup(<Pagination current={5} total={5} />);
  expect(last).toContain('<button type="button" class="prev">Prev</button>');
  expect(last).toContain('<button type="button" class="next" disabled="">Next</button>');
});
