/**
 * Page numbers to show for `current` (1-based) of `total`, with `siblings` neighbours on each side.
 * First and last pages are always present; gaps become the string "…".
 * pages(5, 10) -> [1, "…", 4, 5, 6, "…", 10]
 */
export function pages(current, total, siblings = 1) {
  if (total <= 0) return [];
  const start = Math.max(2, current - siblings);
  const end = Math.min(total - 1, current + siblings);
  const out = [1];
  if (start > 2) out.push('…');
  for (let p = start; p <= end; p++) out.push(p);
  if (end < total - 1) out.push('…');
  if (total > 1) out.push(total);
  return out;
}
