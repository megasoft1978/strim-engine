import { pages } from './pages.js';

export function Pagination({ current, total, siblings = 1 }) {
  const items = pages(current, total, siblings);
  return (
    <nav aria-label="pagination">
      <button type="button" className="prev" disabled={current <= 1}>
        Prev
      </button>
      <ul>
        {items.map((p, i) =>
          p === '…' ? (
            <li key={`gap-${i}`} className="gap">…</li>
          ) : (
            <li key={p}>
              <a href={`?page=${p}`} aria-current={p === current ? 'page' : undefined}>{p}</a>
            </li>
          ),
        )}
      </ul>
      <button type="button" className="next" disabled={current > total}>
        Next
      </button>
    </nav>
  );
}
