import test from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig, clearConfigCache, quote } from '../lib/index.js';

test('configs are cached per region and carry overrides', () => {
  assert.equal(loadConfig('de'), loadConfig('de'));
  assert.equal(loadConfig('de').taxRate, 0.19);
  assert.equal(loadConfig().taxRate, 0.2);
  assert.equal(loadConfig('ch').currency, 'CHF');
});

test('clearing the cache rebuilds configs', () => {
  const a = loadConfig('us');
  clearConfigCache();
  assert.notEqual(loadConfig('us'), a);
  assert.deepEqual(loadConfig('us').tiers, a.tiers);
});

test('cached tiers stay in ascending order after quoting', () => {
  quote([{ price: 70000, qty: 1 }]);
  quote([{ price: 70000, qty: 1 }], 'ch');
  assert.deepEqual(loadConfig().tiers.map((t) => t.min), [0, 10000, 50000]);
  assert.deepEqual(loadConfig('us').tiers.map((t) => t.min), [0, 10000, 50000]);
  assert.deepEqual(loadConfig('ch').tiers.map((t) => t.min), [0, 20000]);
});
