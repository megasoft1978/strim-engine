import test from 'node:test';
import assert from 'node:assert/strict';
import { quote, summary, tierTable } from '../lib/index.js';

test('summary formats money', () => {
  assert.equal(
    summary(quote([item(10000)])),
    'subtotal 100.00 EUR, discount 5.00 EUR, tax 19.00 EUR, total 114.00 EUR',
  );
});

test('tier table lists the default tiers', () => {
  assert.deepEqual(tierTable(), ['from 0 EUR: 0%', 'from 100 EUR: 5%', 'from 500 EUR: 10%']);
});

test('tier table after a few quotes', () => {
  quote([item(60000)]);
  quote([item(500)]);
  assert.deepEqual(tierTable('de'), ['from 0 EUR: 0%', 'from 100 EUR: 5%', 'from 500 EUR: 10%']);
  assert.deepEqual(tierTable('ch'), ['from 0 CHF: 0%', 'from 200 CHF: 3%']);
});

function item(price, qty = 1) {
  return { price, qty };
}
