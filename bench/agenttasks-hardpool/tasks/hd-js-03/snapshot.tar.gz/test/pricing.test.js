import test from 'node:test';
import assert from 'node:assert/strict';
import { quote } from '../lib/index.js';

const item = (price, qty = 1) => ({ price, qty });

test('no discount below the first threshold', () => {
  assert.deepEqual(quote([item(2500, 2)]), { currency: 'EUR', subtotal: 5000, discount: 0, tax: 1000, total: 6000 });
});

test('discount tiers apply at their threshold', () => {
  assert.equal(quote([item(10000)]).discount, 500);
  assert.equal(quote([item(9999)]).discount, 0);
  assert.equal(quote([item(25000, 2)]).discount, 5000);
});

test('regions change currency, tax and tiers', () => {
  assert.deepEqual(quote([item(20000)], 'ch'), { currency: 'CHF', subtotal: 20000, discount: 600, tax: 1571, total: 20971 });
  assert.equal(quote([item(10000)], 'ch').discount, 0);
  assert.equal(quote([item(10000)], 'de').tax, 1805);
  assert.equal(quote([item(10000)], 'us').total, 9500);
});

test('quotes are repeatable and independent of earlier calls', () => {
  const first = quote([item(60000)]);
  quote([item(100)]);
  quote([item(30000)], 'de');
  assert.deepEqual(quote([item(60000)]), first);
});

test('unknown region is rejected', () => {
  assert.throws(() => quote([item(1)], 'xx'), RangeError);
});
