/** Grams -> "250 g" below one kilogram, "1.5 kg" from there on (at most two decimals). */
export function formatWeight(grams) {
  if (grams < 1000) return `${grams} g`;
  return `${Number((grams / 1000).toFixed(2))} kg`;
}

/** "1 item", "3 items", "no items". */
export function pluralize(n, one, many = `${one}s`) {
  if (n === 0) return `no ${many}`;
  return n === 1 ? `1 ${one}` : `${n} ${many}`;
}
