import { sumCents } from './money.js';
import { taxCents } from './tax.js';

/** Items are { sku, price (cents), qty, weightKg }. All money fields of the result are integer cents. */
export function computeTotals(items, discountPct, taxPct) {
  const subtotal = sumCents(items.map((it) => it.price * it.qty));
  const discount = Math.round((subtotal * discountPct) / 100);
  const taxable = subtotal - discount;
  const tax = taxCents(taxable, taxPct);
  const weightKg = items.reduce((kg, it) => kg + it.weightKg * it.qty, 0);
  return { subtotal, discount, tax, total: taxable + tax, weightKg };
}

/** Memoizes the last call; a new result is computed whenever any argument changes. */
export function makeTotalsSelector() {
  let last = null;
  let result = null;
  return (items, discountPct, taxPct) => {
    const args = [items, discountPct, taxPct];
    if (last && last[0] === items && last[2] === taxPct) return result;
    last = args;
    result = computeTotals(items, discountPct, taxPct);
    return result;
  };
}
