import { formatMoney } from './money.js';
import { formatWeight, pluralize } from './units.js';

export function LineItems({ items }) {
  const units = items.reduce((n, it) => n + it.qty, 0);
  return (
    <section className="lines">
      <h3>{pluralize(units, 'item')}</h3>
      <ul>
        {items.map((it) => (
          <li key={it.sku} data-sku={it.sku}>
            <span className="qty">{it.qty} x</span>
            <span className="line-total">{formatMoney(it.price * it.qty)}</span>
            <span className="line-weight">{formatWeight(Math.round(it.weightKg * it.qty * 1000))}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}
