/** Integer cents -> "$1,234.50"; negative amounts keep the sign in front: -250 -> "-$2.50". */
export function formatMoney(cents) {
  const sign = cents < 0 ? '-' : '';
  const abs = Math.abs(cents);
  const dollars = String(Math.floor(abs / 100)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `${sign}$${dollars}.${String(abs % 100).padStart(2, '0')}`;
}

export function sumCents(values) {
  return values.reduce((sum, v) => sum + v, 0);
}
