/** Tax in whole cents for an amount in cents at `ratePct` percent (8.5 means 8.5%), rounded half up. */
export function taxCents(amountCents, ratePct) {
  return Math.round(amountCents * ratePct) / 10000;
}
