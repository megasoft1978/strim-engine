import { LineItems } from './LineItems.jsx';
import { formatMoney } from './money.js';
import { makeTotalsSelector } from './selectors.js';
import { formatWeight } from './units.js';

const selectTotals = makeTotalsSelector();

export function Summary({ items, discountPct = 0, taxPct = 8 }) {
  const t = selectTotals(items, discountPct, taxPct);
  return (
    <div className="order">
    <LineItems items={items} />
    <dl className="summary">
      <dt>Subtotal</dt>
      <dd className="subtotal">{formatMoney(t.subtotal)}</dd>
      {t.discount > 0 && (
        <>
          <dt>Discount ({discountPct}%)</dt>
          <dd className="discount">{formatMoney(-t.discount)}</dd>
        </>
      )}
      <dt>Tax ({taxPct}%)</dt>
      <dd className="tax">{formatMoney(t.tax)}</dd>
      <dt>Total</dt>
      <dd className="total">{formatMoney(t.total)}</dd>
      <dt>Weight</dt>
      <dd className="weight">{formatWeight(t.weightKg)}</dd>
    </dl>
    </div>
  );
}
