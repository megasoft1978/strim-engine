import { test, expect } from 'bun:test';
import { renderToStaticMarkup } from 'react-dom/server';
import { formatMoney } from '../src/money.js';
import { formatWeight } from '../src/units.js';
import { computeTotals, makeTotalsSelector } from '../src/selectors.js';
import { Summary } from '../src/Summary.jsx';

const items = [
  { sku: 'a', price: 1999, qty: 2, weightKg: 0.4 },
  { sku: 'b', price: 550, qty: 1, weightKg: 1.2 },
];
const cell = (html, cls) => html.match(new RegExp(`<dd class="${cls}">([^<]*)</dd>`))?.[1];
const render = (props) => renderToStaticMarkup(<Summary items={items} {...props} />);

test('formatMoney pads cents, groups thousands and keeps the sign in front', () => {
  expect(formatMoney(5)).toBe('$0.05');
  expect(formatMoney(123456)).toBe('$1,234.56');
  expect(formatMoney(-250)).toBe('-$2.50');
});

test('formatWeight takes grams', () => {
  expect(formatWeight(250)).toBe('250 g');
  expect(formatWeight(1500)).toBe('1.5 kg');
  expect(formatWeight(2000)).toBe('2 kg');
  expect(formatWeight(1234)).toBe('1.23 kg');
});

test('computeTotals returns integer cents', () => {
  const t = computeTotals(items, 10, 8);
  expect(t).toMatchObject({ subtotal: 4548, discount: 455, tax: 327, total: 4420 });
  expect(Number.isInteger(t.tax) && Number.isInteger(t.total)).toBe(true);
});

test('summary shows subtotal, tax, total and weight without a discount', () => {
  const html = render({});
  expect(cell(html, 'subtotal')).toBe('$45.48');
  expect(cell(html, 'tax')).toBe('$3.64');
  expect(cell(html, 'total')).toBe('$49.12');
  expect(cell(html, 'weight')).toBe('2 kg');
  expect(html).not.toContain('class="discount"');
});

test('summary applies the discount before tax', () => {
  const html = render({ discountPct: 10 });
  expect(cell(html, 'discount')).toBe('-$4.55');
  expect(cell(html, 'tax')).toBe('$3.27');
  expect(cell(html, 'total')).toBe('$44.20');
  expect(html).toContain('Tax (8%)');
});

test('summary follows a changed discount for the very same items array', () => {
  expect(cell(render({ discountPct: 10 }), 'total')).toBe('$44.20');
  expect(cell(render({ discountPct: 50 }), 'total')).toBe('$24.56');
  expect(cell(render({ discountPct: 0 }), 'total')).toBe('$49.12');
});

test('summary follows a changed tax rate and different items', () => {
  expect(cell(render({ taxPct: 8.5 }), 'tax')).toBe('$3.87');
  const light = [{ sku: 'c', price: 1000, qty: 3, weightKg: 0.25 }];
  const html = renderToStaticMarkup(<Summary items={light} taxPct={0} />);
  expect(cell(html, 'total')).toBe('$30.00');
  expect(cell(html, 'weight')).toBe('750 g');
});

test('weights of a kilogram or more switch unit', () => {
  const one = [{ sku: 'd', price: 100, qty: 1, weightKg: 1.5 }];
  expect(cell(renderToStaticMarkup(<Summary items={one} />), 'weight')).toBe('1.5 kg');
});

test('the selector reuses its result only for identical arguments', () => {
  const select = makeTotalsSelector();
  const first = select(items, 10, 8);
  expect(select(items, 10, 8)).toBe(first);
  expect(select(items, 20, 8)).not.toBe(first);
  expect(select(items, 20, 8).discount).toBe(910);
  expect(select(items.slice(), 20, 8)).not.toBe(select(items, 20, 8));
});

test('line items list per-line totals and weights, and the item count', () => {
  const html = render({});
  expect(html).toContain('<h3>3 items</h3>');
  expect(html).toContain('<li data-sku="a"><span class="qty">2 x</span><span class="line-total">$39.98</span><span class="line-weight">800 g</span></li>');
  expect(html).toContain('<span class="line-total">$5.50</span><span class="line-weight">1.2 kg</span>');
  expect(renderToStaticMarkup(<Summary items={[]} />)).toContain('<h3>no items</h3>');
});
