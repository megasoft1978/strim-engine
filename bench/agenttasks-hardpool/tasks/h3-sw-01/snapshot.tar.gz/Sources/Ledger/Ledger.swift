import Foundation

public final class Ledger {
    public let store: Store
    private let cache = BalanceCache()

    public init(store: Store = Store()) {
        self.store = store
    }

    public func balance(account id: String) throws -> Int {
        guard let account = store.account(id) else { throw LedgerError.missingAccount }
        if let cached = cache.get(id, revision: store.revision) { return cached }
        let transactions = store.allTransactions().filter { $0.account == id }
        let total = try sumCents(transactions.map { $0.amount })
        let result = try addCents(account.opening, total)
        cache.put(result, account: id, revision: store.revision)
        return result
    }

    public func statement(account id: String, from: Int, until: Int) throws -> Statement {
        guard let account = store.account(id) else { throw LedgerError.missingAccount }
        guard from < until else { throw LedgerError.invalidRange }
        let all = try selectTransactions(store.allTransactions(), filter: TransactionFilter(account: id))
        let preceding = all.filter { $0.date <= from }
        let opening = try addCents(account.opening, sumCents(preceding.map { $0.amount }))
        let period = all.filter { $0.date >= from && $0.date < until }
        return try makeStatement(opening: opening, transactions: period)
    }
}
