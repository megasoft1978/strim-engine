import Foundation

public struct Transaction: Equatable {
    public let id: String
    public let account: String
    public let amount: Int
    public let date: Int
    public let category: String
    public init(id: String, account: String, amount: Int, date: Int, category: String) {
        self.id = id
        self.account = account
        self.amount = amount
        self.date = date
        self.category = category
    }
}

public struct Account: Equatable {
    public let id: String
    public var opening: Int
    public var name: String
    public init(id: String, opening: Int, name: String) {
        self.id = id
        self.opening = opening
        self.name = name
    }
}

public enum LedgerError: Error, Equatable {
    case invalidID
    case duplicateID
    case missingAccount
    case missingTransaction
    case overflow
    case invalidRange
}
