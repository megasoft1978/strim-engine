import Foundation

/// Cached totals by account. Values are valid for a specific store revision.
final class BalanceCache {
    private var values: [String: Int] = [:]

    func get(_ account: String, revision: Int) -> Int? {
        values[account]
    }

    func put(_ value: Int, account: String, revision: Int) {
        values[account] = value
    }

    func clear() {
        values.removeAll()
    }
}
