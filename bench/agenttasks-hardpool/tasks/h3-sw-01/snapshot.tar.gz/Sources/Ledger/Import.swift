import Foundation

/// A compact tab-separated format for transaction exchange.
public func exportTransactions(_ transactions: [Transaction]) throws -> String {
    var rows: [String] = []
    for item in transactions {
        let fields = [item.id, item.account, String(item.amount), String(item.date), item.category]
        guard fields.allSatisfy({ !$0.contains("\t") && !$0.contains("\n") }) else { throw LedgerError.invalidID }
        rows.append(fields.joined(separator: "\t"))
    }
    return rows.joined(separator: "\n")
}

public func importTransactions(_ text: String) throws -> [Transaction] {
    if text.isEmpty { return [] }
    return try text.split(separator: "\n", omittingEmptySubsequences: false).map { row in
        let fields = row.split(separator: "\t", omittingEmptySubsequences: false).map(String.init)
        guard fields.count == 5, let amount = Int(fields[2]), let date = Int(fields[3]), !fields[0].isEmpty else {
            throw LedgerError.invalidID
        }
        return Transaction(id: fields[0], account: fields[1], amount: amount, date: date, category: fields[4])
    }
}
