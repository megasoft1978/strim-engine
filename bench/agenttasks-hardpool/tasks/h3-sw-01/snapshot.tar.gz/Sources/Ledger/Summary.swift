import Foundation

public struct CategoryTotal: Equatable {
    public let category: String
    public let count: Int
    public let amount: Int
}

public func categoryTotals(_ transactions: [Transaction]) throws -> [CategoryTotal] {
    var amounts: [String: Int] = [:]
    var counts: [String: Int] = [:]
    for transaction in transactions {
        amounts[transaction.category] = try addCents(amounts[transaction.category, default: 0], transaction.amount)
        counts[transaction.category, default: 0] += 1
    }
    return amounts.keys.sorted().map { category in
        CategoryTotal(category: category, count: counts[category, default: 0], amount: amounts[category, default: 0])
    }
}

public func dailyTotals(_ transactions: [Transaction]) throws -> [(date: Int, amount: Int)] {
    var amounts: [Int: Int] = [:]
    for transaction in transactions {
        amounts[transaction.date] = try addCents(amounts[transaction.date, default: 0], transaction.amount)
    }
    return amounts.keys.sorted().map { (date: $0, amount: amounts[$0, default: 0]) }
}

public func largestExpense(_ transactions: [Transaction]) -> Transaction? {
    transactions.filter { $0.amount < 0 }.sorted {
        $0.amount == $1.amount ? $0.id < $1.id : $0.amount < $1.amount
    }.first
}
