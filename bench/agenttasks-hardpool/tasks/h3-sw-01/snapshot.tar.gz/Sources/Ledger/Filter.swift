import Foundation

public struct TransactionFilter {
    public var account: String?
    public var category: String?
    public var from: Int?
    public var until: Int?
    public init(account: String? = nil, category: String? = nil, from: Int? = nil, until: Int? = nil) {
        self.account = account
        self.category = category
        self.from = from
        self.until = until
    }

    public func accepts(_ transaction: Transaction) -> Bool {
        if let account, account != transaction.account { return false }
        if let category, category != transaction.category { return false }
        if let from, transaction.date < from { return false }
        if let until, transaction.date >= until { return false }
        return true
    }

    public func validate() throws {
        if let from, let until, from >= until { throw LedgerError.invalidRange }
    }
}

public func selectTransactions(_ items: [Transaction], filter: TransactionFilter) throws -> [Transaction] {
    try filter.validate()
    return items.filter { filter.accepts($0) }.sorted {
        $0.date == $1.date ? $0.id < $1.id : $0.date < $1.date
    }
}
