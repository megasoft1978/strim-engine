import Foundation

public func addCents(_ left: Int, _ right: Int) throws -> Int {
    let (value, overflow) = left.addingReportingOverflow(right)
    guard !overflow else { throw LedgerError.overflow }
    return value
}

public func sumCents<S: Sequence>(_ amounts: S) throws -> Int where S.Element == Int {
    var total = 0
    for amount in amounts {
        total = try addCents(total, amount)
    }
    return total
}

public func formatCents(_ value: Int) -> String {
    let negative = value < 0
    let magnitude = value.magnitude
    let whole = magnitude / 100
    let fraction = magnitude % 100
    let fractionalText = fraction < 10 ? "0\(fraction)" : "\(fraction)"
    return "\(negative ? "-" : "")\(whole).\(fractionalText)"
}
