import Foundation

public struct StatementLine: Equatable {
    public let transaction: Transaction
    public let balance: Int
}

public struct Statement: Equatable {
    public let opening: Int
    public let lines: [StatementLine]
    public let closing: Int
}

public func makeStatement(opening: Int, transactions: [Transaction]) throws -> Statement {
    var current = opening
    var lines: [StatementLine] = []
    for transaction in transactions {
        current = try addCents(current, transaction.amount)
        lines.append(StatementLine(transaction: transaction, balance: current))
    }
    return Statement(opening: opening, lines: lines, closing: current)
}

public func renderStatement(_ statement: Statement) -> String {
    var rows = ["Opening \(formatCents(statement.opening))"]
    for line in statement.lines {
        rows.append("\(line.transaction.id) \(formatCents(line.transaction.amount)) \(formatCents(line.balance))")
    }
    rows.append("Closing \(formatCents(statement.closing))")
    return rows.joined(separator: "\n")
}
