import Foundation

public final class Store {
    private var accounts: [String: Account] = [:]
    private var transactions: [String: Transaction] = [:]
    public private(set) var revision: Int = 0

    public init() {}

    public func addAccount(_ account: Account) throws {
        guard !account.id.isEmpty else { throw LedgerError.invalidID }
        guard accounts[account.id] == nil else { throw LedgerError.duplicateID }
        accounts[account.id] = account
        revision += 1
    }

    public func account(_ id: String) -> Account? { accounts[id] }
    public func allAccounts() -> [Account] { accounts.values.sorted { $0.id < $1.id } }
    public func transaction(_ id: String) -> Transaction? { transactions[id] }
    public func allTransactions() -> [Transaction] { transactions.values.sorted { $0.id < $1.id } }

    public func put(_ transaction: Transaction) throws {
        guard !transaction.id.isEmpty else { throw LedgerError.invalidID }
        guard accounts[transaction.account] != nil else { throw LedgerError.missingAccount }
        transactions[transaction.id] = transaction
        revision += 1
    }

    public func remove(_ id: String) throws {
        guard transactions.removeValue(forKey: id) != nil else { throw LedgerError.missingTransaction }
        revision += 1
    }
}
