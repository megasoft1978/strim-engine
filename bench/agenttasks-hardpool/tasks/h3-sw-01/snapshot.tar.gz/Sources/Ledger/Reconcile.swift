import Foundation

public struct Reconciliation: Equatable {
    public let matched: [String]
    public let missing: [String]
    public let unexpected: [String]
    public let different: [String]
}

/// Compare imported records with local records by ID, independent of ordering.
public func reconcile(local: [Transaction], external: [Transaction]) throws -> Reconciliation {
    func index(_ records: [Transaction]) throws -> [String: Transaction] {
        var result: [String: Transaction] = [:]
        for item in records {
            guard !item.id.isEmpty else { throw LedgerError.invalidID }
            guard result[item.id] == nil else { throw LedgerError.duplicateID }
            result[item.id] = item
        }
        return result
    }
    let localIndex = try index(local)
    let externalIndex = try index(external)
    var matched: [String] = []
    var missing: [String] = []
    var unexpected: [String] = []
    var different: [String] = []
    for id in localIndex.keys.sorted() {
        guard let other = externalIndex[id] else {
            missing.append(id)
            continue
        }
        if localIndex[id] == other { matched.append(id) }
        else { different.append(id) }
    }
    for id in externalIndex.keys.sorted() where localIndex[id] == nil {
        unexpected.append(id)
    }
    return Reconciliation(matched: matched, missing: missing, unexpected: unexpected, different: different)
}
