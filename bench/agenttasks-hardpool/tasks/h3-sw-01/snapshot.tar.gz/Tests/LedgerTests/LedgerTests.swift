import XCTest
@testable import Ledger

final class LedgerTests: XCTestCase {
    func transaction(_ id: String, _ account: String, _ amount: Int, _ date: Int) -> Transaction {
        Transaction(id: id, account: account, amount: amount, date: date, category: "general")
    }

    func testBalanceReflectsExternalStoreMutationsAndReassignment() throws {
        let store = Store()
        try store.addAccount(Account(id: "a", opening: 100, name: "A"))
        try store.addAccount(Account(id: "b", opening: 200, name: "B"))
        try store.put(transaction("t", "a", 50, 2))
        let ledger = Ledger(store: store)
        XCTAssertEqual(try ledger.balance(account: "a"), 150)
        XCTAssertEqual(try ledger.balance(account: "b"), 200)
        try store.put(transaction("t", "b", -10, 2))
        XCTAssertEqual(try ledger.balance(account: "a"), 100)
        XCTAssertEqual(try ledger.balance(account: "b"), 190)
        try store.remove("t")
        XCTAssertEqual(try ledger.balance(account: "b"), 200)
    }

    func testStatementAtBoundaryHasOpeningAndClosingWithoutDoubleCounting() throws {
        let store = Store()
        try store.addAccount(Account(id: "a", opening: 100, name: "A"))
        try store.put(transaction("before", "a", 20, 4))
        try store.put(transaction("start", "a", -5, 5))
        try store.put(transaction("end", "a", 10, 10))
        let statement = try Ledger(store: store).statement(account: "a", from: 5, until: 10)
        XCTAssertEqual(statement.opening, 120)
        XCTAssertEqual(statement.lines.map { $0.transaction.id }, ["start"])
        XCTAssertEqual(statement.closing, 115)
    }

    func testHelpersAndOverflow() throws {
        let values = [transaction("x", "a", -45, 4), transaction("y", "a", 70, 5)]
        XCTAssertEqual(try importTransactions(exportTransactions(values)), values)
        XCTAssertEqual(try categoryTotals(values).first?.amount, 25)
        XCTAssertEqual(try reconcile(local: values, external: [values[1]]).missing, ["x"])
        XCTAssertEqual(formatCents(-45), "-0.45")
        XCTAssertThrowsError(try addCents(Int.max, 1))
        XCTAssertThrowsError(try selectTransactions(values, filter: TransactionFilter(from: 5, until: 5)))
    }
}
