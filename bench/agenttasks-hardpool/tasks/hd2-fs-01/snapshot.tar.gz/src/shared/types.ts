// Wire contract shared by the server and the client. Both sides import from here.

export type OrderStatus = 'open' | 'paid' | 'refunded';

export interface Order {
  id: string;
  /** Integer number of cents (never dollars, never a float). */
  totalCents: number;
  /** ISO-8601 UTC timestamp, e.g. "2024-03-05T10:00:00.000Z". */
  placedAt: string;
  /** null when the order has no note. The key is always present. */
  note: string | null;
  status: OrderStatus;
}

export interface OrderPage {
  items: Order[];
  /** Opaque cursor for the next page; null when this is the last page. */
  nextCursor: string | null;
}

/** Every non-2xx response body has exactly this shape. */
export interface ApiError {
  error: { code: string; message: string };
}

export interface HttpRequest {
  method: string;
  path: string;
  query: Record<string, string>;
}

export interface HttpResponse {
  status: number;
  body: unknown;
}
