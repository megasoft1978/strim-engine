import type { ApiError, Order, OrderPage, OrderStatus } from './types.ts';

export class SchemaError extends Error {}

const STATUSES: OrderStatus[] = ['open', 'paid', 'refunded'];

function obj(v: unknown, where: string): Record<string, unknown> {
  if (typeof v !== 'object' || v === null || Array.isArray(v)) throw new SchemaError(`${where}: expected object`);
  return v as Record<string, unknown>;
}

function str(v: unknown, where: string): string {
  if (typeof v !== 'string') throw new SchemaError(`${where}: expected string`);
  return v;
}

export function parseOrder(v: unknown): Order {
  const o = obj(v, 'order');
  const totalCents = o.totalCents;
  if (typeof totalCents !== 'number' || !Number.isInteger(totalCents)) {
    throw new SchemaError('order.totalCents: expected integer');
  }
  const placedAt = str(o.placedAt, 'order.placedAt');
  if (Number.isNaN(Date.parse(placedAt)) || !placedAt.endsWith('Z')) {
    throw new SchemaError('order.placedAt: expected ISO UTC timestamp');
  }
  const note = o.note;
  if (note !== null && typeof note !== 'string') throw new SchemaError('order.note: expected string or null');
  const status = str(o.status, 'order.status') as OrderStatus;
  if (!STATUSES.includes(status)) throw new SchemaError('order.status: unknown status');
  return { id: str(o.id, 'order.id'), totalCents, placedAt, note, status };
}

export function parseOrderPage(v: unknown): OrderPage {
  const p = obj(v, 'page');
  if (!Array.isArray(p.items)) throw new SchemaError('page.items: expected array');
  const nextCursor = p.nextCursor;
  if (nextCursor !== null && typeof nextCursor !== 'string') throw new SchemaError('page.nextCursor: expected string or null');
  return { items: p.items.map(parseOrder), nextCursor };
}

export function parseApiError(v: unknown): ApiError {
  const e = obj(obj(v, 'body').error, 'error');
  return { error: { code: str(e.code, 'error.code'), message: str(e.message, 'error.message') } };
}
