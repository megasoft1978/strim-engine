import type { HttpRequest, HttpResponse } from '../shared/types.ts';
import { CursorError, listPage, toWire, type OrderRecord } from './orders.ts';

const DEFAULT_LIMIT = 3;
const MAX_LIMIT = 5;

export function fail(status: number, code: string, message: string): HttpResponse {
  return { status, body: { code, message } };
}

export function handle(req: HttpRequest, records: OrderRecord[]): HttpResponse {
  if (req.method !== 'GET') return fail(405, 'method_not_allowed', `Method ${req.method} not allowed`);
  if (req.path === '/orders') {
    let limit = DEFAULT_LIMIT;
    if (req.query.limit !== undefined) {
      if (!/^[1-9]\d*$/.test(req.query.limit)) return fail(400, 'bad_limit', 'Limit must be a positive integer');
      limit = Math.min(Number(req.query.limit), MAX_LIMIT);
    }
    try {
      return { status: 200, body: listPage(records, req.query.cursor ?? null, limit) };
    } catch (e) {
      if (e instanceof CursorError) return fail(400, 'bad_cursor', e.message);
      throw e;
    }
  }
  const m = /^\/orders\/([^/]+)$/.exec(req.path);
  if (m) {
    const rec = records.find((r) => r.id === m[1]);
    return rec ? { status: 200, body: toWire(rec) } : fail(404, 'not_found', `Order ${m[1]} not found`);
  }
  return fail(404, 'not_found', `No route for ${req.path}`);
}
