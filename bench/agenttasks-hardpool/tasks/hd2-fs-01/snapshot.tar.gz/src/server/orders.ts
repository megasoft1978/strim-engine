import type { Order, OrderPage, OrderStatus } from '../shared/types.ts';

/** Storage shape: money in cents, time in epoch SECONDS. */
export interface OrderRecord {
  id: string;
  cents: number;
  placedAtSec: number;
  note: string | null;
  status: OrderStatus;
}

export class CursorError extends Error {}

export function toWire(r: OrderRecord): Order {
  return {
    id: r.id,
    totalCents: r.cents / 100,
    placedAt: new Date(r.placedAtSec).toISOString(),
    note: r.note ?? '',
    status: r.status,
  };
}

/** The cursor is the decimal index of the first item of the next page. */
export function listPage(records: OrderRecord[], cursor: string | null, limit: number): OrderPage {
  let start = 0;
  if (cursor !== null) {
    if (!/^\d+$/.test(cursor)) throw new CursorError(`Invalid cursor: ${cursor}`);
    start = Number(cursor);
  }
  const end = start + limit;
  return {
    items: records.slice(start, end).map(toWire),
    nextCursor: end < records.length ? String(end - 1) : null,
  };
}
