import type { Order } from '../shared/types.ts';
import type { Result } from './api.ts';
import { formatDay, formatMoney } from './format.ts';

export function OrderRow({ order }: { order: Order }) {
  return (
    <li data-id={order.id} className={`order ${order.status}`}>
      <span className="id">{order.id}</span>
      <span className="total">{formatMoney(order.totalCents)}</span>
      <time dateTime={order.placedAt}>{formatDay(order.placedAt)}</time>
      {order.note !== null && <p className="note">{order.note}</p>}
    </li>
  );
}

export function OrderFeed({ result }: { result: Result<Order[]> }) {
  if (!result.ok) return <div role="alert" className="error">{result.error.message}</div>;
  if (result.value.length === 0) return <p className="empty">No orders yet</p>;
  return (
    <ul className="orders">
      {result.value.map((o) => (
        <OrderRow key={o.id} order={o} />
      ))}
    </ul>
  );
}
