import { parseApiError, parseOrder, parseOrderPage, SchemaError } from '../shared/schema.ts';
import type { HttpRequest, HttpResponse, Order, OrderPage } from '../shared/types.ts';

export type Transport = (req: HttpRequest) => Promise<HttpResponse>;
export type Result<T> = { ok: true; value: T } | { ok: false; error: { code: string; message: string } };

async function call<T>(transport: Transport, req: HttpRequest, parse: (v: unknown) => T): Promise<Result<T>> {
  const res = await transport(req);
  if (res.status >= 200 && res.status < 300) {
    try {
      return { ok: true, value: parse(res.body) };
    } catch (e) {
      if (e instanceof SchemaError) return { ok: false, error: { code: 'bad_response', message: e.message } };
      throw e;
    }
  }
  try {
    return { ok: false, error: parseApiError(res.body).error };
  } catch {
    return { ok: false, error: { code: 'unknown', message: `Unexpected error (HTTP ${res.status})` } };
  }
}

export function createClient(transport: Transport) {
  return {
    listOrders(cursor?: string, limit?: number): Promise<Result<OrderPage>> {
      const query: Record<string, string> = {};
      if (cursor !== undefined) query.cursor = cursor;
      if (limit !== undefined) query.limit = String(limit);
      return call(transport, { method: 'GET', path: '/orders', query }, parseOrderPage);
    },
    getOrder(id: string): Promise<Result<Order>> {
      return call(transport, { method: 'GET', path: `/orders/${id}`, query: {} }, parseOrder);
    },
    /** Follows nextCursor until it is null; stops at the first error. */
    async listAll(limit: number): Promise<Result<Order[]>> {
      const all: Order[] = [];
      let cursor: string | undefined;
      for (let guard = 0; guard < 20; guard++) {
        const r = await this.listOrders(cursor, limit);
        if (!r.ok) return r;
        all.push(...r.value.items);
        if (r.value.nextCursor === null) return { ok: true, value: all };
        cursor = r.value.nextCursor;
      }
      return { ok: false, error: { code: 'too_many_pages', message: 'Too many pages' } };
    },
  };
}
