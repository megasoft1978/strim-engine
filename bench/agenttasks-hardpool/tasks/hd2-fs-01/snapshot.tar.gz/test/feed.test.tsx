import { describe, expect, test } from 'bun:test';
import { renderToStaticMarkup } from 'react-dom/server';
import { createClient, type Transport } from '../src/client/api.ts';
import { OrderFeed } from '../src/client/OrderList.tsx';
import { handle } from '../src/server/handler.ts';
import type { OrderRecord } from '../src/server/orders.ts';
import type { HttpRequest } from '../src/shared/types.ts';

const RECORDS: OrderRecord[] = [
  { id: 'o1', cents: 1250, placedAtSec: 1709632800, note: null, status: 'paid' },
  { id: 'o2', cents: 123400, placedAtSec: 1709767800, note: 'Gift wrap', status: 'open' },
  { id: 'o3', cents: 5, placedAtSec: 1709856900, note: null, status: 'refunded' },
  { id: 'o4', cents: 99900, placedAtSec: 1709985600, note: 'Leave at door', status: 'paid' },
  { id: 'o5', cents: 2000, placedAtSec: 1710060300, note: null, status: 'open' },
];

function setup(records = RECORDS) {
  const calls: HttpRequest[] = [];
  const transport: Transport = async (req) => {
    calls.push(req);
    return handle(req, records);
  };
  return { client: createClient(transport), calls };
}

async function feed(limit = 5, records = RECORDS) {
  const { client } = setup(records);
  return renderToStaticMarkup(<OrderFeed result={await client.listAll(limit)} />);
}

describe('server wire format', () => {
  test('order JSON matches the contract', () => {
    const res = handle({ method: 'GET', path: '/orders/o2', query: {} }, RECORDS);
    expect(res.status).toBe(200);
    expect(res.body).toEqual({
      id: 'o2',
      totalCents: 123400,
      placedAt: '2024-03-06T23:30:00.000Z',
      note: 'Gift wrap',
      status: 'open',
    });
  });

  test('pages chain without overlap', () => {
    const first = handle({ method: 'GET', path: '/orders', query: { limit: '2' } }, RECORDS).body as any;
    expect(first.items.map((o: any) => o.id)).toEqual(['o1', 'o2']);
    const second = handle({ method: 'GET', path: '/orders', query: { limit: '2', cursor: first.nextCursor } }, RECORDS).body as any;
    expect(second.items.map((o: any) => o.id)).toEqual(['o3', 'o4']);
  });
});

describe('client over the handler', () => {
  test('listAll walks every page exactly once', async () => {
    const { client, calls } = setup();
    const r = await client.listAll(2);
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.value.map((o) => o.id)).toEqual(['o1', 'o2', 'o3', 'o4', 'o5']);
    expect(calls.length).toBe(3);
  });

  test('a page that fits in one request has no next cursor', async () => {
    const { client, calls } = setup();
    const r = await client.listOrders(undefined, 5);
    expect(r.ok && r.value.nextCursor).toBe(null);
    expect(calls.length).toBe(1);
  });

  test('server errors reach the client with code and message', async () => {
    const { client } = setup();
    const bad = await client.listOrders('zzz', 2);
    expect(bad).toEqual({ ok: false, error: { code: 'bad_cursor', message: 'Invalid cursor: zzz' } });
    const missing = await client.getOrder('o99');
    expect(missing.ok ? '' : missing.error.code).toBe('not_found');
    const limit = await client.listOrders(undefined, 0);
    expect(limit.ok ? '' : limit.error.code).toBe('bad_limit');
  });

  test('limit is capped at five', async () => {
    const many: OrderRecord[] = Array.from({ length: 8 }, (_, i) => ({
      id: `m${i}`, cents: 100, placedAtSec: 1709632800, note: null, status: 'open' as const,
    }));
    const { client } = setup(many);
    const r = await client.listOrders(undefined, 50);
    expect(r.ok && r.value.items.length).toBe(5);
  });
});

describe('rendered feed', () => {
  test('amounts are shown in dollars', async () => {
    const html = await feed();
    expect(html).toContain('<span class="total">$12.50</span>');
    expect(html).toContain('<span class="total">$1,234.00</span>');
    expect(html).toContain('<span class="total">$0.05</span>');
    expect(html).toContain('<span class="total">$999.00</span>');
  });

  test('placed dates are the UTC calendar day', async () => {
    const html = await feed();
    expect(html).toContain('>2024-03-05</time>');
    expect(html).toContain('>2024-03-06</time>');
    expect(html).toContain('>2024-03-08</time>');
    expect(html).toContain('>2024-03-10</time>');
  });

  test('notes render only when present', async () => {
    const html = await feed();
    expect(html.match(/class="note"/g)?.length).toBe(2);
    expect(html).toContain('<p class="note">Gift wrap</p>');
    expect(html).toContain('<li data-id="o1" class="order paid"><span class="id">o1</span><span class="total">$12.50</span><time dateTime="2024-03-05T10:00:00.000Z">2024-03-05</time></li>');
  });

  test('every order appears once with small pages', async () => {
    const html = await feed(2);
    expect(html.match(/<li /g)?.length).toBe(5);
  });

  test('errors are shown in an alert', async () => {
    const { client } = setup();
    const html = renderToStaticMarkup(<OrderFeed result={await client.listOrders('abc')} />);
    expect(html).toBe('<div role="alert" class="error">Invalid cursor: abc</div>');
  });

  test('empty feed', async () => {
    expect(await feed(3, [])).toBe('<p class="empty">No orders yet</p>');
  });
});
