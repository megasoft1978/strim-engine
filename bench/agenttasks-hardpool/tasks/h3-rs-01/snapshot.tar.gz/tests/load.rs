use std::collections::BTreeMap;
use layered_config::{ConfigError, Loader, Sources, render_keys, render_redacted};

fn env(pairs: &[(&str, &str)]) -> BTreeMap<String, String> {
    pairs.iter().map(|(k, v)| (k.to_string(), v.to_string())).collect()
}

#[test]
fn deployment_settings() {
    let mut s = Sources::new();
    s.insert("defaults", "[web]\nport=80\nhost=localhost\n");
    s.insert("region", "[web]\nport=8080\nzone=west\n");
    s.insert("prod", "[web]\nport=443\n@include defaults\n@include region\nhost=example.org\n");
    let c = Loader::new(&s).load("prod").unwrap();
    assert_eq!(c.get("web.port"), Some("443"));
    assert_eq!(c.get("web.host"), Some("example.org"));
    assert_eq!(c.get("web.zone"), Some("west"));
}

#[test]
fn quoted_characters_in_values() {
    let mut s = Sources::new();
    s.insert("main", r"endpoint = host\#fragment\=tail # ignored");
    let c = Loader::new(&s).load("main").unwrap();
    assert_eq!(c.get("endpoint"), Some("host#fragment=tail"));
}

#[test]
fn literal_templates_and_environment_values() {
    let mut s = Sources::new();
    s.insert("main", r"message = \${USER} / ${VALUE}");
    let environment = env(&[("USER", "alice"), ("VALUE", "${USER}")]);
    let c = Loader::new(&s).with_environment(environment).load("main").unwrap();
    assert_eq!(c.get("message"), Some("${USER} / ${USER}"));
}

#[test]
fn later_includes_and_repeated_includes() {
    let mut s = Sources::new();
    s.insert("base", "key=base\n");
    s.insert("a", "@include base\nkey=a\n");
    s.insert("b", "@include base\nkey=b\n");
    s.insert("root", "@include a\n@include b\n");
    assert_eq!(Loader::new(&s).load("root").unwrap().get("key"), Some("b"));
}

#[test]
fn errors_are_specific() {
    let mut s = Sources::new();
    s.insert("a", "@include b\n");
    s.insert("b", "@include a\n");
    assert_eq!(Loader::new(&s).load("a"), Err(ConfigError::IncludeCycle("a".into())));
    assert_eq!(Loader::new(&s).load("absent"), Err(ConfigError::MissingSource("absent".into())));
    s.insert("bad", "[x]\nmissing equals\n");
    assert!(matches!(Loader::new(&s).load("bad"), Err(ConfigError::Syntax { line: 2, .. })));
    s.insert("var", "x=${MISSING}");
    assert_eq!(Loader::new(&s).load("var"), Err(ConfigError::MissingVariable("MISSING".into())));
    s.insert("var", "x=${OPEN");
    assert_eq!(Loader::new(&s).load("var"), Err(ConfigError::UnterminatedVariable));
}

#[test]
fn reporting_is_sorted_and_redacted() {
    let mut s = Sources::new();
    s.insert("main", "z=last\n[db]\npassword=secret\nuser=app\n");
    let c = Loader::new(&s).load("main").unwrap();
    assert_eq!(render_keys(&c), "db.password\ndb.user\nz\n");
    assert_eq!(render_redacted(&c, &["PASSWORD"]), "db.password = [redacted]\ndb.user = app\nz = last\n");
}

#[test]
fn only_winning_values_are_interpolated() {
    let mut s = Sources::new();
    s.insert("defaults", "token=${UNSET}\n");
    s.insert("root", "@include defaults\ntoken=local\n");
    assert_eq!(Loader::new(&s).load("root").unwrap().get("token"), Some("local"));
}

#[test]
fn escaped_backslash_before_comment() {
    let mut s = Sources::new();
    s.insert("main", r"path = C:\\ # note");
    assert_eq!(Loader::new(&s).load("main").unwrap().get("path"), Some("C:\\"));
}
