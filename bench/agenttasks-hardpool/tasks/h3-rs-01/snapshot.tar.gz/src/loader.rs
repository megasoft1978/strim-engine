use std::collections::BTreeMap;
use crate::{error::ConfigError, merge, resolver, source::Sources, value::Config};

/// Loads one named root using a caller-owned environment snapshot.
pub struct Loader<'a> {
    sources: &'a Sources,
    environment: BTreeMap<String, String>,
}

impl<'a> Loader<'a> {
    pub fn new(sources: &'a Sources) -> Self {
        Self { sources, environment: BTreeMap::new() }
    }

    pub fn with_environment(mut self, environment: BTreeMap<String, String>) -> Self {
        self.environment = environment;
        self
    }

    pub fn load(&self, root: &str) -> Result<Config, ConfigError> {
        let raw = merge::collect(self.sources, root)?;
        let mut resolved = BTreeMap::new();
        for (key, value) in raw {
            resolved.insert(key, resolver::expand(&value, &self.environment)?);
        }
        Ok(Config::from_map(resolved))
    }
}
