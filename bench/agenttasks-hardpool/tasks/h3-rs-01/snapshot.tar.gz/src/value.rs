use std::collections::BTreeMap;

/// Final values are ordered for reproducible output.
#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct Config {
    values: BTreeMap<String, String>,
}

impl Config {
    pub(crate) fn from_map(values: BTreeMap<String, String>) -> Self {
        Self { values }
    }

    pub fn get(&self, key: &str) -> Option<&str> {
        self.values.get(key).map(String::as_str)
    }

    pub fn iter(&self) -> impl Iterator<Item = (&str, &str)> {
        self.values.iter().map(|(k, v)| (k.as_str(), v.as_str()))
    }

    /// Iterate through values in one section, omitting its prefix.
    /// The name must match the complete component before the dot.
    pub fn section<'a>(&'a self, name: &str) -> Vec<(&'a str, &'a str)> {
        let prefix = format!("{name}.");
        self.values.iter().filter_map(|(key, value)| {
            key.strip_prefix(&prefix).map(|suffix| (suffix, value.as_str()))
        }).collect()
    }

    pub fn len(&self) -> usize {
        self.values.len()
    }

    pub fn is_empty(&self) -> bool {
        self.values.is_empty()
    }
}
