use std::fmt;

/// Errors carry source and line information whenever parsing can provide it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ConfigError {
    MissingSource(String),
    IncludeCycle(String),
    Syntax { source: String, line: usize, message: String },
    MissingVariable(String),
    UnterminatedVariable,
}

impl fmt::Display for ConfigError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::MissingSource(name) => write!(f, "source not found: {name}"),
            Self::IncludeCycle(name) => write!(f, "include cycle: {name}"),
            Self::Syntax { source, line, message } => {
                write!(f, "{source}:{line}: {message}")
            }
            Self::MissingVariable(name) => write!(f, "variable not found: {name}"),
            Self::UnterminatedVariable => write!(f, "unterminated variable"),
        }
    }
}

impl std::error::Error for ConfigError {}
