//! A small, deterministic layered configuration loader.
mod document;
mod error;
mod lexer;
mod loader;
mod merge;
mod report;
mod resolver;
mod source;
mod value;

pub use error::ConfigError;
pub use loader::Loader;
pub use report::{render_keys, render_redacted};
pub use source::Sources;
pub use value::Config;
