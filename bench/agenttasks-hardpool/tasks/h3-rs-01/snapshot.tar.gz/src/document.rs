use crate::{error::ConfigError, lexer};

#[derive(Debug)]
pub(crate) struct Document {
    pub includes: Vec<String>,
    pub assignments: Vec<(String, String)>,
}

pub(crate) fn parse(source: &str, text: &str) -> Result<Document, ConfigError> {
    let mut doc = Document { includes: Vec::new(), assignments: Vec::new() };
    let mut section = String::new();
    for (offset, line) in text.lines().enumerate() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let syntax = |message: &str| ConfigError::Syntax {
            source: source.to_owned(),
            line: offset + 1,
            message: message.to_owned(),
        };
        if let Some(name) = line.strip_prefix("@include ") {
            let name = name.trim();
            if name.is_empty() {
                return Err(syntax("empty include"));
            }
            doc.includes.push(name.to_owned());
        } else if line.starts_with('[') {
            if !line.ends_with(']') || line.len() < 3 {
                return Err(syntax("invalid section"));
            }
            section = line[1..line.len()-1].trim().to_owned();
            if section.is_empty() {
                return Err(syntax("empty section"));
            }
        } else {
            let (key, value) = lexer::assignment(line)
                .ok_or_else(|| syntax("expected assignment"))?;
            let full_key = if section.is_empty() {
                key
            } else {
                format!("{section}.{key}")
            };
            doc.assignments.push((full_key, value));
        }
    }
    Ok(doc)
}
