use std::collections::BTreeMap;
use crate::error::ConfigError;

/// Expand each value against an explicit environment; never read process state.
pub(crate) fn expand(raw: &str, env: &BTreeMap<String, String>) -> Result<String, ConfigError> {
    let mut out = String::new();
    let mut chars = raw.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch == '\\' {
            if let Some(next) = chars.next() {
                out.push(next);
            } else {
                out.push(ch);
            }
        } else if ch == '$' && chars.peek() == Some(&'{') {
            chars.next();
            let mut name = String::new();
            let mut closed = false;
            for part in chars.by_ref() {
                if part == '}' {
                    closed = true;
                    break;
                }
                name.push(part);
            }
            if !closed {
                return Err(ConfigError::UnterminatedVariable);
            }
            let value = env.get(&name).ok_or_else(|| ConfigError::MissingVariable(name.clone()))?;
            out.push_str(value);
        } else {
            out.push(ch);
        }
    }
    // A second pass catches substitutions introduced by escaped dollar signs.
    if out.contains("${") && out != raw {
        return expand(&out, env);
    }
    Ok(out)
}
