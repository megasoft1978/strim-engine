/// Split an assignment and strip comments. Escapes remain in the value until
/// interpolation so the resolver can distinguish literal dollars.
pub(crate) fn assignment(line: &str) -> Option<(String, String)> {
    let mut separator = None;
    let mut end = line.len();
    for (index, ch) in line.char_indices() {
        if ch == '#' {
            end = index;
            break;
        }
        if ch == '=' && separator.is_none() {
            separator = Some(index);
        }
    }
    let index = separator?;
    if index >= end {
        return None;
    }
    let key = line[..index].trim();
    if key.is_empty() {
        return None;
    }
    Some((key.to_owned(), line[index + 1..end].trim().to_owned()))
}
