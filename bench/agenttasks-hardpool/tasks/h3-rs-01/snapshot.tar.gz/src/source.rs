use std::collections::BTreeMap;

/// Named source texts. The caller controls the namespace and storage.
#[derive(Debug, Default, Clone)]
pub struct Sources {
    texts: BTreeMap<String, String>,
}

impl Sources {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, name: impl Into<String>, text: impl Into<String>) {
        self.texts.insert(name.into(), text.into());
    }

    pub fn get(&self, name: &str) -> Option<&str> {
        self.texts.get(name).map(String::as_str)
    }

    pub fn names(&self) -> impl Iterator<Item = &str> {
        self.texts.keys().map(String::as_str)
    }

    pub fn len(&self) -> usize {
        self.texts.len()
    }

    pub fn is_empty(&self) -> bool {
        self.texts.is_empty()
    }
}
