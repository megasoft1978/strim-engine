use std::collections::BTreeMap;
use crate::{document, error::ConfigError, source::Sources};

/// Collect raw values in precedence order, detecting only active-stack cycles.
pub(crate) fn collect(sources: &Sources, root: &str) -> Result<BTreeMap<String, String>, ConfigError> {
    let mut values = BTreeMap::new();
    visit(sources, root, &mut Vec::new(), &mut values)?;
    Ok(values)
}

fn visit(
    sources: &Sources,
    name: &str,
    stack: &mut Vec<String>,
    values: &mut BTreeMap<String, String>,
) -> Result<(), ConfigError> {
    if stack.iter().any(|entry| entry == name) {
        return Err(ConfigError::IncludeCycle(name.to_owned()));
    }
    let text = sources.get(name).ok_or_else(|| ConfigError::MissingSource(name.to_owned()))?;
    let doc = document::parse(name, text)?;
    stack.push(name.to_owned());
    for (key, value) in doc.assignments {
        values.insert(key, value);
    }
    for child in doc.includes {
        visit(sources, &child, stack, values)?;
    }
    stack.pop();
    Ok(())
}
