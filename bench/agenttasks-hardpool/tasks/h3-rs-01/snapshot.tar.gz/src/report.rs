use crate::value::Config;

/// Return one key per line in stable order, useful for inventory checks.
pub fn render_keys(config: &Config) -> String {
    config.iter().map(|(key, _)| format!("{key}\n")).collect()
}

/// Render values while hiding keys that contain a case-insensitive marker.
/// This is a display aid, not an access-control boundary.
pub fn render_redacted(config: &Config, markers: &[&str]) -> String {
    let mut output = String::new();
    for (key, value) in config.iter() {
        let lower = key.to_lowercase();
        let secret = markers.iter().any(|marker| lower.contains(&marker.to_lowercase()));
        let shown = if secret { "[redacted]" } else { value };
        output.push_str(key);
        output.push_str(" = ");
        output.push_str(shown);
        output.push('\n');
    }
    output
}
