# Layered config

A dependency-free configuration loader for applications that need repeatable
settings across deployments. Sources are supplied by a caller rather than read
from disk; this makes a complete configuration easy to test and audit.

Documents contain `key = value` assignments, `[section]` headers, and
`@include name` directives. Empty lines and lines beginning with `#` are
ignored. A backslash quotes the following character in a value. In particular,
`\#` is a literal hash, `\=` is a literal equals sign, and `\$` prevents
interpolation. An unescaped `#` begins a comment. The first unescaped equals
sign separates the key and value. Spaces around the assignment are trimmed.

Includes are merged in their listed order, then all assignments in the including
document are applied, regardless of where the directives appear. Thus local
settings win over included settings, and later includes win over earlier ones.
Includes have their own section state and are identified by exact source names.
A repeated include is allowed; a cycle on the active include stack is an error.

Values may use `${NAME}` to substitute from a caller-supplied environment map.
Missing variables and unterminated expressions are errors. Escaped dollars are
literal, even when followed by braces. Substituted text is not parsed again.
The loader returns a sorted map keyed by `section.key` (or just `key` outside
sections). Its report can be used to display configuration without secrets.
