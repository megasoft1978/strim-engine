import test from 'node:test';
import assert from 'node:assert/strict';
import { compare, satisfies } from '../src/semver.ts';

test('compare is numeric per component', () => {
  assert.equal(compare('1.2.3', '1.2.3'), 0);
  assert.ok(compare('1.10.0', '1.9.0') > 0);
  assert.ok(compare('2.0.0', '10.0.0') < 0);
  assert.ok(compare('0.0.9', '0.0.10') < 0);
});

test('satisfies: exact, comparators, x-ranges', () => {
  const table: Array<[string, string, boolean]> = [
    ['1.2.3', '1.2.3', true],
    ['1.2.4', '1.2.3', false],
    ['1.5.0', '>=1.2.0', true],
    ['1.2.0', '>1.2.0', false],
    ['1.2.1', '>1.2.0', true],
    ['2.0.0', '<2.0.0', false],
    ['2.0.0', '<=2.0.0', true],
    ['1.4.0', '>=1.2.0 <1.5.0', true],
    ['1.5.0', '>=1.2.0 <1.5.0', false],
    ['3.1.0', '^1.0.0 || >=3.0.0', true],
    ['2.1.0', '^1.0.0 || >=3.0.0', false],
    ['1.9.9', '1.x', true],
    ['2.0.0', '1.x', false],
    ['1.2.9', '1.2.x', true],
    ['1.3.0', '1.2.x', false],
    ['9.9.9', '*', true],
    ['0.0.1', 'x', true],
  ];
  for (const [v, r, want] of table) assert.equal(satisfies(v, r), want, `${v} vs ${r}`);
});

test('satisfies: caret and tilde with full versions', () => {
  const table: Array<[string, string, boolean]> = [
    ['1.2.3', '^1.2.3', true],
    ['1.9.0', '^1.2.3', true],
    ['2.0.0', '^1.2.3', false],
    ['1.2.2', '^1.2.3', false],
    ['0.2.9', '^0.2.3', true],
    ['0.3.0', '^0.2.3', false],
    ['0.0.3', '^0.0.3', true],
    ['0.0.4', '^0.0.3', false],
    ['1.2.9', '~1.2.3', true],
    ['1.3.0', '~1.2.3', false],
    ['1.9.0', '~1', true],
    ['2.0.0', '~1', false],
  ];
  for (const [v, r, want] of table) assert.equal(satisfies(v, r), want, `${v} vs ${r}`);
});

test('invalid input throws', () => {
  assert.throws(() => satisfies('1.2', '^1.0.0'));
  assert.throws(() => satisfies('1.2.3', '^1.q'));
});
