import test from 'node:test';
import assert from 'node:assert/strict';
import { plan } from '../src/plan.ts';
import { formatDuration, render } from '../src/format.ts';
import { registry } from './helpers.ts';

const reg = () =>
  registry([
    ['web@1.2.0', { util: '^1.0.0' }, 5],
    ['web@1.9.0', { util: '^1.0.0' }, 6],
    ['web@1.10.0', { util: '^1.0.0', ui: '~2.1.0' }, 20],
    ['web@2.0.0', {}, 1],
    ['util@1.0.0', {}, 5],
    ['util@1.3.0', {}, 8],
    ['util@2.0.0', {}, 15],
    ['ui@2.1.0', {}, 9],
    ['ui@2.1.4', { util: '^2.0.0' }, 12],
    ['ui@2.2.0', {}, 1],
    ['lib@0.4.1', {}, 25],
    ['lib@0.4.9', {}, 30],
    ['lib@0.5.0', {}, 99],
  ]);

test('plans builds for a small dependency tree', () => {
  const p = plan({ deps: { web: '^1.0.0', lib: '^0.4' } }, reg());
  assert.deepEqual(p.order, ['lib@0.4.9', 'util@2.0.0', 'ui@2.1.4', 'util@1.3.0', 'web@1.10.0']);
  assert.deepEqual(p.waves, [['lib@0.4.9', 'util@1.3.0', 'util@2.0.0'], ['ui@2.1.4'], ['web@1.10.0']]);
  assert.deepEqual(p.cycles, []);
  assert.equal(p.estimateMs, 6200);
});

test('render shows waves, cycles and the estimate', () => {
  const p = plan({ deps: { web: '^1.0.0', lib: '^0.4' } }, reg());
  assert.equal(
    render(p),
    ['wave 1: lib@0.4.9, util@1.3.0, util@2.0.0', 'wave 2: ui@2.1.4', 'wave 3: web@1.10.0', 'estimate: 6s'].join('\n'),
  );
});

test('cycles are reported and every package is still planned', () => {
  const r = registry([
    ['aa@1.0.0', { x: '^1' }, 10],
    ['x@1.2.0', { y: '^1' }, 10],
    ['y@1.0.0', { x: '^1' }, 10],
  ]);
  const p = plan({ deps: { aa: '*' } }, r);
  assert.deepEqual(p.cycles, [['x@1.2.0', 'y@1.0.0', 'x@1.2.0']]);
  assert.deepEqual(p.order, ['y@1.0.0', 'x@1.2.0', 'aa@1.0.0']);
  assert.deepEqual(p.waves, [['y@1.0.0'], ['x@1.2.0'], ['aa@1.0.0']]);
  assert.equal(p.estimateMs, 3000);
  assert.match(render(p), /^cycle: x@1\.2\.0 -> y@1\.0\.0 -> x@1\.2\.0$/m);
});

test('an empty dependency list gives an empty plan', () => {
  assert.deepEqual(plan({ deps: {} }, reg()), { order: [], waves: [], cycles: [], estimateMs: 0 });
});

test('formatDuration', () => {
  const table: Array<[number, string]> = [[0, '0s'], [4900, '5s'], [59500, '1m00s'], [65000, '1m05s'], [7207000, '2h00m07s']];
  for (const [ms, want] of table) assert.equal(formatDuration(ms), want);
});
