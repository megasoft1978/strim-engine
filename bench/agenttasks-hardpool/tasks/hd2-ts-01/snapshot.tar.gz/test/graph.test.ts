import test from 'node:test';
import assert from 'node:assert/strict';
import { topoOrder } from '../src/graph.ts';
import { graph } from './helpers.ts';

test('dependencies come first, ties broken by key', () => {
  const g = graph({ 'web@1.0.0': ['db@1.0.0', 'log@1.0.0'], 'log@1.0.0': [], 'db@1.0.0': ['log@1.0.0'], 'cli@1.0.0': ['log@1.0.0'] });
  assert.deepEqual(topoOrder(g), {
    order: ['log@1.0.0', 'cli@1.0.0', 'db@1.0.0', 'web@1.0.0'],
    cycles: [],
  });
});

test('insertion order of the map does not matter', () => {
  const a = topoOrder(graph({ 'b@1.0.0': ['c@1.0.0'], 'a@1.0.0': ['c@1.0.0'], 'c@1.0.0': [] }));
  const b = topoOrder(graph({ 'c@1.0.0': [], 'a@1.0.0': ['c@1.0.0'], 'b@1.0.0': ['c@1.0.0'] }));
  assert.deepEqual(a, b);
  assert.deepEqual(a.order, ['c@1.0.0', 'a@1.0.0', 'b@1.0.0']);
});

test('a cycle is reported as a closed path without the path that led to it', () => {
  const g = graph({ 'app@1.0.0': ['x@1.0.0'], 'x@1.0.0': ['y@1.0.0'], 'y@1.0.0': ['z@1.0.0'], 'z@1.0.0': ['x@1.0.0'] });
  const { order, cycles } = topoOrder(g);
  assert.deepEqual(cycles, [['x@1.0.0', 'y@1.0.0', 'z@1.0.0', 'x@1.0.0']]);
  assert.equal(order.length, 4);
  assert.equal(order.at(-1), 'app@1.0.0');
});

test('a cycle starts at its smallest key even when entered elsewhere', () => {
  const g = graph({ 'a@1.0.0': ['r@1.0.0'], 'r@1.0.0': ['q@1.0.0'], 'q@1.0.0': ['r@1.0.0'] });
  assert.deepEqual(topoOrder(g).cycles, [['q@1.0.0', 'r@1.0.0', 'q@1.0.0']]);
});

test('self loops, several cycles and unknown edges', () => {
  const g = graph({ 'a@1.0.0': ['a@1.0.0', 'ghost@1.0.0'], 'm@1.0.0': ['n@1.0.0'], 'n@1.0.0': ['m@1.0.0'] });
  const { order, cycles } = topoOrder(g);
  assert.deepEqual(cycles, [['a@1.0.0', 'a@1.0.0'], ['m@1.0.0', 'n@1.0.0', 'm@1.0.0']]);
  assert.deepEqual(order, ['a@1.0.0', 'n@1.0.0', 'm@1.0.0']);
});
