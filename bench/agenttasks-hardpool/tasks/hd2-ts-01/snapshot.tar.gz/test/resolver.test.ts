import test from 'node:test';
import assert from 'node:assert/strict';
import { resolve, ResolveError } from '../src/resolver.ts';
import { registry } from './helpers.ts';

test('picks the highest satisfying version', () => {
  const r = registry([['lib@1.2.0', {}], ['lib@1.9.0', {}], ['lib@1.10.0', {}], ['lib@2.0.0', {}]]);
  const res = resolve({ lib: '^1.0.0' }, r);
  assert.deepEqual(res.roots, ['lib@1.10.0']);
  assert.deepEqual([...res.nodes.keys()], ['lib@1.10.0']);
});

test('the same package can resolve to several versions for different ranges', () => {
  const r = registry([
    ['a@1.0.0', { util: '^1.0.0' }],
    ['b@1.0.0', { util: '^2.0.0' }],
    ['util@1.4.0', {}],
    ['util@2.3.0', {}],
  ]);
  const res = resolve({ a: '^1', b: '^1' }, r);
  assert.deepEqual([...res.nodes.keys()].sort(), ['a@1.0.0', 'b@1.0.0', 'util@1.4.0', 'util@2.3.0']);
  assert.deepEqual(res.nodes.get('a@1.0.0')!.deps, ['util@1.4.0']);
  assert.deepEqual(res.nodes.get('b@1.0.0')!.deps, ['util@2.3.0']);
});

test('equal ranges are shared and deps are deduplicated and sorted', () => {
  const r = registry([
    ['a@1.0.0', { z: '*', y: '*', y2: '*' }],
    ['z@1.0.0', {}],
    ['y@1.0.0', {}],
    ['y2@1.0.0', {}],
  ]);
  const res = resolve({ a: '*', y: '>=1.0.0' }, r);
  assert.deepEqual(res.nodes.get('a@1.0.0')!.deps, ['y2@1.0.0', 'y@1.0.0', 'z@1.0.0']);
  assert.equal(res.nodes.size, 4);
  assert.deepEqual(res.roots, ['a@1.0.0', 'y@1.0.0']);
});

test('an unsatisfiable or unknown dependency throws ResolveError', () => {
  const r = registry([['lib@1.0.0', {}]]);
  assert.throws(() => resolve({ lib: '^2.0.0' }, r), ResolveError);
  assert.throws(() => resolve({ missing: '*' }, r), /missing/);
});

test('cycles terminate', () => {
  const r = registry([['a@1.0.0', { b: '*' }], ['b@1.0.0', { a: '*' }]]);
  const res = resolve({ a: '*' }, r);
  assert.deepEqual(res.nodes.get('b@1.0.0')!.deps, ['a@1.0.0']);
});
