import { Registry } from '../src/registry.ts';
import type { Node } from '../src/types.ts';

export function registry(spec: Array<[string, Record<string, string>, number?]>): Registry {
  const r = new Registry();
  for (const [id, deps, build] of spec) {
    const at = id.lastIndexOf('@');
    r.add({ name: id.slice(0, at), version: id.slice(at + 1), deps, build: build ?? 1 });
  }
  return r;
}

export function graph(spec: Record<string, string[]>): Map<string, Node> {
  const m = new Map<string, Node>();
  for (const [key, deps] of Object.entries(spec)) {
    const at = key.lastIndexOf('@');
    m.set(key, { name: key.slice(0, at), version: key.slice(at + 1), key, deps: [...deps].sort(), build: 1 });
  }
  return m;
}
