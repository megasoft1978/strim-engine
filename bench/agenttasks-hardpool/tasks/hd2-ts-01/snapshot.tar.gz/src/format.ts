import type { Plan } from './types.ts';

/** `0s`, `5s`, `1m05s`, `2h00m07s`; rounds to the nearest second. */
export function formatDuration(ms: number): string {
  const total = Math.round(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const two = (n: number) => String(n).padStart(2, '0');
  if (h > 0) return `${h}h${two(m)}m${two(s)}s`;
  if (m > 0) return `${m}m${two(s)}s`;
  return `${s}s`;
}

/** Human readable plan: one line per wave, one per cycle, then the estimate. */
export function render(p: Plan): string {
  const lines = p.waves.map((wave, i) => `wave ${i + 1}: ${wave.join(', ')}`);
  for (const c of p.cycles) lines.push(`cycle: ${c.join(' -> ')}`);
  lines.push(`estimate: ${formatDuration(p.estimateMs)}`);
  return lines.join('\n');
}
