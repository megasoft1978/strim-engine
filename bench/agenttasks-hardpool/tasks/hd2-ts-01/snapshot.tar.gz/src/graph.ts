import type { Node } from './types.ts';

export interface Ordering {
  order: string[];
  cycles: string[][];
}

/** Rotates a closed path (first === last) so that it starts at its smallest key. */
function canonical(path: string[]): string[] {
  const ring = path.slice(0, -1);
  const at = ring.indexOf([...ring].sort()[0]);
  const rotated = [...ring.slice(at), ...ring.slice(0, at)];
  return [...rotated, rotated[0]];
}

/**
 * Depth-first topological order: every key appears after its dependencies. Keys and dependencies are visited in
 * sorted order so the result is deterministic. A back edge closes a cycle; cycles are reported once each as a
 * closed path starting at the smallest key of the cycle, and are returned sorted. Edges into unknown keys are ignored.
 */
export function topoOrder(nodes: Map<string, Node>): Ordering {
  const order: string[] = [];
  const cycles = new Map<string, string[]>();
  const state = new Map<string, 'open' | 'done'>();
  const path: string[] = [];

  const walk = (key: string): void => {
    state.set(key, 'open');
    path.push(key);
    for (const dep of nodes.get(key)!.deps) {
      if (!nodes.has(dep)) continue;
      const s = state.get(dep);
      if (s === 'open') {
        const loop = canonical([...path, dep]);
        cycles.set(loop.join('>'), loop);
      } else if (s === undefined) walk(dep);
    }
    path.pop();
    state.set(key, 'done');
    order.push(key);
  };

  for (const key of [...nodes.keys()].sort()) if (!state.has(key)) walk(key);
  return { order, cycles: [...cycles.entries()].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)).map(([, c]) => c) };
}
