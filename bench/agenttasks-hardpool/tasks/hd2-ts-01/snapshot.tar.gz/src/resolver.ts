import { satisfies } from './semver.ts';
import type { Registry } from './registry.ts';
import type { Node, Resolution } from './types.ts';

export class ResolveError extends Error {}

/**
 * Resolves `root` (name -> range) against the registry. Every distinct (name, range) pair gets the highest
 * satisfying version; different ranges of one package may resolve to different versions, and all of them end
 * up in the result. Dependency cycles are allowed.
 */
export function resolve(root: Record<string, string>, registry: Registry): Resolution {
  const cache = new Map<string, string>();
  const nodes = new Map<string, Node>();

  const pick = (name: string, range: string): string => {
    const id = name;
    let version = cache.get(id);
    if (version === undefined) {
      version = registry.versions(name).filter((v) => satisfies(v, range)).pop();
      if (version === undefined) throw new ResolveError(`no version of ${name} satisfies ${range}`);
      cache.set(id, version);
    }
    return version;
  };

  const visit = (name: string, range: string): string => {
    const version = pick(name, range);
    const key = `${name}@${version}`;
    if (nodes.has(key)) return key;
    const m = registry.get(name, version);
    const node: Node = { name, version, key, deps: [], build: m.build };
    nodes.set(key, node); // registered before recursing so cycles terminate
    const deps = new Set<string>();
    for (const dep of Object.keys(m.deps).sort()) deps.add(visit(dep, m.deps[dep]));
    node.deps = [...deps].sort();
    return key;
  };

  const roots = new Set<string>();
  for (const name of Object.keys(root).sort()) roots.add(visit(name, root[name]));
  return { roots: [...roots].sort(), nodes };
}
