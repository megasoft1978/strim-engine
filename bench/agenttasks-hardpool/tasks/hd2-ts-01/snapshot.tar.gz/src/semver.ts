import type { Version } from './types.ts';

export function parse(v: string): Version {
  const m = /^(\d+)\.(\d+)\.(\d+)$/.exec(v);
  if (!m) throw new Error(`invalid version: ${v}`);
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]) };
}

function cmp(a: Version, b: Version): number {
  return a.major - b.major || a.minor - b.minor || a.patch - b.patch;
}

/** Orders two version strings numerically per component. */
export function compare(a: string, b: string): number {
  return cmp(parse(a), parse(b));
}

type Op = '>=' | '>' | '<=' | '<' | '=';
interface Comparator {
  op: Op;
  v: Version;
}

const v3 = (major: number, minor: number, patch: number): Version => ({ major, minor, patch });
const ge = (v: Version): Comparator => ({ op: '>=', v });
const lt = (v: Version): Comparator => ({ op: '<', v });

/** Parses `1`, `1.2` or `1.2.3`; missing or `x` parts count as 0. Returns the version and how many parts were given. */
function partial(s: string): { v: Version; parts: number } {
  const bits = s.split('.');
  const nums = bits.map((b) => (b === 'x' || b === '*' ? -1 : Number(b)));
  if (bits.length > 3 || nums.some((n) => Number.isNaN(n))) throw new Error(`invalid range: ${s}`);
  const given = nums.findIndex((n) => n < 0);
  const parts = given === -1 ? nums.length : given;
  const [a = 0, b = 0, c = 0] = nums.map((n, i) => (i < parts ? n : 0));
  return { v: v3(a, b, c), parts };
}

function bump(v: Version, level: 'major' | 'minor' | 'patch'): Version {
  if (level === 'major') return v3(v.major + 1, 0, 0);
  if (level === 'minor') return v3(v.major, v.minor + 1, 0);
  return v3(v.major, v.minor, v.patch + 1);
}

function expand(token: string): Comparator[] {
  const m = /^(\^|~|>=|<=|>|<|=)?(.*)$/.exec(token)!;
  const { v, parts } = partial(m[2]);
  switch (m[1]) {
    case '^': {
      const level = v.major > 0 || parts < 3 ? 'major' : v.minor > 0 ? 'minor' : 'patch';
      return [ge(v), lt(bump(v, level))];
    }
    case '~':
      return [ge(v), lt(bump(v, parts <= 1 ? 'major' : 'minor'))];
    case '>=':
      return [ge(v)];
    case '>':
      return parts === 3 ? [{ op: '>', v }] : [ge(bump(v, parts === 2 ? 'minor' : 'major'))];
    case '<=':
      return [parts === 3 ? { op: '<=', v } : lt(bump(v, parts === 2 ? 'minor' : 'major'))];
    case '<':
      return [lt(v)];
    default:
      if (parts === 3) return [{ op: '=', v }];
      return parts === 0 ? [] : [ge(v), lt(bump(v, parts === 2 ? 'minor' : 'major'))];
  }
}

/**
 * Supported range syntax: `*`/`x`, exact `1.2.3`, x-ranges `1.x` / `1.2.x`, `^`, `~`, `>=`, `>`, `<=`, `<`,
 * comparators joined by spaces (AND) and sets joined by `||` (OR).
 */
function compile(range: string): Comparator[][] {
  return range.split('||').map((set) => set.trim().split(/\s+/).filter(Boolean).flatMap(expand));
}

function test(c: Comparator, v: Version): boolean {
  const d = cmp(v, c.v);
  switch (c.op) {
    case '>=': return d >= 0;
    case '>': return d > 0;
    case '<=': return d <= 0;
    case '<': return d < 0;
    default: return d === 0;
  }
}

export function satisfies(version: string, range: string): boolean {
  const v = parse(version);
  return compile(range).some((set) => set.every((c) => test(c, v)));
}
