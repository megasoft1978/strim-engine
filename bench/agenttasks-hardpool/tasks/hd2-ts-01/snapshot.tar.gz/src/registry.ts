import type { Manifest } from './types.ts';

/** In-memory package index. */
export class Registry {
  private pkgs = new Map<string, Map<string, Manifest>>();

  add(m: Manifest): this {
    let versions = this.pkgs.get(m.name);
    if (!versions) this.pkgs.set(m.name, (versions = new Map()));
    versions.set(m.version, m);
    return this;
  }

  /** All versions of `name`, lowest first (numeric semver order). Empty when the package is unknown. */
  versions(name: string): string[] {
    return [...(this.pkgs.get(name)?.keys() ?? [])].sort();
  }

  get(name: string, version: string): Manifest {
    const m = this.pkgs.get(name)?.get(version);
    if (!m) throw new Error(`unknown package ${name}@${version}`);
    return m;
  }
}
