import { topoOrder } from './graph.ts';
import { resolve } from './resolver.ts';
import type { Registry } from './registry.ts';
import type { Manifest, Plan } from './types.ts';

const MS_PER_DECISECOND = 1000;

/** Resolves the dependencies of `root`, orders the builds and estimates the wall-clock time. */
export function plan(root: Pick<Manifest, 'deps'>, registry: Registry): Plan {
  const { nodes } = resolve(root.deps, registry);
  const { order, cycles } = topoOrder(nodes);

  const level = new Map<string, number>();
  const waves: string[][] = [];
  for (const key of order) {
    const node = nodes.get(key)!;
    const at = 1 + Math.max(-1, ...node.deps.filter((d) => level.has(d)).map((d) => level.get(d)!));
    level.set(key, at);
    (waves[at] ??= []).push(key);
  }
  for (const wave of waves) wave.sort();

  let deciseconds = 0;
  for (const wave of waves) deciseconds += Math.max(...wave.map((k) => nodes.get(k)!.build));
  return { order, waves, cycles, estimateMs: deciseconds * MS_PER_DECISECOND };
}
