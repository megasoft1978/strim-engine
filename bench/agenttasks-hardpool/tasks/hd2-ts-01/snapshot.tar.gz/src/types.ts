/** A parsed `major.minor.patch` version (no prerelease or build metadata). */
export interface Version {
  major: number;
  minor: number;
  patch: number;
}

/** One published package version, as stored in the registry. */
export interface Manifest {
  name: string;
  version: string;
  /** Dependency name -> semver range. */
  deps: Record<string, string>;
  /** Time needed to build this package, in deciseconds (1 = 100 ms). */
  build: number;
}

/** A resolved package version; `deps` holds the keys (`name@version`) of its dependencies, sorted. */
export interface Node {
  name: string;
  version: string;
  key: string;
  deps: string[];
  build: number;
}

export interface Resolution {
  /** Keys of the direct dependencies of the root, sorted. */
  roots: string[];
  nodes: Map<string, Node>;
}

export interface Plan {
  /** Build order, dependencies first. */
  order: string[];
  /** Keys grouped by the earliest wave in which they can be built in parallel; keys sorted inside a wave. */
  waves: string[][];
  /** Each cycle is a closed path such as `a@1.0.0 -> b@1.0.0 -> a@1.0.0`, as an array of keys. */
  cycles: string[][];
  /** Estimated wall-clock build time in milliseconds: waves run one after another, a wave takes as long as its slowest build. */
  estimateMs: number;
}
