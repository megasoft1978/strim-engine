import { test, expect, describe } from 'bun:test';
import { renderToStaticMarkup } from 'react-dom/server';
import { buildOffsets, rowHeight } from '../src/heights.js';
import { computeRange, findIndex } from '../src/window.js';
import { initialSelection, selectionReducer } from '../src/selection.js';
import { scrollToIndex } from '../src/scroll.js';
import { VirtualList } from '../src/VirtualList.jsx';

const mkRows = (n) => Array.from({ length: n }, (_, i) => ({ label: `Row ${i}` }));
const render = (props) => renderToStaticMarkup(<VirtualList rows={mkRows(10)} {...props} />);
const rowIndexes = (html) => [...html.matchAll(/data-index="(\d+)"/g)].map((m) => Number(m[1]));
const click = (state, index, mods = {}) => selectionReducer(state, { type: 'click', index, ...mods });

describe('heights', () => {
  test('rowHeight uses a measured value only when it is a positive number', () => {
    expect(rowHeight({ 0: 50 }, 0)).toBe(50);
    expect(rowHeight({ 0: 0 }, 0)).toBe(32);
    expect(rowHeight({ 0: NaN }, 0, 20)).toBe(20);
    expect(rowHeight({}, 3, 20)).toBe(20);
  });
});

describe('window math', () => {
  const offsets = buildOffsets(10, {}, 32);

  test('findIndex returns the row containing a pixel', () => {
    expect(findIndex(offsets, 0)).toBe(0);
    expect(findIndex(offsets, 31)).toBe(0);
    expect(findIndex(offsets, 32)).toBe(1);
    expect(findIndex(offsets, 9999)).toBe(9);
  });

  test('range of a viewport at the top', () => {
    expect(computeRange({ offsets, scrollTop: 0, viewport: 96, headerHeight: 32 })).toEqual({ start: 0, end: 2 });
  });

  test('a row that starts exactly at the bottom edge is not visible', () => {
    expect(computeRange({ offsets, scrollTop: 0, viewport: 128, headerHeight: 32 })).toEqual({ start: 0, end: 3 });
    expect(computeRange({ offsets, scrollTop: 0, viewport: 129, headerHeight: 32 })).toEqual({ start: 0, end: 4 });
  });

  test('scrolled range accounts for the sticky header', () => {
    expect(computeRange({ offsets, scrollTop: 64, viewport: 96, headerHeight: 32 })).toEqual({ start: 2, end: 4 });
    expect(computeRange({ offsets, scrollTop: 80, viewport: 96, headerHeight: 32 })).toEqual({ start: 2, end: 5 });
  });

  test('overscan widens both sides and stays inside the list', () => {
    expect(computeRange({ offsets, scrollTop: 96, viewport: 96, headerHeight: 32, overscan: 2 })).toEqual({ start: 1, end: 7 });
    expect(computeRange({ offsets, scrollTop: 0, viewport: 96, headerHeight: 32, overscan: 3 })).toEqual({ start: 0, end: 5 });
  });

  test('window larger than the list covers exactly the list', () => {
    expect(computeRange({ offsets: buildOffsets(3, {}, 32), scrollTop: 0, viewport: 500, headerHeight: 32, overscan: 2 })).toEqual({ start: 0, end: 3 });
  });

  test('scrolled past the end still shows the tail', () => {
    expect(computeRange({ offsets, scrollTop: 5000, viewport: 96, headerHeight: 32, overscan: 1 })).toEqual({ start: 8, end: 10 });
  });

  test('empty list has an empty range', () => {
    expect(computeRange({ offsets: buildOffsets(0), scrollTop: 0, viewport: 200, headerHeight: 32, overscan: 2 })).toEqual({ start: 0, end: 0 });
  });

  test('measured heights move the boundaries', () => {
    const o = buildOffsets(6, { 0: 100, 2: 10 }, 32);
    expect(o).toEqual([0, 100, 132, 142, 174, 206, 238]);
    expect(computeRange({ offsets: o, scrollTop: 101, viewport: 82, headerHeight: 32 })).toEqual({ start: 1, end: 4 });
  });
});

describe('scrollToIndex', () => {
  const offsets = buildOffsets(10, {}, 32);
  test('keeps the row fully inside the body area', () => {
    const args = { offsets, scrollTop: 0, viewport: 132, headerHeight: 32 };
    expect(scrollToIndex({ ...args, index: 2 })).toBe(0);
    expect(scrollToIndex({ ...args, index: 5 })).toBe(92);
    expect(scrollToIndex({ ...args, index: 9 })).toBe(220);
    expect(scrollToIndex({ ...args, scrollTop: 200, index: 1 })).toBe(32);
  });
});

describe('selection reducer', () => {
  test('plain click selects one row and sets the anchor', () => {
    const s = click(click(initialSelection, 4), 2);
    expect(s).toEqual({ selected: [2], anchor: 2 });
  });

  test('ctrl click toggles and moves the anchor', () => {
    let s = click(initialSelection, 1);
    s = click(s, 5, { ctrl: true });
    s = click(s, 3, { ctrl: true });
    expect(s).toEqual({ selected: [1, 3, 5], anchor: 3 });
    s = click(s, 5, { ctrl: true });
    expect(s).toEqual({ selected: [1, 3], anchor: 5 });
  });

  test('shift click selects the span and keeps the anchor', () => {
    let s = click(initialSelection, 2);
    s = click(s, 5, { shift: true });
    expect(s).toEqual({ selected: [2, 3, 4, 5], anchor: 2 });
    s = click(s, 0, { shift: true });
    expect(s).toEqual({ selected: [0, 1, 2], anchor: 2 });
  });

  test('shift without an anchor acts like a plain click', () => {
    expect(click(initialSelection, 3, { shift: true })).toEqual({ selected: [3], anchor: 3 });
  });

  test('ctrl+shift adds the span to the current selection', () => {
    let s = click(initialSelection, 0);
    s = click(s, 6, { ctrl: true });
    s = click(s, 4, { ctrl: true, shift: true });
    expect(s).toEqual({ selected: [0, 4, 5, 6], anchor: 6 });
  });

  test('selectAll, trim and clear', () => {
    let s = click(initialSelection, 7);
    s = selectionReducer(s, { type: 'selectAll', count: 4 });
    expect(s).toEqual({ selected: [0, 1, 2, 3], anchor: 7 });
    s = selectionReducer(s, { type: 'trim', count: 2 });
    expect(s).toEqual({ selected: [0, 1], anchor: null });
    expect(selectionReducer(s, { type: 'clear' })).toEqual(initialSelection);
    expect(selectionReducer(initialSelection, { type: 'selectAll', count: 0 }).selected).toEqual([]);
  });
});

describe('VirtualList markup', () => {
  test('renders only the windowed rows with overscan', () => {
    const html = render({ viewport: 96, headerHeight: 32, overscan: 1 });
    expect(rowIndexes(html)).toEqual([0, 1, 2]);
    expect(html).toContain('data-start="0"');
    expect(html).toContain('data-end="3"');
  });

  test('scrolled window positions rows absolutely', () => {
    const html = render({ scrollTop: 96, viewport: 96, headerHeight: 32, overscan: 0 });
    expect(rowIndexes(html)).toEqual([3, 4]);
    expect(html).toContain('top:96px;height:32px');
    expect(html).toContain('top:128px;height:32px');
  });

  test('body height is the sum of all row heights', () => {
    const html = render({ measured: { 1: 80 }, viewport: 96 });
    expect(html).toContain('role="presentation" style="position:relative;height:368px"');
  });

  test('the last row is reachable and may be partially visible', () => {
    const html = render({ scrollTop: 270, viewport: 96, headerHeight: 32, overscan: 0 });
    expect(rowIndexes(html)).toEqual([8, 9]);
    expect(html).toContain('Row 9');
  });

  test('measured heights drive row geometry', () => {
    const html = render({ measured: { 0: 100 }, viewport: 164, headerHeight: 32, overscan: 0 });
    expect(rowIndexes(html)).toEqual([0, 1]);
    expect(html).toContain('top:100px;height:32px');
  });

  test('aria row numbering counts the header row', () => {
    const html = render({ viewport: 96, overscan: 0 });
    expect(html).toContain('aria-rowcount="11"');
    expect(html).toContain('aria-rowindex="1"');
    expect(html).toContain('aria-rowindex="2" aria-selected="false" data-index="0"');
  });

  test('selected rows are flagged and counted in the header', () => {
    const selection = { selected: [1, 2], anchor: 1 };
    const html = render({ viewport: 128, overscan: 0, selection });
    expect(html).toContain('aria-selected="true" data-index="1"');
    expect(html).toContain('aria-selected="false" data-index="0"');
    expect(html).toContain('2 selected');
  });

  test('empty list shows a status instead of rows', () => {
    const html = render({ rows: [] });
    expect(html).toContain('Nothing to show');
    expect(rowIndexes(html)).toEqual([]);
    expect(html).toContain('aria-rowcount="1"');
    expect(html).toContain('data-end="0"');
  });

  test('a short list renders every row once', () => {
    const html = render({ rows: mkRows(2), viewport: 400, overscan: 3 });
    expect(rowIndexes(html)).toEqual([0, 1]);
  });
});
