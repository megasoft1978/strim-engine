import { DEFAULT_ROW, buildOffsets } from './heights.js';
import { computeRange } from './window.js';
import { initialSelection } from './selection.js';
import { Header } from './Header.jsx';
import { Row } from './Row.jsx';

export function VirtualList({
  rows,
  measured = {},
  rowHeight = DEFAULT_ROW,
  scrollTop = 0,
  viewport = 200,
  headerHeight = 32,
  overscan = 2,
  selection = initialSelection,
  title = 'Items',
}) {
  const offsets = buildOffsets(rows.length, measured, rowHeight);
  const total = offsets[offsets.length - 1];
  const { start, end } = computeRange({ offsets, scrollTop, viewport, headerHeight, overscan });
  const items = [];
  for (let i = start; i < end; i++) {
    items.push(
      <Row
        key={i}
        index={i}
        label={rows[i].label}
        top={offsets[i]}
        height={offsets[i + 1] - offsets[i]}
        selected={selection.selected.includes(i)}
      />,
    );
  }
  return (
    <div
      role="grid"
      aria-label={title}
      aria-rowcount={rows.length + 1}
      data-start={start}
      data-end={end}
      style={{ position: 'relative', height: viewport, overflow: 'auto' }}
    >
      <Header height={headerHeight} title={title} selectedCount={selection.selected.length} />
      {rows.length === 0 ? (
        <div role="status">Nothing to show</div>
      ) : (
        <div role="presentation" style={{ position: 'relative', height: total }}>
          {items}
        </div>
      )}
    </div>
  );
}
