// Index of the row containing pixel y (largest i with offsets[i] <= y), clamped to the last row.
export function findIndex(offsets, y) {
  const count = offsets.length - 1;
  let lo = 0;
  let hi = count - 1;
  while (lo < hi) {
    const mid = (lo + hi + 1) >> 1;
    if (offsets[mid] <= y) lo = mid;
    else hi = mid - 1;
  }
  return lo;
}

// Rows to render as a half-open range [start, end).
// The sticky header covers the top `headerHeight` px of the viewport, so the body is visible
// from y = scrollTop to y = scrollTop + viewport - headerHeight (exclusive).
export function computeRange({ offsets, scrollTop = 0, viewport = 0, headerHeight = 0, overscan = 0 }) {
  const count = offsets.length - 1;
  if (count <= 0) return { start: 0, end: 0 };
  const top = Math.max(0, scrollTop - headerHeight);
  const bottom = scrollTop + viewport;
  const first = findIndex(offsets, top);
  const last = findIndex(offsets, Math.max(top, bottom));
  return {
    start: Math.max(0, first - overscan),
    end: last + 1 + overscan,
  };
}
