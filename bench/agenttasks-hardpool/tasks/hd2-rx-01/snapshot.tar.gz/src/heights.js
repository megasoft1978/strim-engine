export const DEFAULT_ROW = 32;

// Height of one row: the measured value when it is a positive finite number, else the fallback.
export function rowHeight(measured, index, fallback = DEFAULT_ROW) {
  const h = measured[index];
  return Number.isFinite(h) && h > 0 ? h : fallback;
}

// offsets[i] is the top of row i; offsets[count] is the total height (so offsets.length === count + 1).
export function buildOffsets(count, measured = {}, fallback = DEFAULT_ROW) {
  const offsets = [0];
  for (let i = 0; i < count - 1; i++) {
    offsets.push(offsets[i] + rowHeight(measured, i, fallback));
  }
  return offsets;
}
