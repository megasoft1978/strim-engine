export const initialSelection = { selected: [], anchor: null };

function span(a, b) {
  const lo = Math.min(a, b);
  const hi = Math.max(a, b);
  const out = [];
  for (let i = lo; i <= hi; i++) out.push(i);
  return out;
}

function normalize(list) {
  return [...new Set(list)].sort((a, b) => a - b);
}

// State: { selected: number[] (ascending, unique), anchor: number | null }.
// click { index, shift, ctrl }:
//   plain       -> only `index`; anchor = index
//   ctrl        -> toggle `index`; anchor = index
//   shift       -> replace with the span anchor..index; anchor is kept (no anchor: behaves like plain)
//   ctrl+shift  -> add the span anchor..index to the selection; anchor is kept
// selectAll { count } selects 0..count-1 and keeps the anchor.
// trim { count } drops indexes >= count; an anchor >= count becomes null.
// clear resets to the initial state.
export function selectionReducer(state, action) {
  switch (action.type) {
    case 'click': {
      const { index, shift = false, ctrl = false } = action;
      if (shift && state.anchor !== null) {
        const range = span(state.anchor, index);
        const selected = ctrl ? normalize([...state.selected, ...range]) : range;
        return { selected, anchor: index };
      }
      if (ctrl) {
        const has = state.selected.includes(index);
        const selected = has ? state.selected.filter((i) => i !== index) : normalize([...state.selected, index]);
        return { selected, anchor: index };
      }
      return { selected: [index], anchor: index };
    }
    case 'selectAll':
      return { selected: Array.from({ length: Math.max(0, action.count) }, (_, i) => i), anchor: state.anchor };
    case 'trim':
      return {
        selected: state.selected.filter((i) => i < action.count),
        anchor: state.anchor !== null && state.anchor >= action.count ? null : state.anchor,
      };
    case 'clear':
      return initialSelection;
    default:
      return state;
  }
}
