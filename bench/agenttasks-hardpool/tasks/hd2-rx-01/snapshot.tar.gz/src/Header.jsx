export function Header({ height, title, selectedCount }) {
  return (
    <div role="row" aria-rowindex={1} style={{ position: 'sticky', top: 0, height }}>
      <span role="columnheader">{title}</span>
      {selectedCount > 0 ? <span role="status">{selectedCount} selected</span> : null}
    </div>
  );
}
