// Smallest scrollTop change that brings row `index` fully into the body area
// (the viewport minus the sticky header), clamped to the scrollable range.
export function scrollToIndex({ offsets, index, scrollTop = 0, viewport = 0, headerHeight = 0 }) {
  const count = offsets.length - 1;
  if (count <= 0) return 0;
  const i = Math.min(Math.max(0, index), count - 1);
  const visible = Math.max(0, viewport - headerHeight);
  const maxTop = Math.max(0, offsets[count] - visible);
  let next = scrollTop;
  if (offsets[i] < scrollTop) next = offsets[i];
  else if (offsets[i + 1] > scrollTop + visible) next = offsets[i + 1] - visible;
  return Math.min(Math.max(0, next), maxTop);
}
