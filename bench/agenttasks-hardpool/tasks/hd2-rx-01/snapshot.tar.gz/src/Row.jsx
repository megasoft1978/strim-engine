export function Row({ index, label, top, height, selected }) {
  return (
    <div
      role="row"
      aria-rowindex={index + 2}
      aria-selected={selected}
      data-index={index}
      style={{ position: 'absolute', top, height }}
    >
      <span role="gridcell">{label}</span>
    </div>
  );
}
