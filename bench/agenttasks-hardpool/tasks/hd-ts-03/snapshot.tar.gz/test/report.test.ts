import { test } from "node:test";
import assert from "node:assert/strict";
import { report } from "../src/report.ts";
import { dedupe } from "../src/dedupe.ts";
import { normalizeTags, sortBy } from "../src/util.ts";
import type { Ticket } from "../src/types.ts";

const t = (id: number, title: string, priority: number, tags: string[]): Ticket => ({ id, title, priority, tags });

const input: Ticket[] = [
  t(1, "Login fails", 2, ["Web", "auth"]),
  t(2, "Slow search", 5, ["perf"]),
  t(3, "login fails", 1, ["Bug"]),
  t(4, "Crash on save", 5, ["bug", "Web"]),
];

test("sortBy is stable", () => {
  assert.deepEqual(sortBy([3, 1, 2, 1], (x) => x), [1, 1, 2, 3]);
  assert.deepEqual(sortBy(["bb", "a", "cc", "d"], (x) => x.length), ["a", "d", "bb", "cc"]);
});

test("normalizeTags lowercases, trims, de-duplicates and sorts", () => {
  assert.deepEqual(normalizeTags([" Web", "auth", "WEB"]), ["auth", "web"]);
});

test("dedupe merges tags into the first duplicate", () => {
  const out = dedupe(input);
  assert.deepEqual(out.map((x) => x.id), [1, 2, 4]);
  assert.deepEqual(out[0].tags, ["auth", "bug", "web"]);
});

test("dedupe leaves its input alone", () => {
  const before = JSON.stringify(input);
  dedupe(input);
  assert.equal(JSON.stringify(input), before);
});

test("report ranks by priority (ties keep input order) and counts tags", () => {
  const r = report(input, 2);
  assert.deepEqual(r.top, [2, 4]);
  assert.deepEqual(r.byTag, { auth: 1, bug: 2, web: 2, perf: 1 });
});

test("report is repeatable", () => {
  assert.deepEqual(report(input, 3), report(input, 3));
  assert.deepEqual(input.map((x) => x.id), [1, 2, 3, 4]);
});

test("renderReport lists the top ids then tags by count", async () => {
  const { renderReport } = await import("../src/format.ts");
  assert.equal(renderReport(report(input, 2)), "top: 2, 4\nbug: 2\nweb: 2\nauth: 1\nperf: 1");
});

test("a lower n only truncates the ranking", () => {
  assert.deepEqual(report(input, 1).top, [2]);
  assert.deepEqual(report(input, 10).top, [2, 4, 1]);
});
