import { test } from "node:test";
import assert from "node:assert/strict";
import { Store } from "../src/store.ts";
import { report } from "../src/report.ts";
import type { Ticket } from "../src/types.ts";

const t = (id: number, title: string, priority: number, tags: string[]): Ticket => ({ id, title, priority, tags });

function seeded(): Store {
  const s = new Store();
  s.add(t(1, "Login fails", 2, ["web", "Auth"]));
  s.add(t(2, "Slow search", 5, ["perf"]));
  s.add(t(3, "login fails", 1, ["Bug"]));
  s.add(t(4, "Crash on save", 5, ["bug", "Web"]));
  return s;
}

test("list keeps insertion order", () => {
  assert.deepEqual(seeded().list().map((x) => x.id), [1, 2, 3, 4]);
});

test("reporting does not reorder or rewrite the store", () => {
  const s = seeded();
  const r = report(s.list(), 2);
  assert.deepEqual(r.top, [2, 4]);
  assert.deepEqual(s.list().map((x) => x.id), [1, 2, 3, 4]);
  assert.deepEqual(s.get(1)?.tags, ["web", "Auth"]);
  assert.deepEqual(s.get(4)?.tags, ["bug", "Web"]);
});

test("the store does not alias what the caller added", () => {
  const s = new Store();
  const ticket = t(9, "x", 1, ["b", "a"]);
  s.add(ticket);
  ticket.tags.push("c");
  assert.deepEqual(s.get(9)?.tags, ["b", "a"]);
});
