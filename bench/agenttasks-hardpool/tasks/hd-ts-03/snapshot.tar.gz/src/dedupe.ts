import { normalizeTags } from "./util.ts";
import type { Ticket } from "./types.ts";

/** Tickets whose titles match case-insensitively are duplicates; the first one wins and absorbs the tags of the others. */
export function dedupe(tickets: readonly Ticket[]): Ticket[] {
  const byTitle = new Map<string, Ticket>();
  for (const t of tickets) {
    const key = t.title.trim().toLowerCase();
    const seen = byTitle.get(key);
    if (seen) seen.tags = normalizeTags([...seen.tags, ...t.tags]);
    else byTitle.set(key, { ...t, tags: normalizeTags(t.tags) });
  }
  return [...byTitle.values()];
}
