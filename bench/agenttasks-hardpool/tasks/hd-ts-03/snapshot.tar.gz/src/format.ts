import type { Report } from "./report.ts";

/** "top: 2, 4" then one "tag: count" line per tag, most used first, ties alphabetical. */
export function renderReport(r: Report): string {
  const tags = Object.entries(r.byTag).sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : 1));
  return [`top: ${r.top.join(", ")}`, ...tags.map(([tag, n]) => `${tag}: ${n}`)].join("\n");
}
