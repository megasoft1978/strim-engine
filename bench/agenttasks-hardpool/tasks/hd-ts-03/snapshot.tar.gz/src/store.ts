import type { Ticket } from "./types.ts";

/** In-memory ticket store that hands out read-only views of its tickets. */
export class Store {
  private items: Ticket[] = [];

  add(t: Ticket): void {
    this.items.push({ ...t, tags: [...t.tags] });
  }

  /** All tickets in insertion order. A read-only view: callers must not modify it. */
  list(): readonly Ticket[] {
    return this.items;
  }

  get(id: number): Readonly<Ticket> | undefined {
    return this.items.find((x) => x.id === id);
  }

  /** Removes a ticket; returns whether it existed. */
  remove(id: number): boolean {
    const i = this.items.findIndex((x) => x.id === id);
    if (i < 0) return false;
    this.items.splice(i, 1);
    return true;
  }

  get size(): number {
    return this.items.length;
  }
}
