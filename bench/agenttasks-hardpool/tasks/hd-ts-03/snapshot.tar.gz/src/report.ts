import { dedupe } from "./dedupe.ts";
import { sortBy } from "./util.ts";
import type { Ticket } from "./types.ts";

export interface Report {
  top: number[];
  byTag: Record<string, number>;
}

/** Ids of the `n` highest-priority tickets (ties keep store order) and a per-tag ticket count, after de-duplication. */
export function report(tickets: readonly Ticket[], n: number): Report {
  const unique = dedupe(tickets);
  const keep = new Set(unique.map((t) => t.id));
  const top = sortBy(tickets, (t) => -t.priority)
    .filter((t) => keep.has(t.id))
    .slice(0, n)
    .map((t) => t.id);
  const byTag: Record<string, number> = {};
  for (const t of unique) for (const tag of t.tags) byTag[tag] = (byTag[tag] ?? 0) + 1;
  return { top, byTag };
}
