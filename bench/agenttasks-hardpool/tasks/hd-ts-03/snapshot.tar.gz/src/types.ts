export interface Ticket {
  id: number;
  title: string;
  priority: number;
  tags: string[];
}
