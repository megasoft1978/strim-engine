# Order Desk

A server-rendered order browser. `renderOrders` accepts an array of orders and
URL search parameters, and returns a model plus static HTML. An order has an id,
customer, region, status, integer amount in cents, and ISO date. IDs are unique.

Search is case-insensitive over customer and id. Status and region filters match
case-insensitively; omitted filters match all rows. Sorting uses the selected
column, with id as a stable tie-breaker. Group summaries describe all matching
orders before pagination, and appear in first-occurrence order after sorting.
The requested page is clamped to the available range. Empty results use page 1
of 1. Changing a filter retains the requested page unless it needs clamping.

`report` provides independent whole-ledger summaries for exports. Its totals are
not intended to reflect the current browser query. Run the offline suite with
`bun test`; React and the server renderer are included in node_modules.
