import { describe, test, expect } from 'bun:test';
import { renderOrders } from '../src/index.jsx';
import { buildTable } from '../src/model.js';
import { parseParams } from '../src/params.js';
import { report, exportLines } from '../src/report.js';
import { sortLink } from '../src/links.js';
import { money } from '../src/format.js';

const orders = [
  { id: 'A1', customer: 'Ada', region: 'North', status: 'open', amount: 1100, date: '2026-01-04' },
  { id: 'B2', customer: 'Bea', region: 'South', status: 'closed', amount: 2200, date: '2026-01-01' },
  { id: 'C3', customer: 'Cara', region: 'North', status: 'open', amount: 3300, date: '2026-01-03' },
  { id: 'D4', customer: 'Dan', region: 'South', status: 'open', amount: 4400, date: '2026-01-02' },
  { id: 'E5', customer: 'Eda', region: 'North', status: 'closed', amount: 5500, date: '2026-01-05' },
  { id: 'F6', customer: 'Fay', region: 'South', status: 'open', amount: 6600, date: '2026-01-06' },
];

describe('orders browser', () => {
  test('renders filtered range and clamped page', () => {
    const { model, html } = renderOrders(orders, '?status=closed&size=1&page=5');
    expect(model.rows.map(x => x.id)).toEqual(['E5']);
    expect(html).toContain('2–2 of 2 orders');
    expect(html).toContain('Page 2 of 2');
    expect(html).not.toContain('>Next</a>');
  });
  test('shows summaries for the complete matching set, including off-page rows', () => {
    const { model, html } = renderOrders(orders, '?status=open&group=region&sort=amount&dir=desc&size=1');
    expect(model.groups).toEqual([
      { label: 'South', count: 2, amount: 11000 },
      { label: 'North', count: 2, amount: 4400 },
    ]);
    expect(html).toContain('South: 2 orders, $110.00');
    expect(html).toContain('North: 2 orders, $44.00');
  });
  test('empty filtered results do not offer phantom pages', () => {
    const { model, html } = renderOrders(orders, '?q=absent&group=status&page=3&size=2');
    expect(model.groups).toEqual([]);
    expect(model.rows).toEqual([]);
    expect(html).toContain('No orders');
    expect(html).toContain('Page 1 of 1');
  });
  test('filter changes produce fresh counts and summaries on subsequent requests', () => {
    const first = buildTable(orders, '?region=north&group=status');
    const second = buildTable(orders, '?region=south&group=status');
    expect(first.total).toBe(3);
    expect(second.groups).toEqual([
      { label: 'closed', count: 1, amount: 2200 },
      { label: 'open', count: 2, amount: 11000 },
    ]);
    expect(second.total).toBe(3);
  });
  test('sorting and pagination never mutate the source', () => {
    const ids = orders.map(x => x.id);
    const model = buildTable(orders, '?sort=date&dir=desc&size=2&page=2');
    expect(model.rows.map(x => x.id)).toEqual(['A1', 'C3']);
    expect(orders.map(x => x.id)).toEqual(ids);
  });
  test('normalizes invalid options and supports case insensitive intersection', () => {
    const options = parseParams('?size=-1&page=0&sort=nope&group=unknown');
    expect([options.page, options.pageSize, options.sort, options.group]).toEqual([1, 10, 'id', '']);
    expect(buildTable(orders, '?q=DA&region=NORTH&status=OPEN').rows.map(x => x.id)).toEqual(['A1']);
  });
  test('escapes customer markup in server-rendered output', () => {
    const row = { ...orders[0], customer: '<script>alert(1)</script>' };
    const { html } = renderOrders([row]);
    expect(html).toContain('&lt;script&gt;');
    expect(html).not.toContain('<script>');
  });
  test('export report is independent of table filters', () => {
    expect(report(orders).amount).toBe(23100);
    expect(report(orders).byStatus.closed.count).toBe(2);
    expect(exportLines([{ ...orders[0], customer: 'A "quoted" name' }])[0]).toContain('"A ""quoted"" name"');
    expect(money(-5)).toBe('-$0.05');
    expect(sortLink('?q=ada&page=3', 'amount', 'desc')).toBe('?q=ada&sort=amount&dir=desc');
  });
});

test('ledger and import helpers validate independent accounting workflows', async () => {
  const { prepareImport } = await import('../src/validate.js');
  const { ledgerByMonth, ledgerByRegion, compareLedgers } = await import('../src/ledger.js');
  const { ledgerCsv, readCsvLine } = await import('../src/csv.js');
  expect(prepareImport(orders).rows).toHaveLength(6);
  expect(prepareImport([...orders, orders[0]]).errors[0].message).toBe('Duplicate id');
  expect(prepareImport([{ ...orders[0], date: '2026-02-30' }]).rows).toEqual([]);
  expect(ledgerByMonth(orders)[0].amount).toBe(23100);
  expect(compareLedgers([], ledgerByRegion(orders))[0].countDelta).toBe(3);
  expect(ledgerCsv([{ key: 'North, East', count: 1, amount: 50, min: 50, max: 50 }])).toContain('"North, East",1,50,50,50');
  expect(readCsvLine('"North, East",1')).toEqual(['North, East', '1']);
});
