import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { buildTable } from './model.js';
import { Table } from './Table.jsx';

/** Render a request without depending on a browser or a global store. */
export function renderOrders(orders, search = '') {
  const model = buildTable(orders, search);
  const html = renderToStaticMarkup(<Table model={model} search={search} />);
  return { model, html };
}
