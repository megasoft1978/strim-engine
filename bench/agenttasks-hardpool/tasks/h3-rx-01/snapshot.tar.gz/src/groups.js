/** Summaries preserve the first appearance of each group in sorted results. */
export function summarizeGroups(orders, field) {
  if (!field) return [];
  const groups = new Map();
  for (const order of orders) {
    const label = order[field];
    let summary = groups.get(label);
    if (!summary) {
      summary = { label, count: 0, amount: 0 };
      groups.set(label, summary);
    }
    summary.count += 1;
    summary.amount += order.amount;
  }
  return [...groups.values()];
}
