import React from 'react';
import { money, rangeLabel } from './format.js';
import { pageLink } from './links.js';

export function Table({ model, search = '' }) {
  return <section aria-label="Orders">
    <p data-testid="range">{rangeLabel(model)}</p>
    {model.groups.length > 0 && <ul aria-label="Group totals">
      {model.groups.map(group => <li key={group.label}>
        {group.label}: {group.count} orders, {money(group.amount)}
      </li>)}
    </ul>}
    <table>
      <thead><tr><th>ID</th><th>Customer</th><th>Region</th><th>Status</th><th>Amount</th></tr></thead>
      <tbody>{model.rows.map(order => <tr key={order.id}>
        <td>{order.id}</td><td>{order.customer}</td><td>{order.region}</td>
        <td>{order.status}</td><td>{money(order.amount)}</td>
      </tr>)}</tbody>
    </table>
    <nav aria-label="Pages">
      {model.page > 1 && <a href={pageLink(search, model.page - 1)}>Previous</a>}
      <span>Page {model.page} of {model.pages}</span>
      {model.page < model.pages && <a href={pageLink(search, model.page + 1)}>Next</a>}
    </nav>
  </section>;
}
