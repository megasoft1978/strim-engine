/** Format cents without losing the sign on amounts between -99 and 0. */
export function money(cents) {
  const sign = cents < 0 ? '-' : '';
  const absolute = Math.abs(cents);
  return `${sign}$${Math.floor(absolute / 100)}.${String(absolute % 100).padStart(2, '0')}`;
}

export function rangeLabel(model) {
  if (!model.total) return 'No orders';
  return `${model.first}–${model.last} of ${model.total} orders`;
}
