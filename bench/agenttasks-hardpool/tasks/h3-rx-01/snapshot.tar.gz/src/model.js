import { parseParams } from './params.js';
import { selectOrders } from './filter.js';
import { sortOrders } from './sort.js';
import { summarizeGroups } from './groups.js';
import { paginate } from './pagination.js';

/** Build the complete display model for a request. */
export function buildTable(orders, search = '') {
  const options = parseParams(search);
  const matching = selectOrders(orders, options);
  const sorted = sortOrders(matching, options);
  const pagination = paginate(sorted, options.page, options.pageSize, orders.length);
  const groups = summarizeGroups(orders, options.group);
  return { options, groups, ...pagination };
}
