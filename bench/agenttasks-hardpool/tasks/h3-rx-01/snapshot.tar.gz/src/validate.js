/** Validate an import without changing any input records. */
const requiredText = ['id', 'customer', 'region', 'status', 'date'];
const datePattern = /^\d{4}-\d{2}-\d{2}$/;

function isCalendarDate(value) {
  if (!datePattern.test(value)) return false;
  const date = new Date(`${value}T00:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

export function validateOrders(records) {
  const errors = [];
  const ids = new Set();
  if (!Array.isArray(records)) return [{ row: 0, field: '', message: 'Expected an array' }];
  records.forEach((record, index) => {
    const row = index + 1;
    if (!record || typeof record !== 'object' || Array.isArray(record)) {
      errors.push({ row, field: '', message: 'Expected a record' });
      return;
    }
    for (const field of requiredText) {
      if (typeof record[field] !== 'string' || !record[field].trim()) {
        errors.push({ row, field, message: 'Required text' });
      }
    }
    if (typeof record.id === 'string' && record.id.trim()) {
      if (ids.has(record.id)) errors.push({ row, field: 'id', message: 'Duplicate id' });
      ids.add(record.id);
    }
    if (!Number.isSafeInteger(record.amount)) {
      errors.push({ row, field: 'amount', message: 'Expected integer cents' });
    }
    if (typeof record.date === 'string' && record.date && !isCalendarDate(record.date)) {
      errors.push({ row, field: 'date', message: 'Expected a calendar date' });
    }
  });
  return errors;
}

/** Import is atomic: return no rows if any record is invalid. */
export function prepareImport(records) {
  const errors = validateOrders(records);
  if (errors.length) return { rows: [], errors };
  return { rows: records.map(record => ({ ...record })), errors };
}
