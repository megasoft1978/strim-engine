/** Whole-ledger export summaries, deliberately independent of table state. */
export function report(orders) {
  const byStatus = {};
  let amount = 0;
  for (const order of orders) {
    amount += order.amount;
    const item = byStatus[order.status] || { count: 0, amount: 0 };
    item.count++;
    item.amount += order.amount;
    byStatus[order.status] = item;
  }
  return { count: orders.length, amount, byStatus };
}

export function exportLines(orders) {
  return orders.map(order => [order.id, order.customer, order.status, order.amount]
    .map(value => `"${String(value).replaceAll('"', '""')}"`).join(','));
}
