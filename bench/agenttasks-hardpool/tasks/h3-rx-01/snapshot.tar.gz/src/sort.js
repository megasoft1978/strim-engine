/** A deterministic sort that does not change the caller's order array. */
export function sortOrders(orders, options) {
  const direction = options.direction === 'desc' ? -1 : 1;
  const key = options.sort;
  return [...orders].sort((left, right) => {
    const a = left[key];
    const b = right[key];
    const comparison = typeof a === 'number' && typeof b === 'number'
      ? a - b
      : String(a).localeCompare(String(b), 'en', { sensitivity: 'base' });
    if (comparison !== 0) return comparison * direction;
    return String(left.id).localeCompare(String(right.id), 'en');
  });
}
