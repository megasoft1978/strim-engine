/** Convert user-provided search params into the supported table options. */
const sortable = new Set(['id', 'customer', 'region', 'status', 'amount', 'date']);
const groupable = new Set(['region', 'status']);

function positiveInt(value, fallback, max) {
  if (!/^\d+$/.test(value || '')) return fallback;
  const number = Number(value);
  if (!Number.isSafeInteger(number) || number < 1) return fallback;
  return Math.min(number, max);
}

export function parseParams(input = '') {
  const params = input instanceof URLSearchParams
    ? input
    : new URLSearchParams(String(input).replace(/^\?/, ''));
  const sort = params.get('sort') || 'id';
  const group = params.get('group') || '';
  return {
    query: (params.get('q') || '').trim(),
    status: (params.get('status') || '').trim(),
    region: (params.get('region') || '').trim(),
    sort: sortable.has(sort) ? sort : 'id',
    direction: params.get('dir') === 'desc' ? 'desc' : 'asc',
    group: groupable.has(group) ? group : '',
    page: positiveInt(params.get('page'), 1, 100000),
    pageSize: positiveInt(params.get('size'), 10, 100),
  };
}
