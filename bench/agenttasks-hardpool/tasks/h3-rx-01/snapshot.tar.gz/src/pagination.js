/** Page numbers are one-based, including for an empty result. */
export function paginate(orders, requestedPage, pageSize, total) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const page = Math.min(requestedPage, pages);
  const start = (page - 1) * pageSize;
  return {
    rows: orders.slice(start, start + pageSize),
    page,
    pages,
    pageSize,
    total,
    first: total === 0 ? 0 : start + 1,
    last: Math.min(start + pageSize, total),
  };
}
