/** Spreadsheet export of ledger aggregates. Callers choose the rows to export. */
const columns = ['key', 'count', 'amount', 'min', 'max'];

function csvCell(value) {
  const text = value == null ? '' : String(value);
  if (/[",\r\n]/.test(text)) return `"${text.replaceAll('"', '""')}"`;
  return text;
}

export function ledgerCsv(buckets) {
  const lines = [columns.join(',')];
  for (const bucket of buckets) {
    lines.push(columns.map(column => csvCell(bucket[column])).join(','));
  }
  return `${lines.join('\r\n')}\r\n`;
}

/** Small import helper; rejects malformed CSV instead of guessing at fields. */
export function readCsvLine(line) {
  const cells = [];
  let value = '';
  let quoted = false;
  let closed = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (quoted) {
      if (char === '"' && line[i + 1] === '"') {
        value += '"';
        i++;
      } else if (char === '"') {
        quoted = false;
        closed = true;
      } else value += char;
    } else if (char === ',') {
      cells.push(value);
      value = '';
      closed = false;
    } else if (char === '"' && value === '' && !closed) {
      quoted = true;
    } else if (char === '"' || closed) {
      throw new Error('Invalid CSV field');
    } else value += char;
  }
  if (quoted) throw new Error('Unclosed CSV field');
  cells.push(value);
  return cells;
}
