/** Preserve table options when constructing navigation links. */
export function pageLink(search, page) {
  const params = new URLSearchParams(String(search).replace(/^\?/, ''));
  params.set('page', String(page));
  return `?${params.toString()}`;
}

export function sortLink(search, column, direction) {
  const params = new URLSearchParams(String(search).replace(/^\?/, ''));
  params.set('sort', column);
  params.set('dir', direction);
  params.delete('page');
  return `?${params.toString()}`;
}
