/** Summaries used by a back-office ledger, not by the table view. */
function makeBucket(key) {
  return { key, count: 0, amount: 0, min: null, max: null };
}

function add(bucket, amount) {
  bucket.count += 1;
  bucket.amount += amount;
  bucket.min = bucket.min === null ? amount : Math.min(bucket.min, amount);
  bucket.max = bucket.max === null ? amount : Math.max(bucket.max, amount);
}

export function ledgerByMonth(orders) {
  const months = new Map();
  for (const order of orders) {
    const month = order.date.slice(0, 7);
    if (!months.has(month)) months.set(month, makeBucket(month));
    add(months.get(month), order.amount);
  }
  return [...months.values()].sort((left, right) => left.key.localeCompare(right.key));
}

export function ledgerByRegion(orders) {
  const regions = new Map();
  for (const order of orders) {
    if (!regions.has(order.region)) regions.set(order.region, makeBucket(order.region));
    add(regions.get(order.region), order.amount);
  }
  return [...regions.values()].sort((left, right) => left.key.localeCompare(right.key));
}

/** Diff two ledgers for accounting reconciliation. Missing buckets count as zero. */
export function compareLedgers(before, after) {
  const oldBuckets = new Map(before.map(item => [item.key, item]));
  const newBuckets = new Map(after.map(item => [item.key, item]));
  const keys = [...new Set([...oldBuckets.keys(), ...newBuckets.keys()])].sort();
  return keys.map(key => {
    const oldItem = oldBuckets.get(key);
    const newItem = newBuckets.get(key);
    return {
      key,
      countDelta: (newItem?.count || 0) - (oldItem?.count || 0),
      amountDelta: (newItem?.amount || 0) - (oldItem?.amount || 0),
    };
  });
}
