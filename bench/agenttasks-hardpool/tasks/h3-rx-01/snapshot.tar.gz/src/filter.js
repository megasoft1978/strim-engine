/** Filter without mutating the source collection or its rows. */
export function selectOrders(orders, options) {
  const query = options.query.toLocaleLowerCase();
  const status = options.status.toLocaleLowerCase();
  const region = options.region.toLocaleLowerCase();
  return orders.filter(order => {
    const matchesQuery = !query || [order.id, order.customer].some(value =>
      String(value).toLocaleLowerCase().includes(query));
    const matchesStatus = !status || order.status.toLocaleLowerCase() === status;
    const matchesRegion = !region || order.region.toLocaleLowerCase() === region;
    return matchesQuery && matchesStatus && matchesRegion;
  });
}
