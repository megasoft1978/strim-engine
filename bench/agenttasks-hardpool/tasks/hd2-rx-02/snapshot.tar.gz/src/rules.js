// Cross-field rules. Each one looks at several fields and reports on exactly one of them.
//
// crossFieldErrors(stepId, values, fieldErrors) -> { [field]: message }
//   `fieldErrors` holds the single-field errors already found for the step. A cross-field rule
//   never overwrites a field that already has an error, and is skipped when a field it depends
//   on is empty or invalid.
//
//   account: `confirm` must equal `password` exactly (no trimming) -> "Passwords do not match"
//            (only when confirm is non-empty; an empty confirm is the field-level error)
//   plan:    age (from the profile step) under 18 cannot pick team
//            -> plan: "Team plan requires age 18 or over" (skipped if age is not a valid integer)
//            coupon (trimmed, compared case-insensitively) with a free plan -> coupon: "Coupons need a paid plan"
//            unknown code -> "Unknown coupon"; known codes are SAVE10 (pro, team) and TEAM20 (team only);
//            TEAM20 on pro -> "Coupon not valid for this plan"
//            (no coupon rule runs while `plan` has an error or is empty)
export function crossFieldErrors(stepId, values, fieldErrors = {}) {
  throw new Error('not implemented');
}
