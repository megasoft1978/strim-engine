import { STEPS } from './steps.js';
import { validateAll, validateStep } from './validators.js';

export const initialState = { step: 0, furthest: 0, values: {}, errors: {}, done: false };

// Contract (return the same state object when an action changes nothing):
//   change { field, value }  store the value; remove the error of that field only
//   next      validate the current step. Errors -> stay on the step and store them.
//             No errors -> step + 1, errors cleared, furthest = max(furthest, step). Ignored on the summary step.
//   back      step - 1 (not below 0), errors cleared, values kept
//   goto { step }  jump to a step that is not the current one and is <= furthest; errors cleared; otherwise ignored
//   submit    only on the summary step: validateAll(values). Invalid -> go to that step with its errors.
//             Valid -> done: true, errors {}.
// Once done, every action except `restart` is ignored. `restart` returns initialState.
export function wizardReducer(state, action) {
  throw new Error('not implemented');
}
