import { PLANS } from './steps.js';

// Field({ field, value, error, onChange }) renders:
//   <div class="field">
//     <label for="field-NAME">LABEL</label>
//     <input|select id="field-NAME" name type value aria-invalid aria-describedby onChange>
//     hint  -> <p id="field-NAME-hint" class="hint">HINT</p>   (only when field.hint)
//     error -> <p id="field-NAME-error" class="error">ERROR</p> (only when error)
//   </div>
// aria-invalid="true" only when there is an error (attribute absent otherwise).
// aria-describedby lists the ids that exist, hint first, e.g. "field-password-hint field-password-error";
// absent when neither exists.
// type "select" renders <select> with a first empty option (value "", text "Choose...") then one option per PLANS key.
// The value is '' when undefined. onChange may be missing.
export function Field({ field, value, error, onChange }) {
  return null;
}
