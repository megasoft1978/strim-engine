import { STEPS } from './steps.js';

// ErrorSummary({ errors }) lists every error as a link to its field.
//   - no errors -> renders nothing (null)
//   - container: <div id="error-summary" role="alert" aria-live="assertive" tabindex="-1">
//     with <h2>There is a problem</h2> and a <ul> of <li><a href="#field-NAME">MESSAGE</a></li>
//   - order follows the field order of STEPS (not insertion order of `errors`)
export function ErrorSummary({ errors }) {
  return null;
}
