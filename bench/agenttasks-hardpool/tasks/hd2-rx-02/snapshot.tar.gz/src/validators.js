import { STEPS } from './steps.js';

// validateStep(stepId, values) -> { [field]: message }   ({} when valid; at most one message per field)
//
// Single-field rules (values are strings; missing means ''):
//   email    trimmed; empty -> "Email is required"; not /^[^\s@]+@[^\s@]+\.[^\s@]+$/ -> "Enter a valid email"
//   password not trimmed; empty -> "Password is required"; shorter than 8 -> "At least 8 characters";
//            no digit -> "Include a digit"
//   confirm  empty -> "Confirm your password"
//   name     trimmed; empty -> "Name is required"; longer than 40 -> "Name is too long"
//   age      trimmed; empty -> "Age is required"; not all digits, or outside 13..120 -> "Age must be between 13 and 120"
//   plan     must be one of PLANS -> otherwise "Choose a plan"
//   seats    only when plan is team: empty -> "Seats are required"; not an integer in 2..50 -> "Seats must be between 2 and 50"
//   coupon   optional
// Cross-field rules come from rules.js and are merged in. Fields hidden by visibleFields() are never validated.
// The summary step has no fields: validateStep('summary', values) is {}.
export function validateStep(stepId, values) {
  throw new Error('not implemented');
}

// validateAll(values) -> null when every step is valid, else { step: <index of the first invalid step>, errors }
export function validateAll(values) {
  throw new Error('not implemented');
}
