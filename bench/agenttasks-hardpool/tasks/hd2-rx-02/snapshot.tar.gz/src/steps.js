export const PLANS = { free: 'Free', pro: 'Pro', team: 'Team' };

// Field order here is the order used everywhere (rendering, error summary, validation).
export const STEPS = [
  {
    id: 'account',
    title: 'Account',
    fields: [
      { name: 'email', label: 'Email', type: 'email', hint: 'We never share it' },
      { name: 'password', label: 'Password', type: 'password', hint: 'At least 8 characters with a digit' },
      { name: 'confirm', label: 'Confirm password', type: 'password' },
    ],
  },
  {
    id: 'profile',
    title: 'Profile',
    fields: [
      { name: 'name', label: 'Name', type: 'text' },
      { name: 'age', label: 'Age', type: 'number' },
    ],
  },
  {
    id: 'plan',
    title: 'Plan',
    fields: [
      { name: 'plan', label: 'Plan', type: 'select' },
      { name: 'seats', label: 'Seats', type: 'number', onlyFor: 'team' },
      { name: 'coupon', label: 'Coupon', type: 'text' },
    ],
  },
  { id: 'summary', title: 'Summary', fields: [] },
];

export const LAST_INPUT_STEP = STEPS.length - 2;

// Fields of a step that are shown (and validated) for the current values.
export function visibleFields(step, values) {
  return step.fields.filter((f) => !f.onlyFor || values.plan === f.onlyFor);
}
