import { PLANS } from './steps.js';

// Summary({ values }) renders <dl aria-label="Summary"> with one <div><dt>LABEL</dt><dd>VALUE</dd></div> per row, in this order:
//   Email (trimmed), Name (trimmed), Age (trimmed), Plan (PLANS label),
//   Seats (only when plan is team), Coupon (only when non-empty and the plan is not free; trimmed, upper-cased),
//   Password (one "•" per character; the password itself is never printed)
// Missing values render as an empty <dd>.
export function Summary({ values }) {
  return null;
}
