import { PLANS, STEPS, LAST_INPUT_STEP, visibleFields } from './steps.js';
import { Field } from './Field.jsx';
import { ErrorSummary } from './ErrorSummary.jsx';
import { Summary } from './Summary.jsx';

const noop = () => {};

export function Wizard({ state, dispatch = noop }) {
  const { step, values, errors, done } = state;
  const current = STEPS[step];
  const onSummary = step === STEPS.length - 1;
  const primary = onSummary ? ['submit', 'Submit'] : step === LAST_INPUT_STEP ? ['next', 'Review'] : ['next', 'Next'];
  return (
    <form aria-labelledby="wizard-title" noValidate>
      <h1 id="wizard-title">Sign up</h1>
      <ol aria-label="Progress">
        {STEPS.map((s, i) => (
          <li key={s.id} aria-current={i === step ? 'step' : undefined} data-state={i < step ? 'done' : i === step ? 'current' : 'todo'}>
            {s.title}
          </li>
        ))}
      </ol>
      {done ? (
        <p role="status">
          Thanks, {(values.name || '').trim()}! Your {PLANS[values.plan]} plan is ready.
        </p>
      ) : (
        <>
          <ErrorSummary errors={errors} />
          <h2>{current.title}</h2>
          {onSummary ? (
            <Summary values={values} />
          ) : (
            visibleFields(current, values).map((f) => (
              <Field
                key={f.name}
                field={f}
                value={values[f.name]}
                error={errors[f.name]}
                onChange={(e) => dispatch({ type: 'change', field: f.name, value: e.target.value })}
              />
            ))
          )}
          <div>
            {step > 0 ? (
              <button type="button" data-action="back" onClick={() => dispatch({ type: 'back' })}>
                Back
              </button>
            ) : null}
            <button type="button" data-action={primary[0]} onClick={() => dispatch({ type: primary[0] })}>
              {primary[1]}
            </button>
          </div>
        </>
      )}
    </form>
  );
}
