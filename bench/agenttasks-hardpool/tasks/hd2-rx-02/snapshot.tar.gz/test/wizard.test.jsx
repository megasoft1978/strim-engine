import { test, expect, describe } from 'bun:test';
import { renderToStaticMarkup } from 'react-dom/server';
import { validateStep, validateAll } from '../src/validators.js';
import { crossFieldErrors } from '../src/rules.js';
import { initialState, wizardReducer } from '../src/wizardReducer.js';
import { Field } from '../src/Field.jsx';
import { ErrorSummary } from '../src/ErrorSummary.jsx';
import { Summary } from '../src/Summary.jsx';
import { Wizard } from '../src/Wizard.jsx';

const run = (state, ...actions) => actions.reduce(wizardReducer, state);
const set = (field, value) => ({ type: 'change', field, value });
const fill = (state, values) => Object.entries(values).reduce((s, [k, v]) => wizardReducer(s, set(k, v)), state);
const GOOD_ACCOUNT = { email: 'ann@example.com', password: 'secret123', confirm: 'secret123' };
const GOOD_PROFILE = { name: 'Ann', age: '30' };
const at = (step, values) => ({ ...initialState, step, furthest: step, values });
const html = (el) => renderToStaticMarkup(el);

describe('account rules', () => {
  test('email is trimmed, required and shaped', () => {
    expect(validateStep('account', { ...GOOD_ACCOUNT, email: '' }).email).toBe('Email is required');
    expect(validateStep('account', { ...GOOD_ACCOUNT, email: '   ' }).email).toBe('Email is required');
    expect(validateStep('account', { ...GOOD_ACCOUNT, email: 'ann@example' }).email).toBe('Enter a valid email');
    expect(validateStep('account', { ...GOOD_ACCOUNT, email: ' ann@example.com ' })).toEqual({});
  });

  test('password rules report one message, shortest rule first', () => {
    const v = (password) => validateStep('account', { ...GOOD_ACCOUNT, password, confirm: password }).password;
    expect(v('')).toBe('Password is required');
    expect(v('abc')).toBe('At least 8 characters');
    expect(v('abcdefgh')).toBe('Include a digit');
    expect(v('abcdefg1')).toBeUndefined();
    expect(v('        ')).toBe('Include a digit');
  });

  test('confirm is required, then compared exactly', () => {
    expect(validateStep('account', { ...GOOD_ACCOUNT, confirm: '' }).confirm).toBe('Confirm your password');
    expect(validateStep('account', { ...GOOD_ACCOUNT, confirm: 'secret124' }).confirm).toBe('Passwords do not match');
    expect(validateStep('account', { ...GOOD_ACCOUNT, confirm: 'secret123 ' }).confirm).toBe('Passwords do not match');
    expect(validateStep('account', GOOD_ACCOUNT)).toEqual({});
  });

  test('cross-field rules never overwrite a field error', () => {
    expect(crossFieldErrors('account', { password: 'x', confirm: 'y' }, { confirm: 'taken' })).toEqual({});
    expect(crossFieldErrors('account', { password: 'x', confirm: 'y' }, {})).toEqual({ confirm: 'Passwords do not match' });
  });
});

describe('profile rules', () => {
  test('name is trimmed and capped', () => {
    expect(validateStep('profile', { name: '  ', age: '30' }).name).toBe('Name is required');
    expect(validateStep('profile', { name: 'x'.repeat(41), age: '30' }).name).toBe('Name is too long');
    expect(validateStep('profile', { name: 'x'.repeat(40), age: '30' })).toEqual({});
  });

  test('age must be a whole number within bounds', () => {
    const age = (v) => validateStep('profile', { name: 'Ann', age: v }).age;
    expect(age('')).toBe('Age is required');
    for (const bad of ['12', '121', '12.5', '-20', '1e1', 'abc']) expect(age(bad)).toBe('Age must be between 13 and 120');
    for (const ok of ['13', '120', ' 45 ']) expect(age(ok)).toBeUndefined();
  });
});

describe('plan rules', () => {
  const plan = (extra) => validateStep('plan', { age: '30', ...extra });

  test('plan is required and must be known', () => {
    expect(plan({})).toEqual({ plan: 'Choose a plan' });
    expect(plan({ plan: 'gold' })).toEqual({ plan: 'Choose a plan' });
    expect(plan({ plan: 'free' })).toEqual({});
  });

  test('seats are only checked for the team plan', () => {
    expect(plan({ plan: 'team' })).toEqual({ seats: 'Seats are required' });
    expect(plan({ plan: 'team', seats: '1' }).seats).toBe('Seats must be between 2 and 50');
    expect(plan({ plan: 'team', seats: '51' }).seats).toBe('Seats must be between 2 and 50');
    expect(plan({ plan: 'team', seats: '2.5' }).seats).toBe('Seats must be between 2 and 50');
    expect(plan({ plan: 'team', seats: '50' })).toEqual({});
    expect(plan({ plan: 'pro', seats: '1' })).toEqual({});
  });

  test('team needs an adult, but only when the age is usable', () => {
    expect(plan({ plan: 'team', seats: '3', age: '17' })).toEqual({ plan: 'Team plan requires age 18 or over' });
    expect(plan({ plan: 'team', seats: '3', age: '18' })).toEqual({});
    expect(plan({ plan: 'team', seats: '3', age: 'abc' })).toEqual({});
    expect(plan({ plan: 'team', seats: '3', age: '' })).toEqual({});
  });

  test('coupons depend on the plan', () => {
    expect(plan({ plan: 'free', coupon: 'SAVE10' })).toEqual({ coupon: 'Coupons need a paid plan' });
    expect(plan({ plan: 'pro', coupon: ' save10 ' })).toEqual({});
    expect(plan({ plan: 'pro', coupon: 'NOPE' })).toEqual({ coupon: 'Unknown coupon' });
    expect(plan({ plan: 'pro', coupon: 'team20' })).toEqual({ coupon: 'Coupon not valid for this plan' });
    expect(plan({ plan: 'team', seats: '4', coupon: 'TEAM20' })).toEqual({});
    expect(plan({ coupon: 'NOPE' })).toEqual({ plan: 'Choose a plan' });
  });

  test('summary has no rules and validateAll finds the first bad step', () => {
    expect(validateStep('summary', {})).toEqual({});
    expect(validateAll({ ...GOOD_ACCOUNT, ...GOOD_PROFILE, plan: 'pro' })).toBeNull();
    const bad = validateAll({ ...GOOD_ACCOUNT, name: 'Ann', age: '9', plan: 'team', seats: '1' });
    expect(bad.step).toBe(1);
    expect(bad.errors).toEqual({ age: 'Age must be between 13 and 120' });
  });
});

describe('reducer', () => {
  test('next with errors stays and stores them; change clears only that field', () => {
    let s = run(initialState, { type: 'next' });
    expect(s.step).toBe(0);
    expect(Object.keys(s.errors)).toEqual(['email', 'password', 'confirm']);
    s = run(s, set('email', 'a@b.co'));
    expect(Object.keys(s.errors)).toEqual(['password', 'confirm']);
    expect(s.values.email).toBe('a@b.co');
  });

  test('valid next advances, clears errors and tracks the furthest step', () => {
    let s = run(initialState, { type: 'next' });
    s = fill(s, GOOD_ACCOUNT);
    s = run(s, { type: 'next' });
    expect(s).toMatchObject({ step: 1, furthest: 1, errors: {} });
  });

  test('back keeps values and clears errors; not below the first step', () => {
    let s = fill(initialState, GOOD_ACCOUNT);
    s = run(s, { type: 'next' }, { type: 'next' });
    expect(Object.keys(s.errors)).toEqual(['name', 'age']);
    s = run(s, { type: 'back' });
    expect(s).toMatchObject({ step: 0, furthest: 1, errors: {} });
    expect(s.values.email).toBe('ann@example.com');
    expect(run(s, { type: 'back' })).toBe(s);
  });

  test('goto reaches visited steps only', () => {
    let s = run(fill(initialState, GOOD_ACCOUNT), { type: 'next' }, { type: 'back' });
    expect(run(s, { type: 'goto', step: 0 })).toBe(s);
    expect(run(s, { type: 'goto', step: 2 })).toBe(s);
    expect(run(s, { type: 'goto', step: -1 })).toBe(s);
    expect(run(s, { type: 'goto', step: 1 }).step).toBe(1);
  });

  test('next on the summary step does nothing; unknown actions return the same state', () => {
    const s = at(3, { ...GOOD_ACCOUNT, ...GOOD_PROFILE, plan: 'pro' });
    expect(run(s, { type: 'next' })).toBe(s);
    expect(run(s, { type: 'bogus' })).toBe(s);
  });

  test('submit is only for the summary step', () => {
    const s = at(2, { ...GOOD_ACCOUNT, ...GOOD_PROFILE, plan: 'pro' });
    expect(run(s, { type: 'submit' })).toBe(s);
    expect(run(at(3, s.values), { type: 'submit' }).done).toBe(true);
  });

  test('submit with a stale invalid earlier step jumps back to it', () => {
    let s = fill(at(3, { ...GOOD_ACCOUNT, ...GOOD_PROFILE, plan: 'pro' }), { confirm: 'different' });
    s = run(s, { type: 'submit' });
    expect(s).toMatchObject({ step: 0, done: false, errors: { confirm: 'Passwords do not match' } });
  });

  test('changing the plan away from team hides seat errors on submit', () => {
    let s = at(3, { ...GOOD_ACCOUNT, ...GOOD_PROFILE, plan: 'team', seats: '1' });
    expect(run(s, { type: 'submit' }).step).toBe(2);
    s = fill(s, { plan: 'pro' });
    expect(run(s, { type: 'submit' }).done).toBe(true);
  });

  test('after done only restart is accepted', () => {
    const s = run(at(3, { ...GOOD_ACCOUNT, ...GOOD_PROFILE, plan: 'pro' }), { type: 'submit' });
    expect(run(s, { type: 'back' })).toBe(s);
    expect(run(s, set('name', 'Bob'))).toBe(s);
    expect(run(s, { type: 'restart' })).toEqual(initialState);
  });
});

describe('Field', () => {
  const email = { name: 'email', label: 'Email', type: 'email', hint: 'We never share it' };

  test('label, input and hint wiring without an error', () => {
    const out = html(<Field field={email} value="a@b.co" />);
    expect(out).toContain('<label for="field-email">Email</label>');
    expect(out).toContain('id="field-email"');
    expect(out).toContain('value="a@b.co"');
    expect(out).toContain('aria-describedby="field-email-hint"');
    expect(out).toContain('<p id="field-email-hint" class="hint">We never share it</p>');
    expect(out).not.toContain('aria-invalid');
    expect(out).not.toContain('field-email-error');
  });

  test('an error adds aria-invalid and is described after the hint', () => {
    const out = html(<Field field={email} value="" error="Email is required" />);
    expect(out).toContain('aria-invalid="true"');
    expect(out).toContain('aria-describedby="field-email-hint field-email-error"');
    expect(out).toContain('<p id="field-email-error" class="error">Email is required</p>');
  });

  test('a field without hint or error has no aria-describedby', () => {
    const out = html(<Field field={{ name: 'age', label: 'Age', type: 'number' }} />);
    expect(out).not.toContain('aria-describedby');
    expect(out).toContain('value=""');
  });

  test('error without hint is described by the error alone', () => {
    const out = html(<Field field={{ name: 'age', label: 'Age', type: 'number' }} error="Age is required" />);
    expect(out).toContain('aria-describedby="field-age-error"');
  });

  test('select lists the plans after an empty choice', () => {
    const out = html(<Field field={{ name: 'plan', label: 'Plan', type: 'select' }} value="pro" />);
    expect(out).toContain('<select');
    expect(out.indexOf('Choose...')).toBeLessThan(out.indexOf('>Free<'));
    expect(out).toContain('<option value="pro" selected="">Pro</option>');
    expect(out).toContain('<option value="team">Team</option>');
  });
});

describe('ErrorSummary', () => {
  test('renders nothing without errors', () => {
    expect(html(<ErrorSummary errors={{}} />)).toBe('');
  });

  test('is an assertive live region listing links in field order', () => {
    const out = html(<ErrorSummary errors={{ confirm: 'Passwords do not match', email: 'Email is required' }} />);
    expect(out).toContain('id="error-summary"');
    expect(out).toContain('role="alert"');
    expect(out).toContain('aria-live="assertive"');
    expect(out).toContain('tabindex="-1"');
    expect(out).toContain('There is a problem');
    expect(out.indexOf('#field-email')).toBeGreaterThan(-1);
    expect(out.indexOf('#field-email')).toBeLessThan(out.indexOf('#field-confirm'));
    expect(out).toContain('<a href="#field-confirm">Passwords do not match</a>');
  });
});

describe('Summary', () => {
  const values = { email: ' ann@example.com ', name: ' Ann ', age: '30', plan: 'team', seats: '5', coupon: ' team20 ', password: 'secret123' };

  test('rows in order with masked password', () => {
    const out = html(<Summary values={values} />);
    const labels = [...out.matchAll(/<dt>([^<]*)<\/dt>/g)].map((m) => m[1]);
    expect(labels).toEqual(['Email', 'Name', 'Age', 'Plan', 'Seats', 'Coupon', 'Password']);
    expect(out).toContain('<dd>ann@example.com</dd>');
    expect(out).toContain('<dd>Team</dd>');
    expect(out).toContain('<dd>TEAM20</dd>');
    expect(out).toContain('<dd>•••••••••</dd>');
    expect(out).not.toContain('secret123');
    expect(out).toContain('aria-label="Summary"');
  });

  test('seats and coupon are left out when they do not apply', () => {
    const pro = html(<Summary values={{ ...values, plan: 'pro', coupon: '' }} />);
    expect(pro).not.toContain('Seats');
    expect(pro).not.toContain('Coupon');
    const free = html(<Summary values={{ ...values, plan: 'free' }} />);
    expect(free).not.toContain('Coupon');
    expect(free).not.toContain('TEAM20');
  });
});

describe('Wizard', () => {
  test('progress list marks done, current and todo', () => {
    const out = html(<Wizard state={at(1, {})} />);
    expect(out).toContain('<li data-state="done">Account</li>');
    expect(out).toContain('<li aria-current="step" data-state="current">Profile</li>');
    expect(out).toContain('<li data-state="todo">Plan</li>');
  });

  test('first step has no Back; later steps do; labels change on the last input step', () => {
    expect(html(<Wizard state={initialState} />)).not.toContain('data-action="back"');
    const mid = html(<Wizard state={at(1, {})} />);
    expect(mid).toContain('data-action="back"');
    expect(mid).toContain('data-action="next">Next<');
    expect(html(<Wizard state={at(2, {})} />)).toContain('data-action="next">Review<');
    expect(html(<Wizard state={at(3, {})} />)).toContain('data-action="submit">Submit<');
  });

  test('seats appear only for the team plan', () => {
    expect(html(<Wizard state={at(2, { plan: 'pro' })} />)).not.toContain('field-seats');
    expect(html(<Wizard state={at(2, { plan: 'team' })} />)).toContain('id="field-seats"');
  });

  test('errors show in the summary and next to the fields', () => {
    const s = run(initialState, { type: 'next' });
    const out = html(<Wizard state={s} />);
    expect(out).toContain('role="alert"');
    expect(out).toContain('<a href="#field-email">Email is required</a>');
    expect(out).toContain('<p id="field-email-error" class="error">Email is required</p>');
    expect(out).toContain('aria-invalid="true"');
  });

  test('preserved values come back when stepping back', () => {
    let s = run(fill(initialState, GOOD_ACCOUNT), { type: 'next' }, { type: 'back' });
    const out = html(<Wizard state={s} />);
    expect(out).toContain('value="ann@example.com"');
    expect(out).toContain('value="secret123"');
  });

  test('summary step shows the review; done shows a thank-you status', () => {
    const values = { ...GOOD_ACCOUNT, ...GOOD_PROFILE, plan: 'pro' };
    expect(html(<Wizard state={at(3, values)} />)).toContain('<dt>Plan</dt><dd>Pro</dd>');
    const done = html(<Wizard state={run(at(3, values), { type: 'submit' })} />);
    expect(done).toContain('<p role="status">Thanks, Ann! Your Pro plan is ready.</p>');
    expect(done).not.toContain('data-action');
  });
});
