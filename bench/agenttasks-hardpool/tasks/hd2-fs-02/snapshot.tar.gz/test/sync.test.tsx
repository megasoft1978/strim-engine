import { describe, expect, test } from 'bun:test';
import { renderToStaticMarkup } from 'react-dom/server';
import { createApi, type Transport } from '../src/client/api.ts';
import { ItemList } from '../src/client/ItemList.tsx';
import { applyOptimistic, dismissBanner, initialState, ItemStore, rejectOp, resolveOp } from '../src/client/store.ts';
import { handle } from '../src/server/handler.ts';
import type { ItemDb } from '../src/server/patch.ts';
import type { HttpRequest, Item } from '../src/shared/types.ts';

const seed = (): Item[] => [
  { id: 'a', title: 'Write docs', done: false, version: 1 },
  { id: 'b', title: 'Ship it', done: true, version: 4 },
];
const mkDb = (): ItemDb => new Map(seed().map((i) => [i.id, i]));
const patch = (db: ItemDb, id: string, headers: Record<string, string>, body: unknown) =>
  handle({ method: 'PATCH', path: `/items/${id}`, headers, body }, db);

describe('server PATCH', () => {
  test('success stores the change, bumps the version and sets the ETag', () => {
    const db = mkDb();
    const res = patch(db, 'a', { 'if-match': '"1"' }, { title: '  Write more docs  ', done: true });
    expect(res.status).toBe(200);
    expect(res.headers.etag).toBe('"2"');
    expect(res.body).toEqual({ id: 'a', title: 'Write more docs', done: true, version: 2 });
    expect(db.get('a')?.version).toBe(2);
    expect(handle({ method: 'GET', path: '/items/a', headers: {} }, db).headers.etag).toBe('"2"');
  });

  test('unknown id is 404 even without If-Match', () => {
    expect(patch(mkDb(), 'zz', {}, { done: true }).status).toBe(404);
  });

  test('missing If-Match is 428 and changes nothing', () => {
    const db = mkDb();
    const res = patch(db, 'a', {}, { done: true });
    expect(res.status).toBe(428);
    expect((res.body as any).error.code).toBe('precondition_required');
    expect(db.get('a')?.done).toBe(false);
  });

  test('stale If-Match is 412 and returns the current item', () => {
    const db = mkDb();
    const res = patch(db, 'b', { 'if-match': '"3"' }, { done: false });
    expect(res.status).toBe(412);
    expect((res.body as any).error.code).toBe('version_conflict');
    expect((res.body as any).error.current).toEqual({ id: 'b', title: 'Ship it', done: true, version: 4 });
    expect(db.get('b')?.version).toBe(4);
  });

  test('If-Match accepts a list or a wildcard', () => {
    expect(patch(mkDb(), 'b', { 'if-match': '"1", "4"' }, { done: false }).status).toBe(200);
    expect(patch(mkDb(), 'b', { 'if-match': '*' }, { done: false }).status).toBe(200);
    expect(patch(mkDb(), 'b', { 'if-match': '"1","2"' }, { done: false }).status).toBe(412);
  });

  test('invalid patches are 422 and are reported before a version conflict', () => {
    const bad: unknown[] = [null, [], {}, { color: 'red' }, { done: true, extra: 1 }, { title: '   ' }, { title: 5 }, { title: 'x'.repeat(41) }, { done: 'yes' }];
    for (const body of bad) {
      const res = patch(mkDb(), 'a', { 'if-match': '"99"' }, body);
      expect([res.status, (res.body as any).error.code]).toEqual([422, 'invalid_patch']);
    }
    expect(patch(mkDb(), 'a', { 'if-match': '"1"' }, { title: ' ' + 'x'.repeat(40) + ' ' }).status).toBe(200);
  });

  test('a patch that changes nothing keeps the version', () => {
    const db = mkDb();
    const res = patch(db, 'a', { 'if-match': '"1"' }, { title: ' Write docs ', done: false });
    expect(res.status).toBe(200);
    expect(res.headers.etag).toBe('"1"');
    expect((res.body as Item).version).toBe(1);
    expect(db.get('a')?.version).toBe(1);
  });
});

describe('pure state transitions', () => {
  test('applyOptimistic shows the change without touching the version', () => {
    const s0 = { ...initialState(seed()), banner: 'old' };
    const s1 = applyOptimistic(s0, 'op1', 'a', { title: ' New ', done: true });
    expect(s1.items[0]).toEqual({ id: 'a', title: 'New', done: true, version: 1 });
    expect(s1.items[1]).toBe(s0.items[1]);
    expect(s1.pending).toEqual([{ opId: 'op1', id: 'a', patch: { title: ' New ', done: true }, prev: s0.items[0] }]);
    expect(s1.banner).toBe(null);
    expect(applyOptimistic(s0, 'op2', 'nope', { done: true })).toBe(s0);
  });

  test('resolveOp adopts the server copy and drops the op', () => {
    const s1 = applyOptimistic(initialState(seed()), 'op1', 'a', { done: true });
    const s2 = resolveOp(s1, 'op1', { id: 'a', title: 'Write docs', done: true, version: 2 });
    expect(s2.items[0]).toEqual({ id: 'a', title: 'Write docs', done: true, version: 2 });
    expect(s2.pending).toEqual([]);
    expect(resolveOp(s2, 'op1', s2.items[0])).toBe(s2);
  });

  test('rejectOp rolls back and shows the message', () => {
    const s1 = applyOptimistic(initialState(seed()), 'op1', 'a', { title: 'Oops' });
    const s2 = rejectOp(s1, 'op1', { code: 'invalid_patch', message: 'Title must be 1-40 characters' });
    expect(s2.items[0]).toEqual(seed()[0]);
    expect(s2.pending).toEqual([]);
    expect(s2.banner).toBe('Title must be 1-40 characters');
    expect(rejectOp(s2, 'op1', { code: 'x', message: 'y' })).toBe(s2);
  });

  test('rejectOp on a conflict adopts the server copy', () => {
    const s1 = applyOptimistic(initialState(seed()), 'op1', 'b', { done: false });
    const current = { id: 'b', title: 'Ship it today', done: true, version: 5 };
    const s2 = rejectOp(s1, 'op1', { code: 'version_conflict', message: 'changed', current });
    expect(s2.items[1]).toEqual(current);
    expect(s2.banner).toBe('Conflict: "Ship it today" was changed elsewhere. Showing the latest version.');
    expect(dismissBanner(s2).banner).toBe(null);
  });
});

function harness(db = mkDb()) {
  const requests: HttpRequest[] = [];
  let release: (() => void) | null = null;
  let hold = false;
  let fail = false;
  const transport: Transport = async (req) => {
    requests.push(req);
    if (fail) throw new Error('offline');
    if (hold) await new Promise<void>((r) => (release = r));
    return handle(req, db);
  };
  let n = 0;
  const store = new ItemStore(createApi(transport), () => `op${++n}`, seed());
  return {
    db, store, requests,
    hold: () => (hold = true),
    fail: () => (fail = true),
    release: () => release?.(),
  };
}

describe('store end to end', () => {
  test('the change is visible while the request is in flight, then confirmed', async () => {
    const h = harness();
    h.hold();
    const p = h.store.edit('a', { done: true });
    expect(renderToStaticMarkup(<ItemList state={h.store.state} />)).toContain(
      '<li data-id="a" data-pending="true" class="item done"><span class="title">Write docs</span><small>v1</small></li>',
    );
    expect(h.requests[0].headers['if-match']).toBe('"1"');
    h.release();
    await p;
    expect(renderToStaticMarkup(<ItemList state={h.store.state} />)).toContain(
      '<li data-id="a" data-pending="false" class="item done"><span class="title">Write docs</span><small>v2</small></li>',
    );
  });

  test('a conflict shows the latest server copy and a banner', async () => {
    const h = harness();
    h.db.set('a', { id: 'a', title: 'Write the docs', done: false, version: 3 });
    await h.store.edit('a', { done: true });
    expect(h.store.state.items[0]).toEqual({ id: 'a', title: 'Write the docs', done: false, version: 3 });
    const html = renderToStaticMarkup(<ItemList state={h.store.state} />);
    expect(html).toContain('<div role="alert" class="banner">Conflict: &quot;Write the docs&quot; was changed elsewhere. Showing the latest version.</div>');
    expect(html).toContain('data-pending="false"');
  });

  test('a rejected patch rolls back with the server message', async () => {
    const h = harness();
    await h.store.edit('a', { title: '   ' });
    expect(h.store.state.items[0]).toEqual(seed()[0]);
    expect(h.store.state.banner).toBe('Title must be 1-40 characters');
    expect(h.db.get('a')?.version).toBe(1);
  });

  test('a network failure rolls back', async () => {
    const h = harness();
    h.fail();
    await h.store.edit('b', { done: false });
    expect(h.store.state.items[1]).toEqual(seed()[1]);
    expect(h.store.state.banner).toBe('Network error');
    expect(h.store.state.pending).toEqual([]);
  });

  test('a second edit of an item that is still saving is refused', async () => {
    const h = harness();
    h.hold();
    const first = h.store.edit('a', { title: 'First' });
    await h.store.edit('a', { title: 'Second' });
    expect(h.requests.length).toBe(1);
    expect(h.store.state.banner).toBe('"First" is still saving.');
    expect(h.store.state.items[0].title).toBe('First');
    h.release();
    await first;
    expect(h.store.state.items[0]).toEqual({ id: 'a', title: 'First', done: false, version: 2 });
  });

  test('other items can be edited while one is saving, and a new edit clears the banner', async () => {
    const h = harness();
    h.store.state = { ...h.store.state, banner: 'stale message' };
    await h.store.edit('a', { done: true });
    await h.store.edit('b', { title: 'Shipped' });
    expect(h.store.state.banner).toBe(null);
    expect(h.store.state.items.map((i) => i.version)).toEqual([2, 5]);
    await h.store.edit('missing', { done: true });
    expect(h.requests.length).toBe(2);
  });
});
