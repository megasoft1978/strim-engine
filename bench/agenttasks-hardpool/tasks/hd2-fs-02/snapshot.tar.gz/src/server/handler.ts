import type { HttpRequest, HttpResponse } from '../shared/types.ts';
import { fail, ok } from './etag.ts';
import { patchItem, type ItemDb } from './patch.ts';

export function handle(req: HttpRequest, db: ItemDb): HttpResponse {
  if (req.path === '/items' && req.method === 'GET') {
    return { status: 200, headers: {}, body: [...db.values()] };
  }
  const m = /^\/items\/([^/]+)$/.exec(req.path);
  if (m) {
    if (req.method === 'GET') {
      const item = db.get(m[1]);
      return item ? ok(item) : fail(404, 'not_found', `Item ${m[1]} not found`);
    }
    if (req.method === 'PATCH') return patchItem(db, m[1], req);
    return fail(405, 'method_not_allowed', `Method ${req.method} not allowed`);
  }
  return fail(404, 'not_found', `No route for ${req.path}`);
}
