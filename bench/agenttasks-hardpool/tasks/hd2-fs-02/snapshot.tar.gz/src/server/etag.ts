import type { HttpResponse, Item } from '../shared/types.ts';

/** Strong ETag of the current item state: the version in double quotes. */
export function etagOf(item: Item): string {
  return `"${item.version}"`;
}

export function ok(item: Item): HttpResponse {
  return { status: 200, headers: { etag: etagOf(item) }, body: item };
}

export function fail(status: number, code: string, message: string, current?: Item): HttpResponse {
  const error: Record<string, unknown> = { code, message };
  if (current) error.current = current;
  return { status, headers: {}, body: { error } };
}
