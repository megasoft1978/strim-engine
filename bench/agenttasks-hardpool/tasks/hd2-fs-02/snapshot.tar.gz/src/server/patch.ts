import type { HttpRequest, HttpResponse, Item } from '../shared/types.ts';
import { etagOf, fail, ok } from './etag.ts';

export type ItemDb = Map<string, Item>;

const MAX_TITLE = 40;

/**
 * PATCH /items/:id with conditional-update semantics. Checks run in this order:
 *  1. unknown id                       -> 404 not_found
 *  2. no If-Match header               -> 428 precondition_required
 *  3. invalid patch                    -> 422 invalid_patch. A patch is valid when it is an object with
 *     at least one key, only the keys "title" and "done", `title` a string that is non-empty after
 *     trimming and at most 40 characters after trimming, and `done` a boolean.
 *  4. If-Match does not match          -> 412 version_conflict, error.current = the stored item.
 *     If-Match is "*" (matches any version) or a comma-separated list of ETags; it matches when any
 *     listed ETag equals etagOf(stored item). Whitespace around entries is ignored.
 *  5. patch changes nothing (after trimming the title, every given field equals the stored value)
 *                                      -> 200 with the stored item, version NOT bumped
 *  6. otherwise store the trimmed fields, bump version by 1 -> 200 with the new item and its new ETag.
 */
export function patchItem(db: ItemDb, id: string, req: HttpRequest): HttpResponse {
  return fail(501, 'not_implemented', 'PATCH is not implemented');
}
