import { parseApiError, parseItem, parseItems, SchemaError } from '../shared/schema.ts';
import type { ApiErrorBody, HttpRequest, HttpResponse, Item, ItemPatch } from '../shared/types.ts';

export type Transport = (req: HttpRequest) => Promise<HttpResponse>;
export type Result<T> = { ok: true; value: T } | { ok: false; error: ApiErrorBody };

async function call<T>(transport: Transport, req: HttpRequest, parse: (v: unknown) => T): Promise<Result<T>> {
  const res = await transport(req);
  try {
    if (res.status >= 200 && res.status < 300) return { ok: true, value: parse(res.body) };
    return { ok: false, error: parseApiError(res.body) };
  } catch (e) {
    if (e instanceof SchemaError) return { ok: false, error: { code: 'bad_response', message: e.message } };
    throw e;
  }
}

export function createApi(transport: Transport) {
  return {
    listItems: () => call(transport, { method: 'GET', path: '/items', headers: {} }, parseItems),
    /** Sends If-Match with the ETag for `version` (the version in double quotes). */
    patchItem: (id: string, patch: ItemPatch, version: number): Promise<Result<Item>> =>
      call(transport, { method: 'PATCH', path: `/items/${id}`, headers: { 'if-match': `"${version}"` }, body: patch }, parseItem),
  };
}

export type Api = ReturnType<typeof createApi>;
