import type { ApiErrorBody, Item, ItemPatch } from '../shared/types.ts';
import type { Api } from './api.ts';

export interface PendingOp {
  opId: string;
  id: string;
  patch: ItemPatch;
  /** The item exactly as it was before the optimistic change. */
  prev: Item;
}

export interface State {
  items: Item[];
  pending: PendingOp[];
  banner: string | null;
}

export function initialState(items: Item[]): State {
  return { items, pending: [], banner: null };
}

export function dismissBanner(state: State): State {
  return { ...state, banner: null };
}

/**
 * Show `patch` on the item right away. The title is trimmed; the version is NOT changed (only the
 * server bumps versions). Records a PendingOp holding the previous item and clears any banner.
 * An unknown id returns `state` itself.
 */
export function applyOptimistic(state: State, opId: string, id: string, patch: ItemPatch): State {
  return state;
}

/** Server accepted the op: the item becomes `saved` (server copy, new version) and the op is dropped. Unknown opId returns `state` itself. */
export function resolveOp(state: State, opId: string, saved: Item): State {
  return state;
}

/**
 * Server (or network) rejected the op. The op is dropped and
 *  - code "version_conflict" with error.current: the item becomes error.current and the banner is
 *    `Conflict: "<current title>" was changed elsewhere. Showing the latest version.`
 *  - anything else: the item is rolled back to op.prev and the banner is error.message.
 * Unknown opId returns `state` itself.
 */
export function rejectOp(state: State, opId: string, error: ApiErrorBody): State {
  return state;
}

export class ItemStore {
  state: State;
  constructor(private api: Api, private nextOpId: () => string, items: Item[]) {
    this.state = initialState(items);
  }

  /**
   * Optimistic edit. Unknown id: do nothing. If the item already has a pending op: send nothing and
   * set the banner to `"<title>" is still saving.` (title as currently shown). Otherwise: take an op id
   * from nextOpId(), applyOptimistic synchronously (before any await), send api.patchItem with the
   * item's version from before the change, then resolveOp on success or rejectOp on an error. If the
   * transport throws, treat it as { code: "network", message: "Network error" }.
   */
  async edit(id: string, patch: ItemPatch): Promise<void> {
    void id; void patch; void this.api; void this.nextOpId;
  }
}
