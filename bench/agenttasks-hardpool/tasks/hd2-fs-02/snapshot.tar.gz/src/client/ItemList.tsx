import type { State } from './store.ts';

export function ItemList({ state }: { state: State }) {
  const saving = new Set(state.pending.map((op) => op.id));
  return (
    <div className="items">
      {state.banner !== null && <div role="alert" className="banner">{state.banner}</div>}
      <ul>
        {state.items.map((item) => (
          <li key={item.id} data-id={item.id} data-pending={saving.has(item.id) ? 'true' : 'false'} className={item.done ? 'item done' : 'item'}>
            <span className="title">{item.title}</span>
            <small>v{item.version}</small>
          </li>
        ))}
      </ul>
    </div>
  );
}
