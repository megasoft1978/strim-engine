// Wire contract shared by the server and the client.
//
// Concurrency model: every Item carries a `version` that starts at 1 and grows by one on each
// effective change. The server exposes it as a strong ETag (the version in double quotes, e.g. "3")
// on every single-item response, and PATCH requests must echo it back in `If-Match`.

export interface Item {
  id: string;
  title: string;
  done: boolean;
  version: number;
}

/** Fields a client may change. At least one must be present. */
export interface ItemPatch {
  title?: string;
  done?: boolean;
}

export interface ApiErrorBody {
  code: string;
  message: string;
  /** Only on 412 version_conflict: the server's current copy of the item. */
  current?: Item;
}

export interface HttpRequest {
  method: string;
  path: string;
  /** Lower-case header names. */
  headers: Record<string, string>;
  body?: unknown;
}

export interface HttpResponse {
  status: number;
  /** Lower-case header names. */
  headers: Record<string, string>;
  body: unknown;
}
