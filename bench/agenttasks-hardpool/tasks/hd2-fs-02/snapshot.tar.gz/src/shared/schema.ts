import type { ApiErrorBody, Item } from './types.ts';

export class SchemaError extends Error {}

function obj(v: unknown, where: string): Record<string, unknown> {
  if (typeof v !== 'object' || v === null || Array.isArray(v)) throw new SchemaError(`${where}: expected object`);
  return v as Record<string, unknown>;
}

export function parseItem(v: unknown): Item {
  const o = obj(v, 'item');
  if (typeof o.id !== 'string') throw new SchemaError('item.id: expected string');
  if (typeof o.title !== 'string') throw new SchemaError('item.title: expected string');
  if (typeof o.done !== 'boolean') throw new SchemaError('item.done: expected boolean');
  if (typeof o.version !== 'number' || !Number.isInteger(o.version) || o.version < 1) {
    throw new SchemaError('item.version: expected positive integer');
  }
  return { id: o.id, title: o.title, done: o.done, version: o.version };
}

export function parseItems(v: unknown): Item[] {
  if (!Array.isArray(v)) throw new SchemaError('items: expected array');
  return v.map(parseItem);
}

export function parseApiError(v: unknown): ApiErrorBody {
  const e = obj(obj(v, 'body').error, 'error');
  if (typeof e.code !== 'string' || typeof e.message !== 'string') throw new SchemaError('error: code and message are strings');
  const out: ApiErrorBody = { code: e.code, message: e.message };
  if (e.current !== undefined) out.current = parseItem(e.current);
  return out;
}
