import { test } from "node:test";
import assert from "node:assert/strict";
import { compile, ParseError } from "../src/index.ts";
import type { Rec } from "../src/index.ts";

const people: Rec[] = [
  { id: 1, name: "Alice Smith", age: 34, status: "open", tags: ["red", "Blue"], owner: { name: "bob", team: "core" } },
  { id: 2, name: "Bob", age: 29, status: "closed", tags: ["green"], owner: { name: "alice" } },
  { id: 3, name: "Carol and Dave", age: 41, status: "pending", tags: [], active: true },
  { id: 4, name: 'He said "hi"', status: "open", tags: ["red"], score: "9" },
];

const ids = (q: string): number[] => people.filter(compile(q)).map((r) => r.id as number);

test("empty or blank query matches everything", () => {
  assert.deepEqual(ids(""), [1, 2, 3, 4]);
  assert.deepEqual(ids("   "), [1, 2, 3, 4]);
});

test("field:value is a case-insensitive equality on strings, numbers and booleans", () => {
  assert.deepEqual(ids("status:OPEN"), [1, 4]);
  assert.deepEqual(ids("age:29"), [2]);
  assert.deepEqual(ids("active:true"), [3]);
});

test("array fields match when any element matches", () => {
  assert.deepEqual(ids("tags:blue"), [1]);
  assert.deepEqual(ids("tags:red"), [1, 4]);
});

test("dotted paths reach into nested objects; missing paths never match", () => {
  assert.deepEqual(ids("owner.name:bob"), [1]);
  assert.deepEqual(ids("owner.team:core"), [1]);
  assert.deepEqual(ids("owner.name.first:bob"), []);
});

test("comma lists mean any-of", () => {
  assert.deepEqual(ids("status:closed,pending"), [2, 3]);
  assert.deepEqual(ids("status!=closed,pending"), [1, 4]);
});

test("numeric comparisons only apply to numbers; missing or non-numeric values are false", () => {
  assert.deepEqual(ids("age>=34"), [1, 3]);
  assert.deepEqual(ids("age<34"), [2]);
  assert.deepEqual(ids("age>29 age<41"), [1]);
  assert.deepEqual(ids("score<10"), []);
  assert.deepEqual(ids("age>abc"), []);
});

test("!= is true for missing fields", () => {
  assert.deepEqual(ids("age!=34"), [2, 3, 4]);
  assert.deepEqual(ids("nothing!=x"), [1, 2, 3, 4]);
});

test("bare words search every top-level string value, case-insensitively, by substring", () => {
  assert.deepEqual(ids("smith"), [1]);
  assert.deepEqual(ids("RED"), [1, 4]);
  assert.deepEqual(ids("core"), []); // nested values are not searched
});

test("not binds tighter than and, and binds tighter than or", () => {
  assert.deepEqual(ids("status:open or status:closed and age>30"), [1, 4]);
  assert.deepEqual(ids("not status:open and age>30"), [3]);
  assert.deepEqual(ids("not not status:open"), [1, 4]);
});

test("adjacent terms are an implicit and, and parentheses override precedence", () => {
  assert.deepEqual(ids("status:open tags:red"), [1, 4]);
  assert.deepEqual(ids("(status:open or status:closed) age>30"), [1]);
  assert.deepEqual(ids("not (status:open or status:closed)"), [3]);
});

test("keywords are case-insensitive unless quoted", () => {
  assert.deepEqual(ids("status:open AND age>30"), [1]);
  assert.deepEqual(ids("NOT status:open"), [2, 3]);
  assert.deepEqual(ids('"and"'), [3]);
  assert.deepEqual(ids('name:"carol and dave"'), [3]);
});

test("quoted values keep spaces and support escapes", () => {
  assert.deepEqual(ids('name:"alice smith"'), [1]);
  assert.deepEqual(ids('name:"He said \\"hi\\""'), [4]);
});

function errorOf(q: string): ParseError {
  try {
    compile(q);
  } catch (e) {
    assert.ok(e instanceof ParseError, `expected ParseError for ${q}`);
    return e;
  }
  assert.fail(`expected ${q} to throw`);
}

test("syntax errors throw ParseError with the offending position", () => {
  assert.equal(errorOf("(a or b").pos, 0);
  assert.equal(errorOf("a or b)").pos, 6);
  assert.equal(errorOf("status:").pos, 7);
  assert.equal(errorOf("a and").pos, 5);
  assert.equal(errorOf("a or or b").pos, 5);
  assert.equal(errorOf('name:"abc').pos, 5);
  assert.equal(errorOf("age>1,2").pos, 4);
});
