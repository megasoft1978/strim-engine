import { evaluate } from "./evaluate.ts";
import { parse } from "./parser.ts";
import type { Rec } from "./types.ts";

export { ParseError } from "./types.ts";
export type { Rec } from "./types.ts";

/** Parses once (throws ParseError on a bad query), returns a predicate over records. */
export function compile(query: string): (rec: Rec) => boolean {
  const ast = parse(query);
  return (rec) => evaluate(ast, rec);
}
