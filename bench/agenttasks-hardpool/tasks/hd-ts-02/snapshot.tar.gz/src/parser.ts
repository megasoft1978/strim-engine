import type { Node } from "./types.ts";

/**
 * Parses a query into a Node. Precedence, loosest to tightest: or, and (also implicit between adjacent terms), not.
 * An empty query is { k: "all" }. `word op word` is a cmp (an unquoted value splits on "," into values; a quoted value is one value),
 * a bare word is a term. Relational operators (< <= > >=) reject lists of more than one value.
 * Throws ParseError; pos is: the "(" for an unclosed group, the ")" for an unmatched one, the offending token otherwise,
 * and query.length when the query ends too early.
 */
export function parse(query: string): Node {
  throw new Error("not implemented");
}
