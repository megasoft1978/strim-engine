import type { Node, Rec } from "./types.ts";

/**
 * Evaluates a Node against a record.
 * - field paths are dotted ("owner.name"); a missing path has no values.
 * - ":" matches when any scalar value of the field (array elements included) equals any wanted value, case-insensitively,
 *   comparing numbers and booleans by their string form. "!=" is the exact negation of ":" (so true for a missing field).
 * - < <= > >= compare only real numbers with a numeric right-hand side; anything else is false.
 * - a bare term matches when any top-level string value (or string element of a top-level array) contains it, case-insensitively.
 */
export function evaluate(n: Node, rec: Rec): boolean {
  throw new Error("not implemented");
}
