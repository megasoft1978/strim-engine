export type Value = string | number | boolean | null | undefined | Value[] | { [k: string]: Value };
export type Rec = { [k: string]: Value };

export type Op = ":" | "!=" | "<" | "<=" | ">" | ">=";

/** `pos` is the 0-based offset of the token in the query string. */
export type Token =
  | { t: "word"; text: string; quoted: boolean; pos: number }
  | { t: "op"; op: Op; pos: number }
  | { t: "lparen" | "rparen" | "and" | "or" | "not"; pos: number };

export type Node =
  | { k: "all" }
  | { k: "term"; text: string }
  | { k: "cmp"; field: string; op: Op; values: string[] }
  | { k: "and" | "or"; l: Node; r: Node }
  | { k: "not"; e: Node };

export class ParseError extends Error {
  pos: number;
  constructor(message: string, pos: number) {
    super(message);
    this.name = "ParseError";
    this.pos = pos;
  }
}
