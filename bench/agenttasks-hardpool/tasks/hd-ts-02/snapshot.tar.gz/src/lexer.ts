import type { Token } from "./types.ts";

/**
 * Splits a query into tokens. Words stop at whitespace, parentheses, quotes and operator characters.
 * "and" / "or" / "not" (any case, unquoted) become keyword tokens. Quoted words support \" and \\ escapes.
 * Throws ParseError (with the offset of the opening quote) for an unterminated string and for a lone "!" or "=".
 */
export function lex(q: string): Token[] {
  throw new Error("not implemented");
}
