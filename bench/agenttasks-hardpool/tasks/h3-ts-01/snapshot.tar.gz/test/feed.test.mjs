import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Feed } from '../src/service.ts';
import { EventStore } from '../src/store.ts';
import { exportRows, importRows } from '../src/import.ts';
import { audit, gaps, topicRuns } from '../src/audit.ts';
import { countWindows } from '../src/windows.ts';

const make = (topic, actor = 'ann') => ({ time: '2026-01-01T00:00:00Z', topic, actor, action: 'update' });

test('continuation stays on its original snapshot while new events arrive', () => {
  const feed = new Feed();
  for (const topic of ['a', 'b', 'a', 'a', 'a']) feed.store.append(make(topic));
  const first = feed.list({ filter: { topic: 'a' }, limit: 2 });
  assert.deepEqual(first.events.map(e => e.seq), [1, 3]);
  assert.ok(first.nextCursor);
  feed.store.append(make('a'));
  const second = feed.list({ cursor: first.nextCursor, limit: 2 });
  assert.deepEqual(second.events.map(e => e.seq), [4, 5]);
  assert.equal(second.nextCursor, null);
  assert.deepEqual(feed.list({ filter: { topic: 'a' }, limit: 100 }).events.map(e => e.seq), [1, 3, 4, 5, 6]);
});

test('continuation rejects changed filters, malformed cursors and tampered fields', () => {
  const feed = new Feed();
  feed.store.appendMany([make('a'), make('a'), make('b')]);
  const cursor = feed.list({ filter: { topic: 'a' }, limit: 1 }).nextCursor;
  assert.ok(cursor);
  assert.throws(() => feed.list({ cursor, filter: { topic: 'b' } }));
  assert.throws(() => feed.list({ cursor: '%xx' }));
  assert.throws(() => feed.list({ cursor: encodeURIComponent(JSON.stringify({ version: 1, after: -1, ceiling: 2, filter: {} })) }));
  assert.throws(() => feed.list({ cursor: encodeURIComponent(JSON.stringify({ version: 1, after: 2, ceiling: 1, filter: {} })) }));
});

test('time filters normalize offsets and preserve half-open ranges', () => {
  const feed = new Feed();
  feed.store.append({ ...make('a'), time: '2026-01-01T01:00:00+01:00' });
  feed.store.append({ ...make('a'), time: '2026-01-02T00:00:00Z' });
  const result = feed.list({ filter: { from: '2026-01-01T00:00:00Z', until: '2026-01-02T00:00:00Z' } });
  assert.deepEqual(result.events.map(e => e.seq), [1]);
  assert.equal(result.nextCursor, null);
});

test('batch validation, import, audit and reports remain usable', () => {
  const store = new EventStore();
  assert.throws(() => store.appendMany([make('a'), { ...make('b'), actor: '' }]));
  assert.equal(store.size(), 0);
  const values = [make('a'), { ...make('b'), detail: 'a\tb\n\\' }];
  assert.deepEqual(importRows(exportRows(values)).map(x => x.detail), ['', 'a\tb\n\\']);
  store.appendMany(values);
  const events = store.all();
  assert.deepEqual(audit(events), []);
  assert.deepEqual(gaps(events), []);
  assert.equal(topicRuns(events).length, 2);
  assert.equal(countWindows(events, 86400000)[0].count, 2);
});

test('pages do not skip filtered records and may change their size', () => {
  const feed = new Feed();
  for (const topic of ['a', 'b', 'a', 'b', 'a', 'a', 'a']) feed.store.append(make(topic));
  const first = feed.list({ filter: { topic: 'a' }, limit: 1 });
  const second = feed.list({ cursor: first.nextCursor, limit: 2, filter: { topic: 'a' } });
  const third = feed.list({ cursor: second.nextCursor, limit: 10 });
  assert.deepEqual([...first.events, ...second.events, ...third.events].map(e => e.seq), [1, 3, 5, 6, 7]);
  assert.equal(third.nextCursor, null);
  assert.deepEqual(feed.list({ filter: { topic: 'missing' }, limit: 1 }), { events: [], nextCursor: null });
});
