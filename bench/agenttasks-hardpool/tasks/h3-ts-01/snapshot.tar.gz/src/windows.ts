import type { Event } from './types.ts';

export interface WindowCount { start: string; end: string; count: number }

/** Bucket events by fixed UTC durations, aligned with the Unix epoch. */
export function countWindows(events: Event[], widthMs: number): WindowCount[] {
  if (!Number.isSafeInteger(widthMs) || widthMs <= 0) throw new RangeError('invalid window');
  const buckets = new Map<number, number>();
  for (const event of events) {
    const value = Date.parse(event.time);
    if (!Number.isFinite(value)) throw new RangeError('invalid event time');
    const start = Math.floor(value / widthMs) * widthMs;
    buckets.set(start, (buckets.get(start) ?? 0) + 1);
  }
  return [...buckets].sort(([a], [b]) => a - b).map(([start, count]) => ({
    start: new Date(start).toISOString(),
    end: new Date(start + widthMs).toISOString(),
    count,
  }));
}

/** Return events in a half-open UTC interval, without reordering the input. */
export function within(events: Event[], from: string, until: string): Event[] {
  const start = Date.parse(from);
  const end = Date.parse(until);
  if (!Number.isFinite(start) || !Number.isFinite(end) || start >= end) {
    throw new RangeError('invalid interval');
  }
  return events.filter(event => {
    const time = Date.parse(event.time);
    return time >= start && time < end;
  });
}
