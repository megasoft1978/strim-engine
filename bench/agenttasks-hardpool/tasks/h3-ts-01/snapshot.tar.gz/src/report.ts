import type { Event } from './types.ts';

export interface Count { name: string; count: number }
export function counts(events: Event[], field: 'topic' | 'actor' | 'action'): Count[] {
  const grouped = new Map<string, number>();
  for (const event of events) grouped.set(event[field], (grouped.get(event[field]) ?? 0) + 1);
  return [...grouped].map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}

export function dailyCounts(events: Event[]): Count[] {
  const grouped = new Map<string, number>();
  for (const event of events) {
    const day = event.time.slice(0, 10);
    grouped.set(day, (grouped.get(day) ?? 0) + 1);
  }
  return [...grouped].map(([name, count]) => ({ name, count }))
    .sort((a, b) => a.name.localeCompare(b.name));
}

export function renderSummary(events: Event[]): string {
  const days = dailyCounts(events);
  if (!days.length) return 'No events';
  return days.map(day => `${day.name}: ${day.count}`).join('\n');
}
