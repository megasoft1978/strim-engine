import type { EventInput } from './types.ts';
import { normalizeEvent } from './validate.ts';

/** Parse tab-delimited export rows. Backslash escapes preserve tabs and newlines. */
function decodeField(value: string): string {
  let out = '';
  for (let i = 0; i < value.length; i++) {
    if (value[i] !== '\\') { out += value[i]; continue; }
    i++;
    const escaped = value[i];
    if (escaped === 't') out += '\t';
    else if (escaped === 'n') out += '\n';
    else if (escaped === '\\') out += '\\';
    else throw new SyntaxError('invalid escape');
  }
  return out;
}

function encodeField(value: string): string {
  return value.replaceAll('\\', '\\\\').replaceAll('\t', '\\t').replaceAll('\n', '\\n');
}

export function exportRows(events: EventInput[]): string {
  return events.map(event => [event.time, event.topic, event.actor, event.action, event.detail ?? '']
    .map(encodeField).join('\t')).join('\n');
}

export function importRows(text: string): Required<EventInput>[] {
  if (!text) return [];
  return text.split('\n').map((line, index) => {
    const fields = line.split('\t').map(decodeField);
    if (fields.length !== 5) throw new SyntaxError(`row ${index + 1}: expected five fields`);
    return normalizeEvent({ time: fields[0], topic: fields[1], actor: fields[2], action: fields[3], detail: fields[4] });
  });
}
