import type { Event, EventInput } from './types.ts';
import { normalizeEvent } from './validate.ts';

/** Append-only in-memory event storage. Callers receive copies. */
export class EventStore {
  private events: Event[] = [];
  private nextSequence = 1;

  append(input: EventInput): Event {
    const event: Event = { seq: this.nextSequence++, ...normalizeEvent(input) };
    this.events.push(event);
    return { ...event };
  }

  appendMany(inputs: EventInput[]): Event[] {
    // Validate the whole batch before consuming a sequence number.
    const normalized = inputs.map(normalizeEvent);
    return normalized.map(input => this.append(input));
  }

  all(): Event[] { return this.events.map(event => ({ ...event })); }
  lastSequence(): number { return this.nextSequence - 1; }
  size(): number { return this.events.length; }

  find(seq: number): Event | null {
    const event = this.events.find(item => item.seq === seq);
    return event ? { ...event } : null;
  }
}
