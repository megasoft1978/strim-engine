import type { EventInput, Filter } from './types.ts';

export function timestamp(value: string): string {
  // Require an explicit UTC offset; a local timestamp changes meaning with TZ.
  if (!/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,3})?(?:Z|[+-]\d\d:\d\d)$/.test(value)) {
    throw new RangeError('timestamp must include an offset');
  }
  const milliseconds = Date.parse(value);
  if (!Number.isFinite(milliseconds)) throw new RangeError('invalid timestamp');
  return new Date(milliseconds).toISOString();
}

function required(value: string, field: string): string {
  if (typeof value !== 'string' || !value.trim()) throw new TypeError(`${field} required`);
  return value.trim();
}

export function normalizeEvent(input: EventInput): Required<EventInput> {
  return {
    time: timestamp(input.time),
    topic: required(input.topic, 'topic'),
    actor: required(input.actor, 'actor'),
    action: required(input.action, 'action'),
    detail: input.detail ?? '',
  };
}

export function normalizeFilter(input: Filter = {}): Filter {
  const result: Filter = {};
  for (const field of ['topic', 'actor', 'action'] as const) {
    if (input[field] !== undefined) result[field] = required(input[field], field);
  }
  if (input.from !== undefined) result.from = timestamp(input.from);
  if (input.until !== undefined) result.until = timestamp(input.until);
  if (result.from && result.until && result.from >= result.until) {
    throw new RangeError('empty time range');
  }
  return result;
}

export function pageLimit(value = 20): number {
  if (!Number.isInteger(value) || value < 1 || value > 100) throw new RangeError('invalid page limit');
  return value;
}
