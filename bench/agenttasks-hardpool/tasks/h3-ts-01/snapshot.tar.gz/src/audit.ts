import type { Event } from './types.ts';

export interface AuditIssue {
  index: number;
  code: 'sequence' | 'timestamp' | 'empty-field';
  message: string;
}

/** Inspect imported historical records without mutating them. */
export function audit(events: Event[]): AuditIssue[] {
  const issues: AuditIssue[] = [];
  let previous = 0;
  events.forEach((event, index) => {
    if (!Number.isSafeInteger(event.seq) || event.seq <= previous) {
      issues.push({ index, code: 'sequence', message: 'sequence must increase' });
    }
    previous = event.seq;
    if (!Number.isFinite(Date.parse(event.time))) {
      issues.push({ index, code: 'timestamp', message: 'timestamp is invalid' });
    }
    if (!event.topic || !event.actor || !event.action) {
      issues.push({ index, code: 'empty-field', message: 'required field is empty' });
    }
  });
  return issues;
}

/** Find gaps in a sequence-sorted export. */
export function gaps(events: Event[]): Array<{ from: number; to: number }> {
  const result: Array<{ from: number; to: number }> = [];
  for (let i = 1; i < events.length; i++) {
    const from = events[i - 1].seq + 1;
    const to = events[i].seq - 1;
    if (from <= to) result.push({ from, to });
  }
  return result;
}

/** Group consecutive events by topic, preserving their arrival order. */
export function topicRuns(events: Event[]): Array<{ topic: string; first: number; last: number; count: number }> {
  const runs: Array<{ topic: string; first: number; last: number; count: number }> = [];
  for (const event of events) {
    const last = runs[runs.length - 1];
    if (last && last.topic === event.topic) {
      last.last = event.seq;
      last.count++;
    } else {
      runs.push({ topic: event.topic, first: event.seq, last: event.seq, count: 1 });
    }
  }
  return runs;
}
