import type { Cursor, Event, Filter, Page } from './types.ts';
import { select } from './filter.ts';

export function firstPage(events: Event[], filter: Filter, limit: number): Page {
  return { events: select(events, filter).slice(0, limit), nextCursor: null };
}

export function continuedPage(_events: Event[], _cursor: Cursor, _limit: number): Page {
  throw new Error('cursor continuation is not implemented');
}
