import type { Event, Filter } from './types.ts';

/** Time range is inclusive at the start and exclusive at the end. */
export function matches(event: Event, filter: Filter): boolean {
  if (filter.topic !== undefined && event.topic !== filter.topic) return false;
  if (filter.actor !== undefined && event.actor !== filter.actor) return false;
  if (filter.action !== undefined && event.action !== filter.action) return false;
  if (filter.from !== undefined && event.time < filter.from) return false;
  if (filter.until !== undefined && event.time >= filter.until) return false;
  return true;
}

export function select(events: Event[], filter: Filter): Event[] {
  return events.filter(event => matches(event, filter));
}
