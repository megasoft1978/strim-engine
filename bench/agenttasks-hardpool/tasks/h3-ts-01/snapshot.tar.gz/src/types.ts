/** Events are immutable after append and their sequence is unique and increasing. */
export interface Event {
  seq: number;
  time: string;
  topic: string;
  actor: string;
  action: string;
  detail: string;
}
export interface EventInput {
  time: string;
  topic: string;
  actor: string;
  action: string;
  detail?: string;
}
export interface Filter {
  topic?: string;
  actor?: string;
  action?: string;
  from?: string;
  until?: string;
}
export interface PageRequest {
  filter?: Filter;
  limit?: number;
  cursor?: string;
}
export interface Page {
  events: Event[];
  nextCursor: string | null;
}
export interface Cursor {
  version: 1;
  after: number;
  ceiling: number;
  filter: Filter;
}
