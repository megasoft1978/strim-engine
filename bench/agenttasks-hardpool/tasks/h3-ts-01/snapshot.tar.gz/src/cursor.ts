import type { Cursor } from './types.ts';

/** A cursor is opaque to API callers and should be validated before use. */
export function encodeCursor(cursor: Cursor): string {
  return encodeURIComponent(JSON.stringify(cursor));
}

export function decodeCursor(_raw: string): Cursor {
  throw new Error('cursor continuation is not implemented');
}
