import type { Page, PageRequest } from './types.ts';
import { EventStore } from './store.ts';
import { firstPage } from './page.ts';
import { normalizeFilter, pageLimit } from './validate.ts';

/** Read interface for clients of the event feed. */
export class Feed {
  readonly store: EventStore;
  constructor(store = new EventStore()) { this.store = store; }

  list(request: PageRequest = {}): Page {
    const limit = pageLimit(request.limit);
    const filter = normalizeFilter(request.filter);
    return firstPage(this.store.all(), filter, limit);
  }
}
