import test from 'node:test';
import assert from 'node:assert/strict';
import { Router } from '../lib/index.js';

const send = (r, method, path) => r.handle({ method, path });
const echo = (ctx) => { ctx.body = { params: ctx.params }; };

test('static routes, trailing slashes, repeated slashes and query strings', async () => {
  const r = new Router().get('/users', (ctx) => { ctx.body = 'list'; });
  for (const p of ['/users', '/users/', '//users', '/users?page=2', '/users/?a=1#top']) {
    assert.deepEqual(await send(r, 'GET', p), { status: 200, headers: {}, body: 'list' }, p);
  }
  assert.equal((await send(r, 'GET', '/Users')).status, 404);
});

test('root route', async () => {
  const r = new Router().get('/', (ctx) => { ctx.body = 'home'; });
  assert.equal((await send(r, 'GET', '/')).body, 'home');
  assert.equal((await send(r, 'GET', '')).body, 'home');
});

test('params are captured and percent-decoded', async () => {
  const r = new Router().get('/users/:id/posts/:post', echo);
  assert.deepEqual((await send(r, 'GET', '/users/42/posts/hello%20world')).body, { params: { id: '42', post: 'hello world' } });
  assert.deepEqual((await send(r, 'GET', '/users/a%2Fb/posts/x')).body.params, { id: 'a/b', post: 'x' });
});

test('malformed percent-encoding is a 400 and runs middleware but no handler', async () => {
  let hit = false, saw = null;
  const r = new Router()
    .use(async (ctx, next) => { await next(); saw = ctx.status; })
    .get('/users/:id', () => { hit = true; });
  const res = await send(r, 'GET', '/users/%E0%A4%A');
  assert.deepEqual([res.status, res.body, hit, saw], [400, 'Bad Request', false, 400]);
});

test('static segments compare decoded', async () => {
  const r = new Router().get('/a b', (ctx) => { ctx.body = 'space'; });
  assert.equal((await send(r, 'GET', '/a%20b')).body, 'space');
});

test('wildcard captures the rest, including nothing', async () => {
  const r = new Router().get('/files/*', echo);
  assert.deepEqual((await send(r, 'GET', '/files/a/b%20c/d.txt')).body.params, { '*': 'a/b c/d.txt' });
  assert.deepEqual((await send(r, 'GET', '/files')).body.params, { '*': '' });
  assert.deepEqual((await send(r, 'GET', '/files/')).body.params, { '*': '' });
});

test('wildcard must be the last segment', () => {
  assert.throws(() => new Router().get('/a/*/b', echo), /wildcard/);
});

test('precedence per segment: static, then param, then wildcard, regardless of registration order', async () => {
  const r = new Router()
    .get('/items/*', (ctx) => { ctx.body = 'wild'; })
    .get('/items/:id', (ctx) => { ctx.body = 'param'; })
    .get('/items/new', (ctx) => { ctx.body = 'static'; });
  assert.equal((await send(r, 'GET', '/items/new')).body, 'static');
  assert.equal((await send(r, 'GET', '/items/7')).body, 'param');
  assert.equal((await send(r, 'GET', '/items/7/edit')).body, 'wild');
});

test('earlier segments win over later ones', async () => {
  const r = new Router()
    .get('/a/:x/c', (ctx) => { ctx.body = 'param-first'; })
    .get('/a/b/*', (ctx) => { ctx.body = 'static-first'; });
  assert.equal((await send(r, 'GET', '/a/b/c')).body, 'static-first');
  assert.equal((await send(r, 'GET', '/a/z/c')).body, 'param-first');
});

test('falls back to a less specific route when the specific branch dead-ends', async () => {
  const r = new Router()
    .get('/a/b/d', (ctx) => { ctx.body = 'abd'; })
    .get('/a/:x/c', echo)
    .get('/a/*', (ctx) => { ctx.body = 'wild'; });
  assert.deepEqual((await send(r, 'GET', '/a/b/c')).body, { params: { x: 'b' } });
  assert.equal((await send(r, 'GET', '/a/b/d')).body, 'abd');
  assert.equal((await send(r, 'GET', '/a/b/e')).body, 'wild');
});

test('the method takes part in matching before precedence gives up', async () => {
  const r = new Router()
    .get('/users/me', (ctx) => { ctx.body = 'me'; })
    .post('/users/:id', (ctx) => { ctx.body = `post ${ctx.params.id}`; });
  assert.equal((await send(r, 'POST', '/users/me')).body, 'post me');
  assert.equal((await send(r, 'GET', '/users/me')).body, 'me');
});

test('404 for unknown paths, 405 with sorted Allow for wrong methods', async () => {
  const r = new Router()
    .get('/res/:id', (ctx) => { ctx.body = 'g'; })
    .delete('/res/:id', (ctx) => { ctx.body = 'd'; })
    .put('/res/special', (ctx) => { ctx.body = 'p'; });
  assert.deepEqual(await send(r, 'GET', '/nope'), { status: 404, headers: {}, body: 'Not Found' });
  assert.deepEqual(await send(r, 'POST', '/res/5'), { status: 405, headers: { allow: 'DELETE, GET, HEAD' }, body: 'Method Not Allowed' });
  assert.equal((await send(r, 'POST', '/res/special')).headers.allow, 'DELETE, GET, HEAD, PUT');
});

test('HEAD falls back to GET without a body; an explicit HEAD route wins', async () => {
  const r = new Router().get('/x', (ctx) => { ctx.status = 201; ctx.body = 'data'; });
  assert.deepEqual(await send(r, 'HEAD', '/x'), { status: 201, headers: {}, body: undefined });
  r.route('HEAD', '/y', (ctx) => { ctx.status = 202; });
  r.get('/y', (ctx) => { ctx.status = 200; });
  assert.equal((await send(r, 'HEAD', '/y')).status, 202);
});

test('matched handler without body or status answers 204; explicit status is kept', async () => {
  const r = new Router().post('/n', () => {}).get('/g', (ctx) => { ctx.status = 418; });
  assert.deepEqual(await send(r, 'POST', '/n'), { status: 204, headers: {}, body: undefined });
  assert.equal((await send(r, 'GET', '/g')).status, 418);
});

test('middleware is an onion: global in order, then route handlers, then back out', async () => {
  const log = [];
  const mw = (n) => async (ctx, next) => { log.push(`>${n}`); await next(); log.push(`<${n}`); };
  const r = new Router()
    .use(mw('a'))
    .get('/x', mw('h1'), mw('h2'), (ctx) => { log.push('end'); ctx.body = 'ok'; })
    .use(mw('b'));
  await send(r, 'GET', '/x');
  assert.deepEqual(log, ['>a', '>b', '>h1', '>h2', 'end', '<h2', '<h1', '<b', '<a']);
});

test('global middleware also sees 404 and 405 and can rewrite them', async () => {
  const seen = [];
  const r = new Router()
    .use(async (ctx, next) => {
      await next();
      seen.push(ctx.status);
      if (ctx.status === 404) { ctx.status = 200; ctx.body = 'fallback'; }
    })
    .post('/p', () => {});
  assert.deepEqual(await send(r, 'GET', '/zzz'), { status: 200, headers: {}, body: 'fallback' });
  await send(r, 'GET', '/p');
  assert.deepEqual(seen, [404, 405]);
});

test('middleware that does not call next short-circuits', async () => {
  let ran = false;
  const r = new Router()
    .use((ctx) => { ctx.status = 401; ctx.body = 'denied'; })
    .get('/x', () => { ran = true; });
  assert.deepEqual(await send(r, 'GET', '/x'), { status: 401, headers: {}, body: 'denied' });
  assert.equal(ran, false);
});

test('calling next twice is an error that becomes a 500', async () => {
  const r = new Router().get('/x', async (ctx, next) => { await next(); await next(); });
  assert.deepEqual(await send(r, 'GET', '/x'), { status: 500, headers: {}, body: 'Internal Server Error' });
});

test('thrown and rejected errors become 500 and discard partial output', async () => {
  const r = new Router()
    .get('/sync', (ctx) => { ctx.body = 'partial'; ctx.headers.x = '1'; throw new Error('boom'); })
    .get('/async', async () => { throw new Error('later'); });
  assert.deepEqual(await send(r, 'GET', '/sync'), { status: 500, headers: {}, body: 'Internal Server Error' });
  assert.equal((await send(r, 'GET', '/async')).status, 500);
});

test('onError customises the response and may itself fail', async () => {
  const r = new Router()
    .onError((err, ctx) => { ctx.status = 502; ctx.body = `bad: ${err.message}`; })
    .get('/x', () => { throw new Error('boom'); });
  assert.deepEqual(await send(r, 'GET', '/x'), { status: 502, headers: {}, body: 'bad: boom' });
  r.onError(() => { throw new Error('again'); });
  assert.equal((await send(r, 'GET', '/x')).status, 500);
});

test('duplicate method+shape throws, different methods and param names do not', () => {
  const r = new Router().get('/u/:id', echo).post('/u/:id', echo);
  assert.throws(() => r.get('/u/:name', echo), /duplicate/);
  assert.doesNotThrow(() => r.get('/u/:id/x', echo));
});

test('routes sharing a param position may name it differently', async () => {
  const r = new Router().get('/u/:id', echo).get('/u/:uid/x', echo);
  assert.deepEqual((await send(r, 'GET', '/u/5')).body.params, { id: '5' });
  assert.deepEqual((await send(r, 'GET', '/u/5/x')).body.params, { uid: '5' });
});

test('param values like __proto__ are plain data', async () => {
  const r = new Router().get('/p/:name', echo);
  const res = await send(r, 'GET', '/p/__proto__');
  assert.equal(Object.keys(res.body.params).length, 1);
  assert.equal(Object.getPrototypeOf(res.body.params), Object.prototype);
  assert.equal(res.body.params.name, '__proto__');
});
