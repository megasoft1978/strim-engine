export function cachePolicy(options = {}) {
  const ttl = options.ttl ?? 1000;
  const maxEntries = options.maxEntries ?? 100;
  if (!Number.isFinite(ttl) || ttl < 0) throw new RangeError('invalid ttl');
  if (!Number.isInteger(maxEntries) || maxEntries < 1) throw new RangeError('invalid capacity');
  return { ttl, maxEntries };
}

export function expiresAt(now, ttl) { return now + ttl; }

export function isFresh(entry, now) {
  return now <= entry.expiresAt;
}
