import { itemKey } from './keys.js';

/** A simple async repository suitable for embedding and tests. */
export class MemoryRepository {
  constructor(items = []) {
    this.items = new Map();
    for (const item of items) this.items.set(itemKey(item.id), { ...item });
  }

  async fetch(id) {
    const item = this.items.get(itemKey(id));
    return item ? { ...item } : null;
  }

  async save(item) {
    this.items.set(itemKey(item.id), { ...item });
  }

  async remove(id) {
    this.items.delete(itemKey(id));
  }

  async all() {
    return Array.from(this.items.values(), item => ({ ...item }));
  }
}
