import { Cache } from './cache.js';
import { itemKey, scopedKey } from './keys.js';

/** Catalog coordinates a backing repository and namespace-scoped cache. */
export class Catalog {
  constructor(repository, namespace, options = {}) {
    this.repository = repository;
    this.namespace = namespace;
    this.cache = new Cache(async key => {
      const [, id] = JSON.parse(key);
      return this.repository.fetch(id);
    }, options);
  }

  get(id) { return this.cache.get(scopedKey(this.namespace, id)); }

  async save(item) {
    const id = itemKey(item.id);
    await this.repository.save({ ...item, id });
    this.cache.invalidate(scopedKey(this.namespace, id));
  }

  async remove(id) {
    const normalized = itemKey(id);
    await this.repository.remove(normalized);
    this.cache.invalidate(scopedKey(this.namespace, normalized));
  }

  reset() { this.cache.clear(); }
}

/** Build a deterministic search page from the repository's current records. */
export async function searchCatalog(repository, query = {}, page = {}) {
  const { filterItems } = await import('./query.js');
  const { pageItems } = await import('./pagination.js');
  return pageItems(filterItems(await repository.all(), query), page);
}
