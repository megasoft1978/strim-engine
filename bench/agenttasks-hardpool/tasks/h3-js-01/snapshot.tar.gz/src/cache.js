import { systemClock } from './clock.js';
import { cachePolicy, expiresAt } from './policy.js';
import { Store } from './store.js';

/**
 * Cache loader results, including null. Rejections are never cached.
 * An explicit invalidation marks prior requests obsolete: their callers may
 * still receive the old result, but new calls must not join that request.
 */
export class Cache {
  constructor(loader, options = {}) {
    if (typeof loader !== 'function') throw new TypeError('loader required');
    this.loader = loader;
    this.clock = options.clock ?? systemClock;
    this.policy = cachePolicy(options);
    this.store = new Store(this.policy.maxEntries);
  }

  async get(key) {
    const entry = this.store.read(key, this.clock.now());
    if (entry) return entry.value;
    const existing = this.store.pending.get(key);
    if (existing) return existing;
    const pending = Promise.resolve().then(() => this.loader(key)).then(value => {
      this.store.write(key, { value, expiresAt: expiresAt(this.clock.now(), this.policy.ttl) });
      return value;
    }).finally(() => {
      this.store.pending.delete(key);
    });
    this.store.pending.set(key, pending);
    return pending;
  }

  invalidate(key) { this.store.remove(key); }
  clear() { this.store.clear(); }
}
