/** A clock can be supplied by callers to make expiry deterministic. */
export const systemClock = { now: () => Date.now() };

export class ManualClock {
  constructor(now = 0) { this.time = now; }
  now() { return this.time; }
  advance(ms) {
    if (!Number.isFinite(ms) || ms < 0) throw new RangeError('invalid duration');
    this.time += ms;
  }
}
