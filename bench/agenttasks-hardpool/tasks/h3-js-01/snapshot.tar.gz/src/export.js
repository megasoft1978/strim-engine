/** Escape a field according to the CSV quoting rules. */
export function csvField(value) {
  const text = value == null ? '' : String(value);
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

/** Export stable catalog columns with CRLF line endings. Prices are integer cents. */
export function exportCatalog(items) {
  const rows = [['id', 'name', 'category', 'price']];
  for (const item of items) {
    rows.push([item.id, item.name, item.category, item.price]);
  }
  return rows.map(row => row.map(csvField).join(',')).join('\r\n') + '\r\n';
}

/** Parse a CSV line, allowing quoted commas and doubled quotes. */
export function parseCsvLine(line) {
  const fields = [];
  let value = '';
  let quoted = false;
  let closed = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (quoted) {
      if (char === '"' && line[i + 1] === '"') {
        value += '"';
        i++;
      } else if (char === '"') {
        quoted = false;
        closed = true;
      } else {
        value += char;
      }
    } else if (char === ',') {
      fields.push(value);
      value = '';
      closed = false;
    } else if (char === '"' && !value && !closed) {
      quoted = true;
    } else if (closed || char === '"') {
      throw new SyntaxError('invalid CSV field');
    } else {
      value += char;
    }
  }
  if (quoted) throw new SyntaxError('unterminated CSV field');
  fields.push(value);
  return fields;
}
