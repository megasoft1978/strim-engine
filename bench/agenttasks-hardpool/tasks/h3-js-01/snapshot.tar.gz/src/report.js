/** Produce a stable display summary from catalog records. */
export function summarize(items) {
  const groups = new Map();
  for (const item of items) {
    const category = item.category || 'uncategorized';
    const group = groups.get(category) ?? { category, count: 0, total: 0 };
    group.count += 1;
    group.total += item.price ?? 0;
    groups.set(category, group);
  }
  return [...groups.values()].sort((a, b) => a.category.localeCompare(b.category));
}

/** Convert cents to a decimal string without floating point rounding. */
export function formatPrice(cents) {
  if (!Number.isSafeInteger(cents) || cents < 0) {
    throw new RangeError('price must be non-negative integer cents');
  }
  const whole = Math.floor(cents / 100);
  const fraction = String(cents % 100).padStart(2, '0');
  return `${whole}.${fraction}`;
}
