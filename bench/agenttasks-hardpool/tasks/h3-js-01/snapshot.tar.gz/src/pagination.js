/** Stable page construction; equal primary keys are ordered by identifier. */
export function pageItems(items, options = {}) {
  const offset = options.offset ?? 0;
  const limit = options.limit ?? 25;
  const sort = options.sort ?? 'id';
  const direction = options.direction ?? 'asc';
  if (!Number.isSafeInteger(offset) || offset < 0) throw new RangeError('invalid offset');
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100) throw new RangeError('invalid limit');
  if (!['id', 'name', 'price'].includes(sort)) throw new RangeError('invalid sort');
  if (!['asc', 'desc'].includes(direction)) throw new RangeError('invalid direction');
  const compare = (left, right) => {
    if (left === right) return 0;
    return left < right ? -1 : 1;
  };
  const ordered = [...items].sort((a, b) => {
    const av = a[sort] ?? (sort === 'price' ? 0 : '');
    const bv = b[sort] ?? (sort === 'price' ? 0 : '');
    const primary = compare(av, bv) * (direction === 'desc' ? -1 : 1);
    return primary || compare(a.id, b.id);
  });
  return {
    items: ordered.slice(offset, offset + limit),
    total: ordered.length,
    nextOffset: offset + limit < ordered.length ? offset + limit : null,
  };
}
