/** Normalize catalog identifiers, without changing case. */
export function itemKey(id) {
  if (typeof id !== 'string' || !id.trim()) throw new TypeError('id required');
  return id.trim();
}

/** A namespace is part of a cache key, not part of an item identifier. */
export function scopedKey(namespace, id) {
  if (typeof namespace !== 'string' || !namespace) throw new TypeError('namespace required');
  return JSON.stringify([namespace, itemKey(id)]);
}
