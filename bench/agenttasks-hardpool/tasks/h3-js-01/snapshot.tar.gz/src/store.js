import { isFresh } from './policy.js';

/** Bounded LRU storage. In-flight requests live separately from completed values. */
export class Store {
  constructor(capacity) {
    this.capacity = capacity;
    this.values = new Map();
    this.pending = new Map();
  }

  read(key, now) {
    const entry = this.values.get(key);
    if (!entry) return undefined;
    if (!isFresh(entry, now)) {
      this.values.delete(key);
      return undefined;
    }
    this.values.delete(key);
    this.values.set(key, entry);
    return entry;
  }

  write(key, entry) {
    this.values.delete(key);
    this.values.set(key, entry);
    while (this.values.size > this.capacity) {
      this.values.delete(this.values.keys().next().value);
    }
  }

  remove(key) {
    this.values.delete(key);
  }

  clear() {
    this.values.clear();
  }
}
