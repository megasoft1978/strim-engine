/** Catalog queries use exact category matching and case-insensitive text search. */
export function normalizeQuery(query = {}) {
  const text = String(query.text ?? '').trim().toLocaleLowerCase('en-US');
  const category = query.category == null ? null : String(query.category);
  const minPrice = query.minPrice ?? null;
  const maxPrice = query.maxPrice ?? null;
  for (const price of [minPrice, maxPrice]) {
    if (price !== null && (!Number.isSafeInteger(price) || price < 0)) {
      throw new RangeError('prices must be non-negative integer cents');
    }
  }
  if (minPrice !== null && maxPrice !== null && minPrice > maxPrice) {
    throw new RangeError('minimum exceeds maximum');
  }
  return { text, category, minPrice, maxPrice };
}

export function matches(item, query) {
  if (query.category !== null && item.category !== query.category) return false;
  if (query.minPrice !== null && item.price < query.minPrice) return false;
  if (query.maxPrice !== null && item.price > query.maxPrice) return false;
  if (query.text) {
    const haystack = [item.id, item.name, item.category]
      .filter(value => value != null)
      .join(' ')
      .toLocaleLowerCase('en-US');
    if (!haystack.includes(query.text)) return false;
  }
  return true;
}

export function filterItems(items, query = {}) {
  const normalized = normalizeQuery(query);
  return items.filter(item => matches(item, normalized));
}
