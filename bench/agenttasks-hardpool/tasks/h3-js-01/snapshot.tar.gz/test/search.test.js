import { test } from 'node:test';
import assert from 'node:assert/strict';
import { MemoryRepository } from '../src/repository.js';
import { searchCatalog } from '../src/catalog.js';
import { exportCatalog, parseCsvLine } from '../src/export.js';

test('search filters, sorts, and paginates without mutating records', async () => {
  const records = [
    { id: 'b', name: 'Blue Book', category: 'books', price: 250 },
    { id: 'a', name: 'Big Book', category: 'books', price: 250 },
    { id: 'c', name: 'Blue Pen', category: 'pens', price: 50 },
  ];
  const repo = new MemoryRepository(records);
  const result = await searchCatalog(repo, { text: 'BOOK', minPrice: 200 }, { sort: 'price', limit: 1 });
  assert.equal(result.total, 2);
  assert.equal(result.items[0].id, 'a');
  assert.equal(result.nextOffset, 1);
  assert.deepEqual((await repo.all()).map(x => x.id), ['b', 'a', 'c']);
  await assert.rejects(searchCatalog(repo, { minPrice: 3, maxPrice: 2 }), RangeError);
});

test('CSV export quotes punctuation and retains cents', () => {
  const output = exportCatalog([{ id: 'a', name: 'A, "quoted"', category: 'book', price: 0 }]);
  const [heading, row] = output.trimEnd().split('\r\n');
  assert.deepEqual(parseCsvLine(heading), ['id', 'name', 'category', 'price']);
  assert.deepEqual(parseCsvLine(row), ['a', 'A, "quoted"', 'book', '0']);
  assert.throws(() => parseCsvLine('"unfinished'), SyntaxError);
});

test('report formats integer cents exactly', async () => {
  const { formatPrice } = await import('../src/report.js');
  assert.equal(formatPrice(109), '1.09');
  assert.equal(formatPrice(0), '0.00');
  assert.throws(() => formatPrice(-1), RangeError);
});
