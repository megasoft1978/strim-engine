import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Catalog } from '../src/catalog.js';
import { Cache } from '../src/cache.js';
import { ManualClock } from '../src/clock.js';
import { MemoryRepository } from '../src/repository.js';
import { summarize } from '../src/report.js';

function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}

test('expiry is exclusive and reads refresh LRU position', async () => {
  const clock = new ManualClock();
  let calls = 0;
  const cache = new Cache(async key => `${key}:${++calls}`, { clock, ttl: 10, maxEntries: 2 });
  assert.equal(await cache.get('a'), 'a:1');
  clock.advance(9);
  assert.equal(await cache.get('a'), 'a:1');
  clock.advance(1);
  assert.equal(await cache.get('a'), 'a:2');
  await cache.get('b');
  await cache.get('a');
  await cache.get('c');
  assert.equal(await cache.get('a'), 'a:2');
  assert.equal(await cache.get('b'), 'b:5');
});

test('save makes a pending read obsolete without discarding its caller', async () => {
  const first = deferred(), second = deferred();
  let calls = 0;
  const repo = { fetch: () => (++calls === 1 ? first.promise : second.promise), save: async () => {} };
  const catalog = new Catalog(repo, 'shop');
  const old = catalog.get('x');
  await Promise.resolve();
  await catalog.save({ id: 'x', price: 20 });
  const fresh = catalog.get('x');
  await Promise.resolve();
  assert.equal(calls, 2);
  first.resolve({ id: 'x', price: 10 });
  assert.equal((await old).price, 10);
  second.resolve({ id: 'x', price: 20 });
  assert.equal((await fresh).price, 20);
  assert.equal((await catalog.get('x')).price, 20);
});

test('old completion cannot remove a newer in-flight request or overwrite its result', async () => {
  const first = deferred(), second = deferred();
  let calls = 0;
  const cache = new Cache(() => (++calls === 1 ? first.promise : second.promise));
  const old = cache.get('k');
  await Promise.resolve();
  cache.invalidate('k');
  const newer = cache.get('k');
  await Promise.resolve();
  first.resolve('old');
  assert.equal(await old, 'old');
  const joined = cache.get('k');
  await Promise.resolve();
  assert.equal(calls, 2);
  second.resolve('new');
  assert.equal(await newer, 'new');
  assert.equal(await joined, 'new');
  assert.equal(await cache.get('k'), 'new');
});

test('clear isolates all pending reads; rejected reads can retry', async () => {
  const first = deferred();
  let calls = 0;
  const cache = new Cache(() => ++calls === 1 ? first.promise : 'new');
  const old = cache.get('x');
  await Promise.resolve();
  cache.clear();
  const fresh = cache.get('x');
  first.resolve('old');
  assert.equal(await old, 'old');
  assert.equal(await fresh, 'new');
  assert.equal(await cache.get('x'), 'new');
  let attempts = 0;
  const retry = new Cache(() => { if (!attempts++) throw Error('offline'); return null; });
  await assert.rejects(retry.get('x'), /offline/);
  assert.equal(await retry.get('x'), null);
  assert.equal(await retry.get('x'), null);
  assert.equal(attempts, 2);
});

test('repository operations and reporting preserve public behavior', async () => {
  const repo = new MemoryRepository([{ id: 'a', category: 'book', price: 5 }]);
  const catalog = new Catalog(repo, 'n');
  assert.equal((await catalog.get(' a ')).price, 5);
  await catalog.save({ id: 'a', category: 'book', price: 8 });
  assert.equal((await catalog.get('a')).price, 8);
  assert.deepEqual(summarize(await repo.all()), [{ category: 'book', count: 1, total: 8 }]);
  await catalog.remove('a');
  assert.equal(await catalog.get('a'), null);
});
