import { test, expect } from 'bun:test';
import { renderToStaticMarkup } from 'react-dom/server';
import { filterRows, sortRows } from '../src/rows.js';
import { paginate } from '../src/paginate.js';
import { rangeLabel } from '../src/range.js';
import { DataTable } from '../src/DataTable.jsx';

const rows = [
  { id: 1, name: 'Ada Berg', team: 'red', score: 50 },
  { id: 2, name: 'Bo Chen', team: 'blue', score: 70 },
  { id: 3, name: 'Cy Dorn', team: 'red', score: 70 },
  { id: 4, name: 'Di Eber', team: 'green', score: 40 },
  { id: 5, name: 'Ed Fox', team: 'blue', score: 50 },
  { id: 6, name: 'Flo Gray', team: 'red', score: 90 },
  { id: 7, name: 'Gus Hale', team: 'green', score: 70 },
  { id: 8, name: 'Hana Iyer', team: 'blue', score: 50 },
  { id: 9, name: 'Ivo Jung', team: 'red', score: 40 },
  { id: 10, name: 'Jo Kerr', team: 'green', score: 90 },
  { id: 11, name: 'Kai Bergen', team: 'green', score: 60 },
  { id: 12, name: 'Liv Mohr', team: 'red', score: 60 },
];
const columns = [
  { key: 'name', label: 'Name' },
  { key: 'team', label: 'Team' },
  { key: 'score', label: 'Score', numeric: true },
];
const ids = (html) => [...html.matchAll(/data-id="(\d+)"/g)].map((m) => Number(m[1]));
const table = (props) => renderToStaticMarkup(<DataTable rows={rows} columns={columns} {...props} />);

test('sortRows sorts numbers numerically and keeps ties in input order', () => {
  expect(sortRows(rows, 'score', 'asc').map((r) => r.id)).toEqual([4, 9, 1, 5, 8, 11, 12, 2, 3, 7, 6, 10]);
});

test('sortRows desc keeps tied rows in input order too', () => {
  expect(sortRows(rows, 'score', 'desc').map((r) => r.id)).toEqual([6, 10, 2, 3, 7, 11, 12, 1, 5, 8, 4, 9]);
});

test('sortRows returns a copy and never touches the input', () => {
  const copy = rows.slice();
  const out = sortRows(rows, 'name', 'desc');
  expect(rows).toEqual(copy);
  expect(out).not.toBe(rows);
  expect(sortRows(rows, undefined, undefined)).toEqual(rows);
});

test('filterRows trims and ignores case across the given fields', () => {
  expect(filterRows(rows, '  BER ', ['name']).map((r) => r.id)).toEqual([1, 4, 11]);
  expect(filterRows(rows, 'blu', ['name', 'team']).map((r) => r.id)).toEqual([2, 5, 8]);
  expect(filterRows(rows, '   ', ['name'])).toBe(rows);
});

test('paginate counts a partial last page', () => {
  expect(paginate(rows, 1, 5)).toMatchObject({ pages: 3, page: 1, total: 12 });
  expect(paginate(rows, 3, 5).items.map((r) => r.id)).toEqual([11, 12]);
  expect(paginate(rows, 1, 4).pages).toBe(3);
});

test('paginate clamps the page and reports one page when empty', () => {
  expect(paginate(rows, 99, 5).page).toBe(3);
  expect(paginate(rows, 0, 5).page).toBe(1);
  expect(paginate([], 4, 5)).toEqual({ items: [], page: 1, pages: 1, total: 0 });
});

test('table shows the first page in input order by default', () => {
  const html = table({});
  expect(ids(html)).toEqual([1, 2, 3, 4, 5]);
  expect(html).toContain('Page 1 of 3');
});

test('sorting happens before paging, descending ties stay stable across pages', () => {
  expect(ids(table({ sort: { key: 'team', dir: 'desc' } }))).toEqual([1, 3, 6, 9, 12]);
  expect(ids(table({ sort: { key: 'team', dir: 'desc' }, page: 2 }))).toEqual([4, 7, 10, 11, 2]);
  expect(ids(table({ sort: { key: 'team', dir: 'desc' }, page: 3 }))).toEqual([5, 8]);
});

test('the last page is reachable and a too-large page is clamped to it', () => {
  const html = table({ page: 7 });
  expect(ids(html)).toEqual([11, 12]);
  expect(html).toContain('Page 3 of 3');
  expect(html).toMatch(/data-action="next"[^>]*disabled/);
  expect(html).not.toMatch(/data-action="prev"[^>]*disabled/);
});

test('filtering applies to all rows before paging', () => {
  const html = table({ query: 'ber', pageSize: 2, page: 2 });
  expect(ids(html)).toEqual([11]);
  expect(html).toContain('Page 2 of 2');
});

test('every column carries aria-sort, none unless it is the sorted one', () => {
  const html = table({ sort: { key: 'score', dir: 'desc' } });
  expect(html).toContain('<th scope="col" aria-sort="none">Name</th>');
  expect(html).toContain('<th scope="col" aria-sort="descending">Score \u25BC</th>');
  expect(table({ sort: { key: 'name', dir: 'asc' } })).toContain('aria-sort="ascending">Name \u25B2');
  expect(table({}).match(/aria-sort="none"/g)).toHaveLength(3);
});

test('no match shows an empty note, one page and both buttons disabled', () => {
  const html = table({ query: 'zzz', page: 3 });
  expect(ids(html)).toEqual([]);
  expect(html).toContain('No matching rows');
  expect(html).toContain('Page 1 of 1');
  expect(html).toMatch(/data-action="prev"[^>]*disabled/);
  expect(html).toMatch(/data-action="next"[^>]*disabled/);
});

test('rangeLabel counts rows on the current page', () => {
  expect(rangeLabel(paginate(rows, 2, 5), 5)).toBe('Showing 6-10 of 12');
  expect(rangeLabel(paginate(rows, 3, 5), 5)).toBe('Showing 11-12 of 12');
  expect(rangeLabel(paginate([], 1, 5), 5)).toBe('No rows');
});

test('table footer reports the range of the filtered rows', () => {
  expect(table({ query: 'ber', pageSize: 2, page: 2 })).toContain('Showing 3-3 of 3');
  expect(table({ query: 'zzz' })).toContain('No rows');
});
