import { ariaSort } from './rows.js';

export function HeaderCell({ column, sort }) {
  const state = ariaSort(column.key, sort);
  const mark = state === 'ascending' ? ' \u25B2' : state === 'descending' ? ' \u25BC' : '';
  return (
    <th scope="col" aria-sort={state}>
      {column.label}
      {mark}
    </th>
  );
}
