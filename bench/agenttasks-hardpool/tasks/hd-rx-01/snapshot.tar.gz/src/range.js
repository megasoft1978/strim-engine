/** "Showing 6-10 of 12", or "No rows" when the view is empty. */
export function rangeLabel(view, size) {
  if (view.total === 0) return 'No rows';
  const from = (view.page - 1) * size + 1;
  const to = Math.min(view.page * size, view.total);
  return `Showing ${from}-${to} of ${view.total}`;
}
