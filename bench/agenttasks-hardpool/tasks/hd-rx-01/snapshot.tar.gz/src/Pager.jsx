export function Pager({ page, pages }) {
  return (
    <nav aria-label="Pagination">
      <button type="button" data-action="prev" disabled={page <= 1}>
        Previous
      </button>
      <span className="status">
        Page {page} of {pages}
      </span>
      <button type="button" data-action="next" disabled={page >= pages}>
        Next
      </button>
    </nav>
  );
}
