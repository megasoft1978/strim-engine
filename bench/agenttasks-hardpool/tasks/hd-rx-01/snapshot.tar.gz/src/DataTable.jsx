import { Pager } from './Pager.jsx';
import { HeaderCell } from './HeaderCell.jsx';
import { filterRows, sortRows } from './rows.js';
import { rangeLabel } from './range.js';
import { paginate } from './paginate.js';

export function DataTable({ rows, columns, sort = {}, query = '', page = 1, pageSize = 5 }) {
  const paged = paginate(sortRows(rows, sort.key, sort.dir), page, pageSize);
  const view = { ...paged, items: filterRows(paged.items, query, columns.map((c) => c.key)) };
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            {columns.map((c) => (
              <HeaderCell key={c.key} column={c} sort={sort} />
            ))}
          </tr>
        </thead>
        <tbody>
          {view.items.map((r) => (
            <tr key={r.id} data-id={r.id}>
              {columns.map((c) => (
                <td key={c.key} className={c.numeric ? 'num' : undefined}>
                  {r[c.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {view.total === 0 && <p className="empty">No matching rows</p>}
      <p className="range">{rangeLabel(view, pageSize)}</p>
      <Pager page={view.page} pages={view.pages} />
    </div>
  );
}
