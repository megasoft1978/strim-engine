/** Case-insensitive substring match over `fields`; a blank query keeps every row. */
export function filterRows(rows, query, fields) {
  const q = String(query ?? '').trim().toLowerCase();
  if (!q) return rows;
  return rows.filter((r) => fields.some((f) => String(r[f]).toLowerCase().includes(q)));
}

export function compareValues(a, b) {
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  return String(a).localeCompare(String(b));
}

/** Stable sort that never mutates its input; rows that tie keep their original order in both directions. */
export function sortRows(rows, key, dir = 'asc') {
  if (!key || dir === 'none') return rows.slice();
  const asc = rows
    .map((row, i) => [row, i])
    .sort(([a, i], [b, j]) => compareValues(a[key], b[key]) || i - j)
    .map(([row]) => row);
  return dir === 'desc' ? asc.reverse() : asc;
}

/** Value for the aria-sort attribute of the column `key`. */
export function ariaSort(key, sort) {
  if (!sort || sort.key !== key) return undefined;
  return sort.dir === 'desc' ? 'descending' : sort.dir === 'asc' ? 'ascending' : 'none';
}
