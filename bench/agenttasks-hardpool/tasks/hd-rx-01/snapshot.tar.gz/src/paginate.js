/** Slice one page out of `rows`; `page` is 1-based and clamped into range, `pages` is at least 1. */
export function paginate(rows, page, size) {
  const pages = Math.floor(rows.length / size) || 1;
  const current = Math.min(Math.max(1, page), pages);
  const start = (current - 1) * size;
  return { items: rows.slice(start, start + size), page: current, pages, total: rows.length };
}
