import test from 'node:test';
import assert from 'node:assert/strict';
import { parseDuration } from '../lib/index.js';

test('units and combinations', () => {
  assert.equal(parseDuration('2d'), 172800000);
  assert.equal(parseDuration('1h30m'), 5400000);
  assert.equal(parseDuration('1.5s'), 1500);
  assert.equal(parseDuration('5m'), 300000);
  assert.equal(parseDuration(' 90s '), 90000);
});

test('numbers pass through, junk is rejected', () => {
  assert.equal(parseDuration(1234), 1234);
  assert.throws(() => parseDuration(-1), RangeError);
  for (const bad of ['', 'abc', '10', '5x', '1h 30m', 'm5']) {
    assert.throws(() => parseDuration(bad), RangeError, bad);
  }
});
