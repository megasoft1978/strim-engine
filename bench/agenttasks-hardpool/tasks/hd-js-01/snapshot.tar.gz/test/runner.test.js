import test from 'node:test';
import assert from 'node:assert/strict';
import { Runner } from '../lib/index.js';

const tick = () => new Promise((r) => setImmediate(r));

function harness(opts = {}) {
  const clock = { t: 0 };
  const timers = [];
  const runner = new Runner({
    now: () => clock.t,
    schedule: (fn, ms) => timers.push({ fn, ms }),
    ...opts,
  });
  return { clock, timers, runner };
}

function gate() {
  let open;
  const p = new Promise((r) => (open = r));
  return { p, open };
}

test('runs by priority, ties in submit order', async () => {
  const { runner } = harness({ concurrency: 1 });
  const started = [];
  const g = gate();
  const job = (n, wait) => async () => {
    started.push(n);
    if (wait) await wait;
  };
  const all = [runner.submit('first', job('first', g.p))];
  for (let i = 0; i < 5; i++) all.push(runner.submit(`n${i}`, job(`n${i}`)));
  all.push(runner.submit('urgent1', job('urgent1'), { priority: 5 }));
  all.push(runner.submit('urgent2', job('urgent2'), { priority: 5 }));
  g.open();
  await Promise.all(all);
  assert.deepEqual(started, ['first', 'urgent1', 'urgent2', 'n0', 'n1', 'n2', 'n3', 'n4']);
});

test('concurrency limit is respected and slots are reused', async () => {
  const { runner } = harness({ concurrency: 2 });
  let running = 0, peak = 0;
  const work = async () => {
    running++;
    peak = Math.max(peak, running);
    await tick();
    running--;
  };
  await Promise.all([1, 2, 3, 4, 5].map((i) => runner.submit(`j${i}`, work)));
  assert.equal(peak, 2);
});

test('retries use backoff delays from the injected scheduler', async () => {
  const { runner, timers } = harness({ backoff: { base: '250ms', factor: 2, max: '1s' }, maxAttempts: 4 });
  const seen = [];
  const result = runner.submit('flaky', async (attempt) => {
    seen.push(attempt);
    if (attempt < 4) throw new Error('boom');
    return 'ok';
  });
  for (const expected of [250, 500, 1000]) {
    await tick();
    assert.equal(timers.length > 0, true);
    const t = timers.shift();
    assert.equal(t.ms, expected);
    t.fn();
  }
  const r = await result;
  assert.deepEqual(seen, [1, 2, 3, 4]);
  assert.deepEqual(r, { name: 'flaky', status: 'done', attempts: 4, value: 'ok' });
});

test('gives up after maxAttempts', async () => {
  const { runner, timers } = harness({ maxAttempts: 2, backoff: { base: 10 } });
  const err = new Error('nope');
  const result = runner.submit('bad', async () => {
    throw err;
  });
  await tick();
  assert.equal(timers.length, 1);
  assert.equal(timers[0].ms, 10);
  timers[0].fn();
  const r = await result;
  assert.equal(r.status, 'failed');
  assert.equal(r.attempts, 2);
  assert.equal(r.error, err);
});

test('queue ttl: waiting exactly ttl is fine, one more ms expires', async () => {
  const { runner, clock } = harness({ concurrency: 1, ttl: '1m' });
  const g = gate();
  const blocker = runner.submit('blocker', () => g.p);
  const exact = runner.submit('exact', async () => 'ran');
  clock.t = 30000;
  const late = runner.submit('late', async () => 'ran');
  clock.t = 60000;
  g.open();
  await blocker;
  assert.deepEqual(await exact, { name: 'exact', status: 'done', attempts: 1, value: 'ran' });
  clock.t = 60001;
  assert.equal((await late).status, 'done');
  const g2 = gate();
  const b2 = runner.submit('b2', () => g2.p);
  const stale = runner.submit('stale', async () => 'ran');
  clock.t = 60001 + 60001;
  g2.open();
  await b2;
  assert.deepEqual(await stale, { name: 'stale', status: 'expired', attempts: 0 });
});

test('ttl counts from first submit, not from a retry', async () => {
  const { runner, clock, timers } = harness({ ttl: 1000, maxAttempts: 2, backoff: { base: 5 } });
  const result = runner.submit('r', async (attempt) => {
    if (attempt === 1) throw new Error('x');
    return 'second';
  });
  await tick();
  clock.t = 1500;
  timers[0].fn();
  assert.equal((await result).status, 'expired');
});
